package exceptions;

public class MesaElectoralNoValidaException extends RuntimeException{
    public MesaElectoralNoValidaException(String mensaje){
        super(mensaje);
    }
}