import java.util.Scanner;
public class Activitat15 {
    final static int CELSIUS_A_FAHRENHEIT_SUMA = 32;
    final static float CELSIUS_A_FAHRENHEIT_MULTIPLICACIO = 1.8f;
    final static int FAHRENHEIT_A_CELSIUS_RESTE = 32;
    final static float FAHRENHEIT_A_CELSIUS_MULTIPLICACIO = 0.5556f;
    final static float KILIMETROSPORHORA_A_MILASPORHORA = 0.6213712f;
    final static float EXPONENTE = 0.16f;

    final static float CONSTANT_DE_LA_FORMULA = 35.74f;
    final static float CONSTANT_DE_LA_FORMULA2 = 0.6215f;
    final static float CONSTANT_DE_LA_FORMULA3 = 35.75f;
    final static float CONSTANT_DE_LA_FORMULA4 = 0.4275f;

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.println("CÀLCUL DE LA TEMPERATURA REAL\n-----------------------------");
        System.out.print("Introdueix la temperatura en ºC: ");
        int celsius = teclado.nextInt();

        System.out.print("Introdueix la velocitat del vent en km\\h: ");
        float kilometrosPorHora = teclado.nextFloat();


        float fahrentheit = (celsius * CELSIUS_A_FAHRENHEIT_MULTIPLICACIO) + CELSIUS_A_FAHRENHEIT_SUMA;
        float millasPorHora = kilometrosPorHora * KILIMETROSPORHORA_A_MILASPORHORA;

        double exponenteDeLaFormula = CONSTANT_DE_LA_FORMULA3 * Math.pow(millasPorHora, EXPONENTE);
        double exponenteDeLaFormula2 = CONSTANT_DE_LA_FORMULA4 * fahrentheit * Math.pow(millasPorHora, EXPONENTE);
        double multipliDeLaFormula1 = CONSTANT_DE_LA_FORMULA2 * fahrentheit;

        double formulaFinal = CONSTANT_DE_LA_FORMULA + multipliDeLaFormula1 - exponenteDeLaFormula + exponenteDeLaFormula2;

        double celsiusFinales = (formulaFinal - FAHRENHEIT_A_CELSIUS_RESTE) * FAHRENHEIT_A_CELSIUS_MULTIPLICACIO;

        System.out.printf("\nLa sensació tèrmica és de %.0f ºC", celsiusFinales);
    }
}