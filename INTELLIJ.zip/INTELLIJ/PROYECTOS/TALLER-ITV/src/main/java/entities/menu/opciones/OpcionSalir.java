package entities.menu.opciones;

import entities.menu.Opcion;

public class OpcionSalir extends Opcion {
    public OpcionSalir() {
        super("Salir");
    }

    @Override
    public void ejecutar() {
        this.setFinalizar(true);
    }
}