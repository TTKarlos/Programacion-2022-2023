package org.example.view;

import de.vandermeer.asciitable.AT_Row;
import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;
import org.example.GestorIO;
import org.example.Pedido;

public class PedidoView {
    private Pedido pedido;
    public PedidoView(Pedido pedido){
        this.pedido = pedido;
    }

    private String getTablaPedido(){
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow(null, null, null, null, "=== Restaurante 20 Montaditos ===");
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow( null, null, "Pedido: " + pedido.getIdentificador(), "Cliente: " +
                        pedido.getNombreDelCliente(), "Fecha: " + pedido.getFechaDelPedido());
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow(null, null, null, null, "Listado productos solicitados");
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow("Codigo", "Nombre", "Precio", "Descuento", "PVP");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < pedido.getBebidas().size(); i++) {
            table.addRule();
            row = table.addRow(pedido.getBebidas().get(i).getNombre(),
                    pedido.getBebidas().get(i).getDescripcion(),
                    GestorIO.tornarPreuEnFormato(pedido.getBebidas().get(i).getPrecioBase()),
                    GestorIO.tornarDescuentoEnFormato(pedido.getBebidas().get(i).getDecuento()),
                    GestorIO.tornarPreuEnFormato(pedido.getBebidas().get(i).calcularElPrecioPVP()));
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        }

        for (int i = 0; i < pedido.getEntrantes().size(); i++) {
            table.addRule();
            row = table.addRow(pedido.getEntrantes().get(i).getNombre(),
                    pedido.getEntrantes().get(i).getDescripcion(),
                    GestorIO.tornarPreuEnFormato(pedido.getEntrantes().get(i).getPrecioBase()),
                    GestorIO.tornarDescuentoEnFormato(pedido.getEntrantes().get(i).getDecuento()),
                    GestorIO.tornarPreuEnFormato(pedido.getEntrantes().get(i).calcularElPrecioPVP()));
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        }

        for (int i = 0; i < pedido.getMontaditos().size(); i++) {
            table.addRule();
            row = table.addRow(pedido.getMontaditos().get(i).getNombre(),
                    pedido.getMontaditos().get(i).getDescripcion(),
                    GestorIO.tornarPreuEnFormato(pedido.getMontaditos().get(i).getPrecioBase()),
                    GestorIO.tornarDescuentoEnFormato(pedido.getMontaditos().get(i).getDecuento()),
                    GestorIO.tornarPreuEnFormato(pedido.getMontaditos().get(i).calcularElPrecioPVP()));
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        }

        for (int i = 0; i < pedido.getPostres().size(); i++) {
            table.addRule();
            row = table.addRow(pedido.getPostres().get(i).getNombre(),
                    pedido.getPostres().get(i).getDescripcion(),
                    GestorIO.tornarPreuEnFormato(pedido.getPostres().get(i).getPrecioBase()),
                    GestorIO.tornarDescuentoEnFormato(pedido.getPostres().get(i).getDecuento()),
                    GestorIO.tornarPreuEnFormato(pedido.getPostres().get(i).calcularElPrecioPVP()));
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        }

        table.addRule();
        row = table.addRow(null, null, null, null, "TOTAL PRECIO = " +
                GestorIO.tornarPreuEnFormato(pedido.totalDineroDelPedido()));
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.RIGHT);

        table.addRule();
        row = table.addRow("*", "*", "*", "*", "*");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        table.addRule();

        return table.render();
    }

    @Override
    public String toString() {
        return getTablaPedido();
    }
}
