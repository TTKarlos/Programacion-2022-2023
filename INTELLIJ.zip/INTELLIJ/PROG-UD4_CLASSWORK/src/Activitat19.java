public class Activitat19 {

    final static String FRASE = "Hola Món";

    public static void main(String[] args) {

        separarLletres(FRASE);

    }

    public static void separarLletres(String frase){

        for (int i = 0; i < frase.length(); i++){

            String caracter = String.valueOf(frase.charAt(i));

            if (caracter.equalsIgnoreCase(" ")){
            } else if (i != frase.length() - 1){
                System.out.print(caracter + "-");
            } else {
                System.out.println(caracter);
            }
        }
    }
}