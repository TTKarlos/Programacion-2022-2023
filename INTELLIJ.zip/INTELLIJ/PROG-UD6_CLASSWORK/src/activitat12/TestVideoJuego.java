package activitat12;

public class TestVideoJuego {
    public static void main(String[] args) {

        VideoJuego[] listado = new VideoJuego[5];

        listado[0] = new VideoJuego("Fortnite", "Acción", 40, true);
        listado[1] = new VideoJuego("Fifa", "Deportes", 50, true);
        listado[2] = new VideoJuego("Gran Theft Auto", "Acción", 80, true);
        listado[3] = new VideoJuego("MineCraft", "Simulación", 60, true);
        listado[4] = new VideoJuego("AnimalCrossing", "Simulación", 30,true);

        System.out.println("----- VIDEOJUEGOS 1.0 -----");
        VideoJuego.mostrarelJuegoMasBarato(listado);
        VideoJuego.mostrarelJuegoMasCaro(listado);
        VideoJuego.mostrarElTotalDelPrecioDeVideoJuegos(listado);
    }
}
