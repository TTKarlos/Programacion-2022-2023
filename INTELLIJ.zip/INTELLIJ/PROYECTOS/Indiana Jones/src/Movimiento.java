import java.util.Scanner;

public class Movimiento {

    final static String[] LETRAS_DE_MOVIMIENTO = {"W", "A", "S", "D"};
    final static int NO_ES_UNA_DIRECCION_VALIDA = -1;
    final static int INDICES_MAXIMOS_DE_POSICION = 2;
    final static int PRIMERA_DIRECCION = 1;
    final static int SEGUNDA_DIRECCION = 2;
    final static int TERCERA_DIRECCION = 3;
    final static int CUARTA_DIRECCION = 4;
    final static int INICIAL_INDICE = 0;
    final static int PUNTO_X = 0;
    final static int PUNTO_Y = 1;
    final static String MENSAJE_DE_ERROR = "\uD835\uDD3B\uD835\uDD56\uD835\uDD53\uD835\uDD56\uD835\uDD64 " +
            "\uD835\uDD5A\uD835\uDD5F\uD835\uDD65\uD835\uDD63\uD835\uDD60\uD835\uDD55\uD835\uDD66\uD835\uDD54" +
            "\uD835\uDD5A\uD835\uDD63 ❞\uD835\uDD4E, \uD835\uDD38, \uD835\uDD4A \uD835\uDD6A \uD835\uDD3B❞";
    final static String COLOR_ROJO = "\033[31m";
    final static String COLOR_AZUL = "\033[34m";
    final static String RESET_COLOR = "\u001B[0m";


    public static boolean esUnaDireccionValida(int direccion){
        if(direccion == PRIMERA_DIRECCION || direccion == SEGUNDA_DIRECCION ||
                direccion == TERCERA_DIRECCION || direccion == CUARTA_DIRECCION){
            return true;
        }

        return false;
    }

    public static int obtieneDireccionAleatoria(){

        int numAleatorio = (int) (Math.random()*4+1);

        if(esUnaDireccionValida(numAleatorio)){
            return numAleatorio;
        } else {
            return NO_ES_UNA_DIRECCION_VALIDA;
        }
    }

    public static int[] obtenerCoordenadaAdyacente(int direccion, int[] posicion){
        if (posicion.length != INDICES_MAXIMOS_DE_POSICION) {
            return posicion;
        }
        int[] nuevaPosicion = posicion.clone();
        switch (direccion) {
            case PRIMERA_DIRECCION -> nuevaPosicion[PUNTO_X] -= 1;
            case SEGUNDA_DIRECCION -> nuevaPosicion[PUNTO_X] += 1;
            case TERCERA_DIRECCION -> nuevaPosicion[PUNTO_Y] += 1;
            case CUARTA_DIRECCION -> nuevaPosicion[PUNTO_Y] -= 1;
            default -> {
                return posicion;
            }
        }
        return nuevaPosicion;
    }

    public static int pedirDireccion(){

        Principal.scanner = new Scanner(System.in);
        String letraintroducida;
        boolean esCorrecto = true;

        do{

            System.out.print(COLOR_AZUL + "Iɴᴛʀᴏᴅᴜᴄᴇ ᴜɴ ᴍᴏᴠɪᴍɪᴇɴᴛᴏ: " + RESET_COLOR);
            letraintroducida = Principal.scanner.next();

            for( int i = INICIAL_INDICE; i < LETRAS_DE_MOVIMIENTO.length; i++){
                if(letraintroducida.equalsIgnoreCase(LETRAS_DE_MOVIMIENTO[i])){
                    esCorrecto = false;
                }
            }

            if(esCorrecto){
                System.out.println(COLOR_ROJO + MENSAJE_DE_ERROR + RESET_COLOR);
            }

        } while(esCorrecto);

        if (letraintroducida.equals("w")){
            return PRIMERA_DIRECCION;
        } else if (letraintroducida.equals("s")){
            return SEGUNDA_DIRECCION;
        } else if (letraintroducida.equals("d")){
            return TERCERA_DIRECCION;
        } else {
            return CUARTA_DIRECCION;
        }
    }
}