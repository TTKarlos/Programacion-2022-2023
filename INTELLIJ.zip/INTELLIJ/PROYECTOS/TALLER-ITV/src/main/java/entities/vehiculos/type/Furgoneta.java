package entities.vehiculos.type;

import entities.vehiculos.Vehiculo;
import java.time.LocalDate;

public class Furgoneta extends Vehiculo {
    private float PMA;

    public Furgoneta(String matricula, String marca, String modelo, LocalDate fechaUltimaRevision,
                     int cilindros, int numeroPlazas, int potenciaDeCC, float PMA) {
        super(matricula, marca, modelo, fechaUltimaRevision, cilindros, numeroPlazas, potenciaDeCC);
        this.PMA = PMA;
    }

    public Furgoneta(String matricula, String marca, String modelo, int cilindros,
                     int numeroPlazas, int potenciaDeCC, float PMA) {
        super(matricula, marca, modelo, LocalDate.of(2021, 12 , 12), cilindros, numeroPlazas, potenciaDeCC);
        this.PMA = PMA;
    }

    public float getPMA() {
        return PMA;
    }

    public double calcularPrecioRevision(){
        double precioAdicional = 0;

        double pma = 0;
        if (cilindros >= 4 && cilindros <= 10) {
            pma = 3 * (double) cilindros;
        } else if (cilindros > 10) {
            pma = 4 * (double) cilindros;
        }

        if (cilindros >= 8 && cilindros <= 16) {
            precioAdicional += 3 * pma;
        } else {
            precioAdicional += 4 * pma;
        }

        return precioAdicional + super.calcularPrecioRevision();
    }
}