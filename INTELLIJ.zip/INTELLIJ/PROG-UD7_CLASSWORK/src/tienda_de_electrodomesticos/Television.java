package tienda_de_electrodomesticos;

public class Television extends Electrodomesticos implements Conectable {
    private int resolucionEnPulgadas;
    private  boolean esSmartTV;

    public Television(String marca, String modelo, String codigo) {
        super(marca, modelo, codigo);
        this.resolucionEnPulgadas = 20;
        this.esSmartTV = false;
    }

    public Television(String marca, String modelo, String codigo, int resolucionEnPulgadas, boolean esSmartTV) {
        super(marca, modelo, codigo);
        this.resolucionEnPulgadas = resolucionEnPulgadas;
        this.esSmartTV = esSmartTV;
    }

    public void setEsSmartTV(boolean esSmartTV) {
        this.esSmartTV = esSmartTV;
    }

    @Override
    public float obtenerPrecioVenta(){
        float precioVenta = super.obtenerPrecioVenta();

        if(resolucionEnPulgadas > 40){
            precioVenta =precioVenta * 1.30f;
        }

        if(esSmartTV) {
            precioVenta += 50;
        }

        return precioVenta;
    }
    @Override
    public String toString() {
        return "[Television] Resolucion: " + resolucionEnPulgadas + ", Smart TV: " + esSmartTV + ", " +
                super.toString() + ", Precio Venta: " + obtenerPrecioVenta() + ", Power: " + getEstaEncendido();
    }
}