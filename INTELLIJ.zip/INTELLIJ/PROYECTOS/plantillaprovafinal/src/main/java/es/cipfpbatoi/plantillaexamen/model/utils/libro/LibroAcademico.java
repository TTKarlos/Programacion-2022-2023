package es.cipfpbatoi.plantillaexamen.model.utils.libro;

import es.cipfpbatoi.plantillaexamen.model.utils.Editorial;
import es.cipfpbatoi.plantillaexamen.model.utils.enums.NivelEducativo;
import java.time.LocalDate;

public class LibroAcademico extends Libro{
    private NivelEducativo nivelEducativo;

    public LibroAcademico(String titulo, String autor, LocalDate fechaPublicacion, Editorial editorial, NivelEducativo nivelEducativo) {
        super(titulo, autor, fechaPublicacion, editorial);
        this.nivelEducativo = nivelEducativo;
    }

    public LibroAcademico(String titulo, String autor, LocalDate fechaPublicacion, int editorial, NivelEducativo nivelEducativo) {
        super(titulo, autor, fechaPublicacion, editorial);
        this.nivelEducativo = nivelEducativo;
    }

    public NivelEducativo getNivelEducativo() {
        return nivelEducativo;
    }
}