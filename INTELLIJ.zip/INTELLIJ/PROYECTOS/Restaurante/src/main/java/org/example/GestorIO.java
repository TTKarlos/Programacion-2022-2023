package org.example;

import java.util.Scanner;

public class GestorIO {
    public final static String COLOR_AZUL = "\u001B[34m";
    public final static String RESET_COLOR = "\u001B[0m";
    public final static String COLOR_VERDE = "\u001B[32m";
    public final static String COLOR_ROJO = "\u001B[31m";
    final static String TEXTO_INTRODUCIR_NOMBRE = "Introduzca su nombre: ";
    final static String TEXTO_INTRODUCIR_FECHA = "Introduxca la fecha antual en formato dd/mm/yyyy: ";
    public final static String TEXTO_ERROR_INTRODUCIR_FECHA = "Introduce una fecha correcta y siguiendo el estandard";
    public final static String TEXTO_SALIR = "==============================================\n" + COLOR_AZUL +
            "=========== Esperamos verte pronto ===========" + RESET_COLOR +
            "\n============================================== ";
    public final static String TEXTO_MENU = String.format("%s1.%s Crear nuevo pedido\n%s2. %sListar todos los pedidos\n%s3. %sVisualizar orden\n%s4. " +
                        "%sServir Pedido\n%s5. %s Salir\n", COLOR_ROJO, RESET_COLOR, COLOR_ROJO, RESET_COLOR,
    COLOR_ROJO, RESET_COLOR, COLOR_ROJO, RESET_COLOR, COLOR_ROJO, RESET_COLOR);

    public static int elegirUnPedido(int index, String textoError) {
        Scanner teclado = new Scanner(System.in);

        do {
            GestorIO.mostrarTextoEnAzul(String.format("Elige un pedido [1-%d]: ", index));

            if (teclado.hasNextInt()) {
                int numElegido = teclado.nextInt();

                if (numElegido >= 1 && numElegido <= index) {
                    return numElegido - 1;
                } else {
                    GestorIO.mostrarTextoEnError(textoError);
                }
            } else {
                GestorIO.mostrarTextoEnError(textoError);
                teclado.next();
            }
        } while (true);
    }

    public static String pedirNombre() {
        Scanner teclado = new Scanner(System.in);
        GestorIO.mostrarTextoEnAzul(TEXTO_INTRODUCIR_NOMBRE);
        return teclado.next();
    }

    public static String pedirFecha() {
        Scanner teclado = new Scanner(System.in);
        do {
            GestorIO.mostrarTextoEnAzul(TEXTO_INTRODUCIR_FECHA);
            String fecha = teclado.next();
            Fecha fecha1 = new Fecha(fecha);

            if (fecha1.isCorrecta()) {
                return fecha;
            } else {
                GestorIO.mostrarTextoEnError(TEXTO_ERROR_INTRODUCIR_FECHA);
            }
        } while (true);
    }

    public static void mostrarTextoEnError(String texto){
        System.out.println(COLOR_ROJO + texto + RESET_COLOR);
    }

    public static void mostrarTextoEnVerde(String texto){
        System.out.println(COLOR_VERDE + texto + RESET_COLOR);
    }

    public static void mostrarTextoEnAzul(String texto){
        System.out.print(COLOR_AZUL + texto + RESET_COLOR);
    }

    public static String tornarPreuEnFormato(float preu){
        return String.format("%.2f€", preu);
    }

    public static String tornarDescuentoEnFormato(float descuento){
        return String.format("%.2f%%", descuento);
    }
}