package org.example.productos;

import org.example.Producto;
import org.example.enums.TamanyoDeBebida;

public class Bebida extends Producto {
    private TamanyoDeBebida tamanyoDeBebida;
    private boolean esRellenable;

    public Bebida(String nombre, String descripcion, float precioBase, float decuento, float iva,
                  TamanyoDeBebida tamanyoDeBebida, boolean esRellenable) {
        super(nombre, descripcion, precioBase, decuento, iva);
        this.tamanyoDeBebida = tamanyoDeBebida;
        this.esRellenable = esRellenable;
    }

    @Override
    public String getEsRellenableEnFormato(){
        if(esRellenable){
            return "SI";
        } else {
            return "No";
        }
    }
}