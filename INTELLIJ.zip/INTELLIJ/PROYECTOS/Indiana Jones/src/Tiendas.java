public class Tiendas {

    static final String TIENDA = "\uD83D\uDCB0";

    public static int[] generarTiendas(String[][] escenario){

        do{

            int[] posicionCreada = {(int) (Math.random()*escenario.length +1), (int) (Math.random()*escenario.length +1)};

            if(Escenario.esUnPuntoDelEscenario(escenario, posicionCreada[0], posicionCreada[1]) &&
                    esUnHuecoVacio(escenario, posicionCreada[0], posicionCreada[1])){
                return posicionCreada;
            }

        } while (true);
    }

    public static boolean hayTiendas(String[][] escenario, int x, int y){

        if (escenario[x][y].equals(TIENDA)){
            return true;
        }

        return false;
    }

    public static boolean esUnHuecoVacio(String[][] escenario, int x, int y){

        if (escenario[x][y].equalsIgnoreCase(Escenario.NADA)){
            return true;
        }

        return false;
    }
}
