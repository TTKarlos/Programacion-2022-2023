package exception;

public class ReservaNoValidaException extends RuntimeException{
    public ReservaNoValidaException(){
        super("Error! Esta reserva no es valdia");
    }
}