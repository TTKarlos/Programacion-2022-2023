package Practica;

import java.util.Scanner;

public class Activitat2 {

    final static float GELAT_DE_XOCOLATA = 1.5f;
    final static float GELAT_DE_LLIMA = 1.25f;
    final static float GELAT_DE_TORRO = 1.75f;
    final static int ORTXATA = 2;
    final static float GRANISSAT_DE_LLIMA = 2.1f;
    final static float GAFE_GRANISSAT = 2.5f;
    final static int NUMERO_DE_TAULES = 2;

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.println("Benvingut a la Gelateria de Batoi");

        for (int x = 1; x <= NUMERO_DE_TAULES; x++) {

            System.out.println("\nIntrodueix les dades per a la Taula " + x);

            int numClientes;
            boolean esCorrecto = false;
            do {
                System.out.print("Quants clients són? [1-10]: ");
                if (!teclado.hasNextInt()) {
                    System.out.println("Error! El tipus de dades introduït és incorrecte");
                    return;
                } else {
                    numClientes = teclado.nextInt();
                }
                if (numClientes <= 0 || numClientes > 10) {
                    System.out.println("Número de clients incorrecte. Introduïx-lo de nou");
                } else {
                    esCorrecto = true;
                }
            } while (!esCorrecto);

            int numRondas = 1;
            float preuTotalTaula = 0;
            System.out.println("Bon dia a tots, disposem de la següent carta:");
            System.out.println("1. Gelat de xocolata\n2. Gelat de llima\n3. Gelat de torró\n4. Orxata\n5. Granissat de llima\n6. Cafè granissat");
            boolean altraRonda;
            do {
                float preuRonda = 0;
                System.out.println("Ronda " + numRondas);
                for (int i = 1; i <= numClientes; i++) {
                    System.out.print("Què vol prendre el client " + i + "? [1-6]: ");
                    if (!teclado.hasNextInt()) {
                        System.out.print("Error! El tipus de dades introduït és incorrecte");
                        return;
                    } else {
                        int numProducto = teclado.nextInt();
                        switch (numProducto) {
                            case 1 -> preuRonda += GELAT_DE_XOCOLATA;
                            case 2 -> preuRonda += GELAT_DE_LLIMA;
                            case 3 -> preuRonda += GELAT_DE_TORRO;
                            case 4 -> preuRonda += ORTXATA;
                            case 5 -> preuRonda += GRANISSAT_DE_LLIMA;
                            case 6 -> preuRonda += GAFE_GRANISSAT;
                            default -> {
                                System.out.println("Ho senc, això no està a la nostra carta");
                                i--;
                            }
                        }
                    }
                }
                System.out.printf("El cost de la ronda %d és: %.2f€\n", numRondas, preuRonda);

                System.out.print("Altra ronda? [true/false]: ");
                if (!teclado.hasNextBoolean()) {
                    System.out.println("Error! El tipus de dades introduït és incorrecte");
                    return;
                } else {
                    altraRonda = teclado.nextBoolean();
                }
                numRondas++;
                preuTotalTaula += preuRonda;
            } while (altraRonda);
            System.out.printf("El total a pagar de la taula %d és %.2f€\n", x, preuTotalTaula);
        }
    }
}