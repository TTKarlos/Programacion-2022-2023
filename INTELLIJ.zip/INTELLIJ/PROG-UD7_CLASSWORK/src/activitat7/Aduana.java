package activitat7;

public class Aduana{

    private Persona[] persones;

    public Aduana(Persona[] persones){
        this.persones = persones;
    }

    public Aduana(){

    }

    public void entrar(Persona persona){
        System.out.println("Your Welcome");
        persona.saludar();

        int posicio = obtindrePosicio();

        if(posicio == -1 && persones.length >= 10){
            System.out.println("Maximo de 10 personas");
        } else if(posicio == -1 && persones.length < 10){
            persones[persones.length - 1] = persona;
        } else {
            persones[posicio] = persona;
        }
    }

    private int obtindrePosicio(){
        for (int i = 0; i < persones.length; i++) {
            if(persones[i] == null){
                return i;
            }
        }

        return -1;
    }
}