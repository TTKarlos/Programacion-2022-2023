package es.cipfpbatoi.gestorusuariosv2.model.dao;

import es.cipfpbatoi.gestorusuariosv2.model.dao.interfaces.UserDAO;
import es.cipfpbatoi.gestorusuariosv2.model.entities.User;
import es.cipfpbatoi.gestorusuariosv2.model.repositories.EmpresaRepository;
import es.cipfpbatoi.gestorusuariosv2.utils.database.MySQLConnection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.sql.*;
import java.util.ArrayList;

@Service
public class SQLUserDAO implements UserDAO {
    private final MySQLConnection mySQLConnection;

    public SQLUserDAO(@Autowired MySQLConnection mySQLConnection) {
        this.mySQLConnection = mySQLConnection;
    }

    @Override
    public ArrayList<User> findAll() {
        ArrayList<User> usersList = new ArrayList<>();

        try {
            Connection connection = mySQLConnection.getConnection();
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM users";
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()){
                usersList.add(mapFromResulset(resultSet));
            }

            return usersList;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public ArrayList<User> findAll(String searchField) {
        ArrayList<User> usersList = new ArrayList<>();

        try(
                Connection connection = mySQLConnection.getConnection();
                Statement statement = connection.createStatement()
                ) {
            String sql = String.format("SELECT * FROM users WHERE name LIKE '%s%%'", searchField);
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()){
                usersList.add(mapFromResulset(resultSet));

            }
            return usersList;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public User findById(int id) {
        try {
            Connection connection = mySQLConnection.getConnection();
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM users WHERE id = " + id;
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()){
                return mapFromResulset(resultSet);
            }
            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean save(User user) {
        if(user.getId() > 0){
            return update(user);
        }
        return insert(user);
    }

    private boolean update(User user){
        int afectedRows = 0;

        String sql = "UPDATE users SET name = ?, surname = ?, dni = ?, email = ?, mobilePhone = ?" +
                "birthday = ?, idEnterprise = ?, zipCode = ?, password = ? WHERE id = ?";
        try (Connection connection = mySQLConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setString(1, user.getName());
            ps.setString(2, user.getSurname());
            ps.setString(3, user.getDni());
            ps.setString(4, user.getEmail());
            ps.setString(5, user.getMobilePhone());
            ps.setDate(6, Date.valueOf(user.getBirthday()));
            ps.setInt(7, user.idEmpresa());
            ps.setString(8, user.getZipCode());
            ps.setString(9, user.getPassword());
            ps.setInt(10, user.getId());
            afectedRows = ps.executeUpdate();
            return afectedRows > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private boolean insert(User user){
        String sql = "INSERT INTO users (id, name, surname, dni, email, mobilePhone, birthday, idEnterprise, zipCode, " +
                "password) VALUES (?,?,?,?,?,?,?,?,?,?)";
        try (Connection connection = mySQLConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)){

            preparedStatement.setNull(1, Types.INTEGER);
            preparedStatement.setString(2, user.getName());
            preparedStatement.setString(3, user.getSurname());
            preparedStatement.setString(4, user.getDni());
            preparedStatement.setString(5, user.getEmail());
            preparedStatement.setString(6, user.getMobilePhone());
            preparedStatement.setDate(7, Date.valueOf(user.getBirthday()));
            preparedStatement.setInt(8, user.idEmpresa());
            preparedStatement.setString(9, user.getZipCode());
            preparedStatement.setString(10, user.getPassword());
            return preparedStatement.executeUpdate() > 0;

        } catch (SQLException e){
            throw new RuntimeException(e);
        }
    }

    public boolean remove(User user) {
        int afectedRows = 0;
        String sql = "DELETE FROM users WHERE id = ?";
        try (Connection connection = mySQLConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(sql)){
            preparedStatement.setInt(1, user.getId());
            afectedRows = preparedStatement.executeUpdate();
            return afectedRows > 0;
        } catch (SQLException e){
            throw new RuntimeException(e);
        }
    }

    private User mapFromResulset(ResultSet resultSet) throws SQLException {
        return new User(resultSet.getInt("id"), resultSet.getString("name"),
                resultSet.getString("surname"), resultSet.getString("dni"),
                resultSet.getString("email"), resultSet.getString("zipCode"),
                resultSet.getString("mobilePhone"), resultSet.getDate("birthday").toLocalDate(),
                resultSet.getInt("idEnterprise"), resultSet.getString("password"));
    }
}