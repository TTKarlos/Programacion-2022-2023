package activitat11;

public class CocheDeEmpresa {

    private String matricula;
    private String marca;
    private String modelo;

    public CocheDeEmpresa(String matricula, String marca, String modelo){
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
    }
}
