package entities;

public class Mecanico {
    private String nombre;
    private String dni;

    public Mecanico(String nombre, String dni) {
        this.nombre = nombre;
        this.dni = dni;
    }

    public Mecanico(String dni){
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDni() {
        return dni;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Mecanico)) return false;
        Mecanico mecanico = (Mecanico) o;
        return dni.equalsIgnoreCase(mecanico.dni);
    }
}