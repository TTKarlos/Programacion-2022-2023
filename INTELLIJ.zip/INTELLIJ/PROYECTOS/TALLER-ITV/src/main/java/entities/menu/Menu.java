package entities.menu;

import entities.Taller;
import utils.GestioIO;

public class Menu {
    private Opcion[] opcions;
    private Taller taller;

    public Menu(Opcion[] opcions) {
        this.opcions = opcions;
    }

    public void show(){
        int num;

        do{
            mostrarMenu();
            num = GestioIO.devolverNumeroEntreXyY("Elige una opcion ", 1, opcions.length) - 1;
            opcions[num].ejecutar();
        } while (!opcions[num].finalizar());
    }

    private void mostrarMenu(){
        for (int i = 0; i < opcions.length; i++) {
            System.out.println(GestioIO.COLOR_ROJO + (i + 1) + ". "  + GestioIO.RESET_COLOR + opcions[i].getTitulo());
        }
    }
}