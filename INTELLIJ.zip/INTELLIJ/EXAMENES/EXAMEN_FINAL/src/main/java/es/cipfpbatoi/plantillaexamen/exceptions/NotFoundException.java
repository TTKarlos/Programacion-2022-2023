package es.cipfpbatoi.plantillaexamen.exceptions;

public class NotFoundException extends Exception{
    public NotFoundException(String texto){
        super(texto);
    }
}