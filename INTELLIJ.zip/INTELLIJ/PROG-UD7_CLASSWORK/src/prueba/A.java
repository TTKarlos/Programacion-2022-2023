package prueba;

class A extends B {
    public A(int t) {
        System.out.println("constructor A");
    }
}