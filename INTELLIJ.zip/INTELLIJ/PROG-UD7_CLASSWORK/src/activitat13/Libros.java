package activitat13;

public class Libros extends MaterialPrestamo implements Imprimible{
    private int numeroPagina;
    private String capituloMuestra;
    private String texto;

    public Libros(int codigoIdentificativo, String titulo, String autor, int numeroPagina, String capituloMuestra, String texto){
        super(codigoIdentificativo, titulo, autor);
        this.numeroPagina = numeroPagina;
        this.capituloMuestra = capituloMuestra;
        this.texto = texto;
    }

    @Override
    public void obtenerTexto() {
        System.out.println("[Libro]: titulo: "+ getTitulo() + " autor: " + getAutor() + "titulo: \"" +
                capituloMuestra + "\"" + "contenido: " + texto);
    }
}
