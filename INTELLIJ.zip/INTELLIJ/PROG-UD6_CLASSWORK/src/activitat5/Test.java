package activitat5;

public class Test {
    public static void main(String[] args) {
        Persona andreu = new Persona("Andreu", "Puchades Pascual", 19, false);
        Persona paco = new Persona("Paco", "Fernandez Perez", 32, true);

        andreu.saluda();
        paco.saluda();
    }
}