public class Escenario {

    static final String NADA = "\u2B1B";
    static final String MURO = "\uD83E\uDDF1";
    static final String JOREIA = "\uD83D\uDC8E";
    final static int TAMAÑO_ESCENARIO = 8;
    final static int INDEX_INICIAL = 0;
    static int MAXIMO_DE_GEMAS = 3;
    static int MAXIMO_DE_MUROS = 9;

    public static String[][] creaEscenario(){

        String[][] escenario = new String[TAMAÑO_ESCENARIO][TAMAÑO_ESCENARIO];

        for(int i = INDEX_INICIAL; i < escenario.length; i++){
            for(int j = INDEX_INICIAL; j < escenario[i].length; j++){
                if(i == INDEX_INICIAL || j == INDEX_INICIAL || i == escenario.length - 1 || j == escenario[i].length - 1){
                    escenario[i][j] = MURO;
                } else if (i == IndianaJones.ARRAY_INDIANA_JONES[0] && j == IndianaJones.ARRAY_INDIANA_JONES[1] ||
                        i == IndianaJones.ARRAY_INDIANA_JONES[0] + 1 && j == IndianaJones.ARRAY_INDIANA_JONES[1] ||
                        i == IndianaJones.ARRAY_INDIANA_JONES[0] && j == IndianaJones.ARRAY_INDIANA_JONES[1] + 1 ||
                        i == Serpientes.ARRAY_SERPIENTE[0][0] && j == Serpientes.ARRAY_SERPIENTE[0][1] ||
                        i == Serpientes.ARRAY_SERPIENTE[1][0] && j == Serpientes.ARRAY_SERPIENTE[1][1]) {
                    escenario[i][j] = NADA;
                } else {
                    int numRandom = (int) (Math.random()*6+1);
                    if (MAXIMO_DE_MUROS >= 1 && (numRandom == 1 || numRandom == 2)){
                        escenario[i][j] = MURO;
                        MAXIMO_DE_MUROS--;
                    } else if(MAXIMO_DE_GEMAS >= 1 && numRandom == 3){
                        escenario[i][j] = JOREIA;
                        MAXIMO_DE_GEMAS--;
                    } else {
                        escenario[i][j] = NADA;
                    }
                }
            }
        }

        return escenario;
    }

    public static boolean esUnPuntoDelEscenario(String[][] escenario, int x, int y){

        if(x < escenario.length && y < escenario.length && x >= INDEX_INICIAL && y >= INDEX_INICIAL){
            return true;
        }

        return false;
    }

    public static boolean estaPermitidoElPaso(String [][] escenario, int x, int y){

        if(esUnPuntoDelEscenario(escenario, x, y) && !(escenario[x][y].equals(MURO))){
            return true;
        }

        return false;
    }

    public static boolean hayGema(String[][] escenario, int x, int y){

        if (escenario[x][y].equals(JOREIA)){
            return true;
        }

        return false;
    }

    public static void vaciarCelda(String[][] escenario, int x, int y){

        if(esUnPuntoDelEscenario(escenario, x , y)){
            escenario[x][y] = NADA;
        }

    }

    public static boolean quedanGemas(String[][] escenario){
        for(int i = INDEX_INICIAL; i < escenario.length; i++){
            for(int j = INDEX_INICIAL; j < escenario[i].length; j++){
                if(escenario[i][j].equals(JOREIA)){
                    return true;
                }
            }
        }

        return false;
    }
}