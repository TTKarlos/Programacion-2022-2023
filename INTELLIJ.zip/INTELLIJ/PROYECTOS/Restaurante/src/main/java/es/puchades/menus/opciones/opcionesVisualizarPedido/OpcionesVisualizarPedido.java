package es.puchades.menus.opciones.opcionesVisualizarPedido;

import es.puchades.Restaurante;
import es.puchades.menus.Menu;
import es.puchades.menus.opciones.Opcion;

public abstract class OpcionesVisualizarPedido extends Opcion {
    private Restaurante restaurante;

    public OpcionesVisualizarPedido(String texto, Restaurante restaurante){
        super(texto);
        this.restaurante = restaurante;
    }

    @Override
    public void ejecutar(){
    }
}