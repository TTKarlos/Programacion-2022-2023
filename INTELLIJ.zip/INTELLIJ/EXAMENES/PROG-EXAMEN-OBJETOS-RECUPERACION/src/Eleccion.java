import exceptions.EleccionNoValidaExcepion;
import exceptions.EleccionYaEmpezadaException;
import exceptions.NoSeAdmitenMasMesasException;
import exceptions.VotoInvalidoException;
import java.time.LocalDate;
import java.util.ArrayList;

public abstract class Eleccion {
    protected ArrayList<MesaElectoral> mesasElectorales;
    protected LocalDate diaVotacion;
    protected ArrayList<Partido> partidos;
    protected ArrayList<Resultado> resultados;

    public Eleccion(ArrayList<Partido> partidos, LocalDate diaVotacion){
        this.partidos = partidos;
        this.diaVotacion = diaVotacion;
        this.mesasElectorales = new ArrayList<>();
        this.resultados = new ArrayList<>();
        comprobarFecha(diaVotacion);
    }

    public void calcularResultados(){
        for (int i = 0; i < partidos.size(); i++) {
            for (int j = 0; j < mesasElectorales.size(); j++) {
                int votos = mesasElectorales.get(j).obtenerVoto(partidos.get(i));
                Resultado resultado = new Resultado(partidos.get(i), votos);
                resultados.add(resultado);
            }
        }
    }

    public ArrayList<Resultado> getResultados() {
        return resultados;
    }

    public void votar(String dni, Partido partido){
        comprobarPartido(partido);
    }

    public void generarMesaElectoral(){
        comprobarNumeroDeMesas();
    }

    public ArrayList<MesaElectoral> getMesasElectorales() {
        return mesasElectorales;
    }

    public ArrayList<String> generar15Votantes(){
        ArrayList<String> dni = new ArrayList<>();

        for (int i = 0; i < 15; i++) {
            int numeroDni = (int) (Math.random() * 100000000);
            dni.add(generarLetraDNI(numeroDni));
        }

        return dni;
    }

    public String generarLetraDNI(int dni) {
        String[] letras = {"T", "R", "W", "A", "G", "M", "Y", "F", "P", "D", "X", "B", "N", "J", "Z", "S", "Q", "V", "H", "L", "C", "K", "E"};
        int indice = dni % 23;
        return dni + letras[indice];
    }

    public void comprobarMesasElectorales(){
        for (int i = 0; i < mesasElectorales.size(); i++) {
            if(mesasElectorales.get(i).hayVotos()){
                throw new EleccionYaEmpezadaException("La eleccion ya ha empezado");
            }
        }
    }

    private void comprobarFecha(LocalDate diaVotacion){
        if(diaVotacion.isAfter(LocalDate.now())){
            throw new EleccionNoValidaExcepion("La fecha es incorrecta");
        }
    }

    private void comprobarNumeroDeMesas(){
        if(mesasElectorales.size() > 5){
            throw new NoSeAdmitenMasMesasException("Error el maximo numero de mesas permitidas es 5");
        }
    }

    private void comprobarPartido(Partido partido){
        for (int i = 0; i < partidos.size(); i++) {
            if(partidos.get(i).equals(partido)){
                return;
            }
        }
        throw new VotoInvalidoException("Error el partido " + partido.getCodigo() + " no se encuentra entre los leegibles.");
    }
}