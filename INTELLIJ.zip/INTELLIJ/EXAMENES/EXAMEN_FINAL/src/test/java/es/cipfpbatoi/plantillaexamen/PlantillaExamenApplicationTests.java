package es.cipfpbatoi.plantillaexamen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlantillaExamenApplicationTests {

    @Test
    void contextLoads() {
    }

}
