import java.util.Scanner;

public class Activitat23 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        int multiplesDe2 = 0;
        int multiplesDe5 = 0;
        int numero;

        for (int i = 1; i <= 50; i++){
            System.out.print("Escribe un número entero: ");
            numero = teclado.nextInt();

            if (numero == 100){
                continue;
            }
            if (numero == 0){
                break;
            }

            if (numero % 2 == 0){
                System.out.println("El número " + numero + " és parell");
            } else System.out.print("El número " + numero + " és imparell");
            if (numero % 5 == 0){
                System.out.println(" i multiple de 5.");
            }
        }
    }
}
