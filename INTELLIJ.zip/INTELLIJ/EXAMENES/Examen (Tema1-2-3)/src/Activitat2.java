import java.awt.desktop.ScreenSleepEvent;
import java.util.Scanner;

public class Activitat2 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        boolean esCorrecte;

        int any;

        do {
            System.out.print("Introdueix un any: ");
            any = teclado.nextInt();

            if (any % 2 == 0) {
                esCorrecte = true;
            } else {
                esCorrecte = false;
            }
        }while (esCorrecte);

        if (any % 5 == 0){
            if (any % 11 == 0){
                System.out.println("L'any no es alineat");
            } else {
                System.out.println("L'any es alineat");
            }
        } else {
            if ((any / 100) >= 19 && (any / 100) < 20){
                if ( any % 43 == 0){
                    System.out.println("L'any no es alineat");
                } else {
                    System.out.println("L'any es alineat");
            }
            } else {
                if (any % 11 == 0){
                    System.out.println("L'any no es alineat");
                } else {
                    System.out.println("L'any es alineat");
                }
            }
        }
    }
}