package RepàsExamen;

import java.util.Scanner;

public class PosiblesActivitatsExamen {

    final static int INDEX_INICIAL = 0;
    final static String COMA_ACTIVITAT_4 = ",";
    final static String PARAULA_FI = "fin";
    final static int NUMERO_DE_DIES_MAXIMS = 100;
    final static int NUMERO_MAXIMO_DE_USUARIOS_EXERCISI_3 = 10;
    final static int NUMERO_MAXIMO_DE_NUMEROS_EXERCISI_4 = 10;
    final static int NUMERO_DE_MESES_MAXIMO = 12;
    final static int[] LLISTA_1_EXERCISI_6 = {-30, 10, 13, 80};
    final static int[] LLISTA_2_EXERCISI_6 = {0, 10, 20};
    final static int[] LLISTA_1_EXERCISI_7 = {-30, 10, 13, 80, 20};
    final static int[] LLISTA_2_EXERCISI_7 = {0, 10, 20};
    public static final String COLOR_ROJO = "\u001B[31m";
    public static final String COLOR_RESET = "\u001B[0m";

    public static void main(String[] args) {

        System.out.print(COLOR_ROJO + "ACTIVITAT 1:" + COLOR_RESET);
        activitat1();

        System.out.print(COLOR_ROJO + "\n\nACTIVITAT 2:" + COLOR_RESET);
        activitat2();

        System.out.print(COLOR_ROJO + "\n\nACTIVITAT 3:\n" + COLOR_RESET);
        activitat3();

        System.out.println(COLOR_ROJO + "\nACTIVITAT 4:" + COLOR_RESET);
        activitat4();

        System.out.println(COLOR_ROJO + "\n\nACTIVITAT 5:" + COLOR_RESET);
        activitat5();

        System.out.println(COLOR_ROJO + "\n\nACTIVITAT 6:" + COLOR_RESET);
        activitat6();

        System.out.println(COLOR_ROJO + "\n\nACTIVITAT 7:" + COLOR_RESET);
        activitat7();

        System.out.println(COLOR_ROJO + "\n\nACTIVITAT 8:" + COLOR_RESET);
        activitat8();
    }

    //************************************************ Activitat 1 ************************************************\\

    public static void activitat1(){

        String[] array = {"LMSG", "INGLES", "PROG", "SI", "BASES DE DATOS", "FOL", "EDD"};

        System.out.print("\nArray desordenada: ");
        visualizarArray(array);

        System.out.print("\nArray ordenada: ");
        visualizarArray(ordenarPerSeleccio(array));
    }

    public static String[] ordenarPerSeleccio(String[] vector){
        for (int i = INDEX_INICIAL; i < vector.length - 1; i++) {
            int elementMenor = i;
            for (int j = i + 1; j < vector.length; j++) {
                if (vector[j].compareTo(vector[elementMenor]) < 0){
                    elementMenor = j;
                }

                if(elementMenor != i){
                    String aux = vector[elementMenor];
                    vector[elementMenor] = vector[i];
                    vector[i] = aux;
                }
            }
        }

        return vector;
    }

    //************************************************ Activitat 2 ************************************************\\

    public static void activitat2(){
        String[] cadena = {"ENERO", "MARZO", "FEBRERO", "MAYO", "ABRIL", "JULIO", "JUNIO",
                "OCTUBRE", "SEPTIEMBRE", "AGOSTO", "DICIEMBRE", "NOVIEMBRE"};

        System.out.print("\nMeses desordenados: ");
        visualizarArray(cadena);

        System.out.println("\nOrdenando por intercambio...");

        System.out.print("Meses ordenados: ");
        visualizarArray(pasarDeNumeroAMes(ordenarArray(arrayNumMes(cadena))));

    }

    public static void visualizarArray(String[] array){

        for (int i = INDEX_INICIAL; i < array.length; i++){
            if (i != array.length - 1){
                System.out.print(array[i] + ", ");
            } else {
                System.out.print(array[i]);
            }
        }
    }

    public static String[] pasarDeNumeroAMes(int[] cadenaNumMes){

        String[] cadenaMessosOrdenats = {"ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO",
                "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"};
        String[] cadenaOrdenada = new String[NUMERO_DE_MESES_MAXIMO];

        for(int i = INDEX_INICIAL; i < cadenaNumMes.length; i++){
            cadenaOrdenada[i] = cadenaMessosOrdenats[cadenaNumMes[i] - 1];
        }

        return cadenaOrdenada;
    }

    public static int[] arrayNumMes(String[] cadena) {

        int[] arrayNum = new int[NUMERO_DE_MESES_MAXIMO];

        for (int i = INDEX_INICIAL; i < cadena.length; i++){
            arrayNum[i] = obtenerNumeroMes(cadena[i]);
        }

        return arrayNum;
    }

    public static int obtenerNumeroMes(String mes){

        String [] cadenaMessos = {"ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO",
                "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"};

        for ( int i = INDEX_INICIAL; i < cadenaMessos.length; i++){
            if(mes.equalsIgnoreCase(cadenaMessos[i])){
                return i + 1;
            }
        }

        return -1;
    }

    public static int[] ordenarArray(int[] vector){
        int aux;
        for ( int i = INDEX_INICIAL; i < vector.length; i++){
            for( int j = i + 1; j < vector.length; j++){
                if (vector[j] < vector[i]){
                    aux = vector[i];
                    vector[i] = vector[j];
                    vector[j] = aux;
                }
            }
        }

        return vector;
    }

    //************************************************ Activitat 3 ************************************************\\

    public static void activitat3(){

        int[] array = new int[NUMERO_MAXIMO_DE_USUARIOS_EXERCISI_3];

        for (int i = 1; i <= NUMERO_MAXIMO_DE_USUARIOS_EXERCISI_3; i++){
            System.out.printf("Introduzca los puntos para el usuario %d: ", i);
            array[i - 1] = pedirNumeroEntero();
        }

        int[] arrayOrdenada = ordenararray(array);

        System.out.println("\nRanking Juego: \n");
        for (int i = INDEX_INICIAL; i < arrayOrdenada.length; i++){
            System.out.printf( (NUMERO_MAXIMO_DE_USUARIOS_EXERCISI_3 - i) +".- " + arrayOrdenada[9 - i] + "\n");
        }
    }

    public static int pedirNumeroEntero(){

        Scanner teclado = new Scanner(System.in);

        do{
            if(!teclado.hasNextInt()){
                System.out.println("Introduce un numero.");
            } else {
                return teclado.nextInt();
            }

            teclado.next();

        } while (true);
    }

    public static int[] ordenararray(int[] vector){
        int aux;
        for ( int i = INDEX_INICIAL; i < vector.length; i++){
            for( int j = i + 1; j < vector.length; j++){
                if (vector[j] < vector[i]){
                    aux = vector[i];
                    vector[i] = vector[j];
                    vector[j] = aux;
                }
            }
        }

        return vector;
    }

    //************************************************ Activitat 4 ************************************************\\
    public static void activitat4(){

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduzca 10 números: ");
        String cadena = teclado.next();

        double[] array = crearArrayAPartirDeUnString(cadena);

        System.out.printf("El elemento más pequeño es: " + visualizarMinimo(array));
        System.out.printf("\nEl elemento más grande es: " + visualizarMaximo(array));

    }

    public static double visualizarMaximo(double[] array){

        double numeroMaximo = array[INDEX_INICIAL];

        for (int i = 1; i < array.length; i++){

            if(numeroMaximo < array[i]){
                numeroMaximo = array[i];
            }
        }

        return numeroMaximo;
    }

    public static double visualizarMinimo(double[] array){

        double numeroMinimo = array[INDEX_INICIAL];

        for (int i = 1; i < array.length; i++){

            if(numeroMinimo > array[i]){
                numeroMinimo = array[i];
            }
        }

        return numeroMinimo;
    }

    public static double[] crearArrayAPartirDeUnString(String cadena){

        double[] array = new double[10];
        int posicioInicial = INDEX_INICIAL;

        for(int i = INDEX_INICIAL; i < cadena.length() - 1;i++){
            if(COMA_ACTIVITAT_4.equalsIgnoreCase(String.valueOf(cadena.charAt(i)))){
                array[i] = Double.parseDouble(cadena.substring(posicioInicial, i));
                posicioInicial = i + 2;
            }
        }

        return array;
    }



    //************************************************ Activitat 5 ************************************************\\

    public static void activitat5(){

        int[] array = generadorDeArrays();

        System.out.print("Array sin invertir: ");
        visualizarArray(array);

        System.out.println("\nInvirtiendo array...");

        System.out.print("Array invertido: ");
        visualizarArray(invertirArray(array));
    }

    public static int[] invertirArray (int [] array){
        int[] arrayInvertida = new int[array.length];

        for (int i = INDEX_INICIAL; i < array.length; i++){
            arrayInvertida[i] = array[(array.length -1) - i];
        }

        return arrayInvertida;
    }

    public static void visualizarArray(int[] array){

        System.out.print("[");

        for (int i = INDEX_INICIAL; i < array.length; i++){

            if (i != array.length - 1){
                System.out.print(array[i] + ", ");
            } else {
                System.out.print(array[i]);
            }
        }

        System.out.print("]");

    }

    public static int[] generadorDeArrays(){

        int[] arrayGenerada = new int[10];

        for (int i = INDEX_INICIAL; i < arrayGenerada.length; i++){

            int numAleatorio = (int) (Math.random()*100+0);

            arrayGenerada[i] = numAleatorio;
        }

        return arrayGenerada;
    }

    //************************************************ Activitat 6 ************************************************\\

    public static void activitat6(){

        int[] llista1 = LLISTA_1_EXERCISI_6;
        int[] llista2 = LLISTA_2_EXERCISI_6;

        System.out.print("Lista 1: ");
        visualizarArray(llista1);

        System.out.print("\nLista 2: ");
        visualizarArray(llista2);

        System.out.print("\nResultado = ");
        visualizarArray(ordenarArray(juntarDosArrays(llista1,llista2)));
    }

    public static int[] juntarDosArrays(int[] llista1, int[] llista2){

        int[] llistaJunta = new int[llista1.length + llista2.length];
        int posicio = INDEX_INICIAL;

        for (int i = INDEX_INICIAL; i < llistaJunta.length; i++){
            if(i < llista1.length){
                llistaJunta[i] = llista1[i];
            } else {
                llistaJunta[i] = llista2[posicio];
                posicio++;
            }
        }

        return llistaJunta;
    }

    //************************************************ Activitat 7 ************************************************\\

    public static void activitat7(){

        int[] llista1 = LLISTA_1_EXERCISI_7;
        int[] llista2 = LLISTA_2_EXERCISI_7;

        System.out.print("Lista 1: ");
        visualizarArray(llista1);

        System.out.print("\nLista 2: ");
        visualizarArray(llista2);

        llista1 = ordenarArray(llista1);
        llista2 = ordenarArray(llista2);

        System.out.print("\nResultado = ");
        visualizarArray(invertirArray(ordenarArray(generarArrayComunesEntreDosArrays(llista1,llista2))));
    }

    public static int[] generarArrayComunesEntreDosArrays(int[] llista1, int[] llista2){

        int[] llistaJunta = new int[llista1.length + llista2.length];
        int posicio = INDEX_INICIAL;

        for (int i = 0; i < llista1.length; i++){
            for (int j = 0; j < llista2.length; j++){
                if(llista1[i] == llista2[j]){
                    llistaJunta[posicio] = llista2[j];
                    posicio++;
                }
            }
        }

        return llistaJunta;
    }

//************************************************ Activitat 8 ************************************************\\

    public static void activitat8(){

        int contadorIndex = 1;
        boolean comprovador = true;
        String[] cadenaNombres = new String[NUMERO_DE_DIES_MAXIMS];

        System.out.print("Introduxa los nombres de los compradores: ");
        cadenaNombres[INDEX_INICIAL] = pedirNombre();

        do{

            String nom = pedirNombre();

            if(nom.equalsIgnoreCase(PARAULA_FI)){
                comprovador = false;
            } else {
                cadenaNombres = generadorDeLaCadena(nom, contadorIndex, cadenaNombres);
                contadorIndex++;
            }

        } while(comprovador);

        cadenaNombres = ordenarPerSeleccio(generarArray(cadenaNombres, contadorIndex));

        System.out.print("Comprovadores: ");
        visualizarArray(cadenaNombres);

    }

    public static String[] generarArray(String[] cadenaNoms, int index){
        String [] cadenaModificada = new String[index];

        for(int i = INDEX_INICIAL; i < cadenaModificada.length; i++){
            cadenaModificada[i] = cadenaNoms[i];
        }

        return cadenaModificada;
    }

    public static String[] generadorDeLaCadena(String nom, int index, String[] cadenaNoms){

        cadenaNoms[index] = nom;
        return cadenaNoms;
    }

    public static String pedirNombre(){

        Scanner teclado = new Scanner(System.in);

        do{
            if(!teclado.hasNext()){
                System.out.println("Inserta un nombre.");
            } else {
                return teclado.next();
            }

            teclado.next();

        } while(true);
    }
}