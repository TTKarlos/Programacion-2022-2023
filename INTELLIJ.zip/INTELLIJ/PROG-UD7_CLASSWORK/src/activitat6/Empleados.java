package activitat6;

public class Empleados {
    private String nombre;
    private String apellidos;
    private String dni;
    private String fechaDeInicio;
    private String telefono;
    private double salario;

    public Empleados(String nombre, String apellidos, String dni, String fechaDeInicio, String telefono, double salario){
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
        this.fechaDeInicio = fechaDeInicio;
        this.telefono = telefono;
        this.salario = salario;
    }

    public void incrementarSalario(){
        this.salario = salario + (salario * 0.05);
    }

    @Override
    public String toString() {
        return "nombre: " + nombre + ", apellidos: " + apellidos + ", dni: " + dni + ", sueldo: " + salario;
    }
}
