package activitat15;

import activitat13.Fecha;

public class TestPersona {
    public static void main(String[] args) {
        Fecha fechaNacimiento = new Fecha("12/08/1990");
        NIF nif = new NIF(216525612);
        Direccion direccion = new Direccion("España", "Alicante", "Alcoy", "Avda. Hispanidad, 2");
                Persona person = new Persona(nif, "Pepe", "García", "Sánchez", fechaNacimiento, direccion);
        System.out.print("¿Es mayor de edad?: ");
        if(person.esMayorDeEdad()){
            System.out.println("Si");
        } else {
            System.out.println("No");
        }

        System.out.print("¿Esta jubilado?: ");
        if(person.estaJubilado()){
            System.out.println("Si");
        } else {
            System.out.println("No");
        }
    }
}