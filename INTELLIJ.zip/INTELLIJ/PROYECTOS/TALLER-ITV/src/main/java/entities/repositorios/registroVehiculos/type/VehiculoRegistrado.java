package entities.repositorios.registroVehiculos.type;

import java.time.LocalDate;
import java.util.Objects;

public class VehiculoRegistrado {
    private int codigo;
    private String matriculaVehiculo;
    private LocalDate fechaRevision;
    private String dniMecanico;
    private double importe;

    public VehiculoRegistrado(int codigo, String matriculaVehiculo, LocalDate fechaRevision, String dniMecanico, double importe) {
        this.codigo = codigo;
        this.matriculaVehiculo = matriculaVehiculo;
        this.fechaRevision = fechaRevision;
        this.dniMecanico = dniMecanico;
        this.importe = importe;
    }

    public VehiculoRegistrado(String matriculaVehiculo, LocalDate fechaRevision, String dniMecanico, double importe) {
        this.codigo = -1;
        this.matriculaVehiculo = matriculaVehiculo;
        this.fechaRevision = fechaRevision;
        this.dniMecanico = dniMecanico;
        this.importe = importe;
    }

    public LocalDate getFechaRevision() {
        return fechaRevision;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getCodigo() {
        return codigo;
    }

    public double getImporte() {
        return importe;
    }

    public String getDniMecanico() {
        return dniMecanico;
    }

    public String getMatriculaVehiculo() {
        return matriculaVehiculo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof VehiculoRegistrado that)) return false;
        return Double.compare(that.importe, importe) == 0 && Objects.equals(matriculaVehiculo,
                that.matriculaVehiculo) && Objects.equals(getFechaRevision(), that.getFechaRevision()) &&
                Objects.equals(dniMecanico, that.dniMecanico);
    }
}