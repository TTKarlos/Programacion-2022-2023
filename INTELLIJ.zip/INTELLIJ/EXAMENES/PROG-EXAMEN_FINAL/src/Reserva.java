import java.time.LocalDateTime;
import java.util.Objects;

public class Reserva {
    private int codigo;
    private String usuario;
    private int numeroDePlazasSolicitadas;
    private LocalDateTime fechaDeCreacion;

    public Reserva(int codigo, String usuario, int numeroDePlazasSolicitadas) {
        this.codigo = codigo;
        this.usuario = usuario;
        this.numeroDePlazasSolicitadas = numeroDePlazasSolicitadas;
        this.fechaDeCreacion = LocalDateTime.now();
    }

    public Reserva(int codigo){
        this.codigo = codigo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        Reserva reserva = (Reserva) o;
        return codigo == reserva.codigo;
    }
}