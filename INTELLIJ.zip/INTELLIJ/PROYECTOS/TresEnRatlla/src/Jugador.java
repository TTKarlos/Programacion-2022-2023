import javax.swing.*;
import java.util.Scanner;

public abstract class Jugador {
    final static String COLOR_ROJO = "\u001B[31m";
    final static String COLOR_AMARILLO = "\u001B[33m";
    final static String RESET_COLOR = "\u001B[0m";
    final static String TEXTO_ERROR_CORDENADA = COLOR_ROJO + "¡Error! " + RESET_COLOR + "Coordenada ocupada en el tablero";
    final static String TEXTO_CORDENADA_INVALIDA = COLOR_ROJO + "¡Error! " + RESET_COLOR + "Introduce una coordenada válida";
    final static String TEXTO_NUMERO_ENTERO_INVALIDO = COLOR_ROJO + "¡Error! " + RESET_COLOR + "Debe introducir un número entero";
    private EstadoCasilla estadoCasilla;
    private Icono icono;

    public Jugador(EstadoCasilla estadoCasilla, Icono icono){
        this.estadoCasilla = estadoCasilla;
        this.icono = icono;
    }

    public EstadoCasilla getEstadoCasilla() {
        return estadoCasilla;
    }

    public void cantarVictoria(){
        System.out.printf(COLOR_AMARILLO + "¡CAMPEONESSS! Los%sson los mejores%s\n\n",
                icono.obtenerSimbolo(estadoCasilla), RESET_COLOR);
    }

    public void ponerFicha(Tablero tablero){
    }
}