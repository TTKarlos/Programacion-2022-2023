public class Activitat15 {

    public static void main(String[] args) {

        int comtador = 48;

        while (comtador < 100){
            System.out.print(comtador + ", ");
            comtador = comtador +2;
        }
        System.out.print("100");
    }
}
