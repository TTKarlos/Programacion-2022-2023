package tienda_de_electrodomesticos;

public class Ordenador extends TomaCorriente implements Conectable {
    private int ram;
    private float velocidadCPU;
    private int capacidadDelDiscoDuro;
    private float precioBase;
    private String numeroDeSerie;
    private float precioVenta;
    private boolean estaEncendido;

    public Ordenador(int ram, float velocidadCPU, int tmanyoDeDiscoDuro, float precioBase,
                     String numeroDeSerie, float precioVenta) {
        this.ram = ram;
        this.velocidadCPU = velocidadCPU;
        this.capacidadDelDiscoDuro = tmanyoDeDiscoDuro;
        this.precioBase = precioBase;
        this.numeroDeSerie = numeroDeSerie;
        this.precioVenta = precioVenta;
        this.estaEncendido = false;

    }

    @Override
    public String toString() {
        return "[Computer]  Ram: " + ram + ", Velocidad CPU: " + velocidadCPU + ", Capacidad del HDD: " +
                capacidadDelDiscoDuro + ", Precio Base: " + precioBase + ", Precio venta: " + precioVenta +
                ", Power: " + estaEncendido;
    }

    @Override
    public void encender() {
        this.estaEncendido = true;
    }

    @Override
    public void apagar() {
        this.estaEncendido = false;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Ordenador)){
            return false;
        }

        Ordenador ordenador = (Ordenador) obj;
        return numeroDeSerie.equalsIgnoreCase(ordenador.numeroDeSerie);
    }
}