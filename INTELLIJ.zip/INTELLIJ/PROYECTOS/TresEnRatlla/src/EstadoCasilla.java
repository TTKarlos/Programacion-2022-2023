public enum EstadoCasilla {
    FICHA_X,
    FICHA_O,
    FICHA_VACIA {
        public String toString() {
            return " \u2B1B ";
        }
    }
}