package entities;

import exceptions.FaseOcupadaException;
import entities.vehiculos.Vehiculo;
import exceptions.SinMecanicoException;
import exceptions.VehiculoNoExisteException;
import utils.GestioIO;
import java.time.LocalDate;

public class Box {
    private final static int INDICE_INCIAL = 0;
    private final static int MAXIMO_VEHICULOS = 4;
    private final static int NUM_VEHICULO_NO_ENCONTRADO = -1;
    private final static String[] FASES = {
            "Revisión de elementos de seguridad", "Revisión del sistema eléctrico",
            "Revisión de emisión de humos", "Revisión de frenos y de dirección"};
    private int posicionMecanico;
    private Mecanico mecanico;
    private Vehiculo[] vehiculos;

    public Box(Mecanico mecanico) {
        this.posicionMecanico = INDICE_INCIAL;
        this.mecanico = mecanico;
        this.vehiculos = new Vehiculo[MAXIMO_VEHICULOS];
    }

    public Vehiculo[] getVehiculos() {
        return vehiculos;
    }

    public String[] getFASES() {
        return FASES;
    }

    public int getPosicionMecanico() {
        return posicionMecanico;
    }

    public Mecanico getMecanico() {
        return mecanico;
    }

    public void setPosicionMecanico(int posicionMecanico) {
        this.posicionMecanico = posicionMecanico;
    }

    public void reclamarVehiculo(Vehiculo vehiculo) throws FaseOcupadaException {
        estaOcupadaLaFase(INDICE_INCIAL);
        this.vehiculos[INDICE_INCIAL] = vehiculo;
        GestioIO.mostrarTextoEnVerde("Se ha añadido correctamente a la Fase 1: " + FASES[INDICE_INCIAL]);
    }

    public Vehiculo moverVehiculoDeFase(String plate) throws FaseOcupadaException, SinMecanicoException {
        int posicionVehiculo = getVehiculoPosition(plate);
        elVehiculoExiste(posicionVehiculo);
        Vehiculo vehiculo = vehiculos[posicionVehiculo];

        if(posicionVehiculo == (FASES.length - 1)){
            GestioIO.mostrarTextoEnVerde("MATRICULA-> " + vehiculo.getMatricula() + "\nEl vehiculo ha salido de la BOX");
            vehiculo.setFechaUltimaRevision(LocalDate.now());
            this.vehiculos[posicionVehiculo] = null;
            return vehiculo;
        }

        estaOcupadaLaFase(posicionVehiculo + 1);
        estaElMecanicoEnLaFase(posicionVehiculo + 1);

        this.vehiculos[posicionVehiculo] = null;
        this.vehiculos[posicionVehiculo + 1] = vehiculo;
        GestioIO.mostrarTextoEnVerde("MATRICULA-> " + vehiculo.getMatricula() + "\nFASE " + (posicionVehiculo + 1) +
                "-> " + FASES[posicionVehiculo + 1] + "\nBOX: Sigue en el box");
        return null;
    }

    public int numVehiculos(){
        int contador = 0;
        for (int i = INDICE_INCIAL; i < vehiculos.length; i++) {
            if(vehiculos[i] != null){
                contador++;
            }
        }

        return contador;
    }

    private int getVehiculoPosition(String plate){
        for (int i = INDICE_INCIAL; i < vehiculos.length; i++) {
            if(vehiculos[i].getMatricula().equalsIgnoreCase(plate)){
                return i;
            }
        }

        return NUM_VEHICULO_NO_ENCONTRADO;
    }

    private void elVehiculoExiste(int position){
        if(position == NUM_VEHICULO_NO_ENCONTRADO){
            throw new VehiculoNoExisteException();
        }
    }

    private void estaOcupadaLaFase(int posicion) throws FaseOcupadaException {
        if(vehiculos[posicion] != null){
            throw new FaseOcupadaException();
        }
    }

    private void estaElMecanicoEnLaFase(int posicion) throws SinMecanicoException {
        if(posicion != posicionMecanico){
            throw new SinMecanicoException(posicion + 1);
        }
    }
}