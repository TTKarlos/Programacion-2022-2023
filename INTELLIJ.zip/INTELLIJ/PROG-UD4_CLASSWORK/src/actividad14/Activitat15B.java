package actividad14;

import java.util.Scanner;

public class Activitat15B {

    final static float EUROS_A_LIBRAS = 0.86f;
    final static float EUROS_A_DOLARES = 1.28611f;
    final static float EUROS_A_YENES = 129.852f;

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introdueix els diners: ");
        float diners = teclado.nextFloat();
        String moneda = teclado.next();
        dinersContador(diners, moneda);
    }

    public static void dinersContador(float diners, String moneda){

        switch (moneda){
            case "yenes" -> {
                diners = diners / EUROS_A_YENES;
                System.out.println(diners + "€");
            }
            case "dolares" -> {
                diners = diners / EUROS_A_DOLARES;
                System.out.println(diners + "€");
            }
            case "libras" -> {
                diners = diners / EUROS_A_LIBRAS;
                System.out.println(diners + "€");
            }
        }
    }
}