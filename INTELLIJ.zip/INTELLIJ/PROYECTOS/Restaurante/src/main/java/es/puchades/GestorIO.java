package es.puchades;

import es.puchades.exceptions.NoEncontradoException;
import es.puchades.pedido.Pedido;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class GestorIO {
    public final static String COLOR_AZUL = "\u001B[34m";
    public final static String RESET_COLOR = "\u001B[0m";
    public final static String COLOR_VERDE = "\u001B[32m";
    public final static String COLOR_ROJO = "\u001B[31m";
    public final static String TEXTO_ERROR_INTRODUCIR_FECHA = "Introduce una fecha correcta y siguiendo el estandard";
    public final static String TEXTO_MENU = String.format("%s1.%s Crear Nuevo Pedido\n%s2. %sListar Todos los Pedidos" +
                    "\n%s3. %sVisualizar Orden\n%s4.%s Preparar Pedido\n%s5.%s Cancelar un Pedido\n%s6.%s Salir\n",
            COLOR_ROJO, RESET_COLOR, COLOR_ROJO, RESET_COLOR, COLOR_ROJO, RESET_COLOR, COLOR_ROJO, RESET_COLOR,
            COLOR_ROJO, RESET_COLOR, COLOR_ROJO, RESET_COLOR);

    final static String HORA_POR_DEFECTO = "8:00:00";
    final static String OPCION_SI = "si";
    final static String OPCION_NO = "no";
    final static String FORMATO_DE_FECHA = "d/MM/uuuu";
    final static String TEXTO_ERROR_SI_O_NO = "Error! Introduce Si o No";
    final static String TEXTO_INTRODUCIR_FECHA = "Introduxca la fecha actual en formato dd/mm/yyyy: ";
    final static String TEXTO_NO_EXISTE_PEDIDO = "Error! El pedido no existe";
    final static String TEXTO_CAMBIAR_FECHA = "Quieres cambiar la fecha? -> ";

    public static int elegirUnNumero(int indexInicial, int indexFinal, String textoError, String texto) {
        Scanner teclado = new Scanner(System.in);

        do {
            GestorIO.mostrarTextoEnAzul(texto);

            try {
                int numElegido = teclado.nextInt();

                if (comprobarNumero(numElegido, indexInicial, indexFinal)) {
                    return numElegido;
                }
            } catch (InputMismatchException e){
                teclado.next();
                GestorIO.mostrarTextoEnError(textoError);
            }
        } while (true);
    }

    public static Pedido elegirUnPedido(String textoError, ArrayList<Pedido> listaPedidos){
        Scanner teclado = new Scanner(System.in);

        do {
            System.out.printf("Elige un pedido [%s]: ", getNumerosDePedidos(listaPedidos));

            try{
                int identificador = teclado.nextInt();
                Pedido pedidoElegido = estaElPedido(listaPedidos, identificador);

                if(comprobarPedido(pedidoElegido)){
                    return pedidoElegido;
                }
            } catch (Exception e){
                GestorIO.mostrarTextoEnError(textoError);
                teclado.nextLine();
            }
        } while (true);
    }

    public static Pedido estaElPedido(ArrayList<Pedido> listaPedidos, int identificador){
        for (int i = 0; i < listaPedidos.size(); i++) {
            if(listaPedidos.get(i).getIdentificador() == identificador){
                return listaPedidos.get(i);
            }
        }

        return null;
    }

    public static String pedirTexto(String texto) {
        Scanner teclado = new Scanner(System.in);
        GestorIO.mostrarTextoEnAzul(texto);
        return teclado.next();
    }

    public static boolean pediSiONo(String mensaje){
        Scanner teclado = new Scanner(System.in);

        do {
            GestorIO.mostrarTextoEnAzul(mensaje);

            String palabra = teclado.next();

            try {
                if(palabra.equalsIgnoreCase(OPCION_SI)){
                    return true;
                } else if (palabra.equalsIgnoreCase(OPCION_NO)) {
                    return false;
                } else {
                    throw new InputMismatchException(TEXTO_ERROR_SI_O_NO);
                }
            } catch (InputMismatchException e){
                GestorIO.mostrarTextoEnError(e.getMessage());
            }
        } while (true);
    }

    public static String getFechaYHora(){
        System.out.println(fechaYHoraAutomatica());

        if(!pediSiONo(TEXTO_CAMBIAR_FECHA)){
            return fechaYHoraAutomatica();
        } else {
            return pedirFecha(TEXTO_INTRODUCIR_FECHA) + "\n" + HORA_POR_DEFECTO;
        }
    }

    public static String pedirFecha(String texto) {
        Scanner teclado = new Scanner(System.in);

        do {
            GestorIO.mostrarTextoEnAzul(texto);
            String fecha = teclado.next();
            Fecha fecha1 = new Fecha(fecha);

            try {
                if (comprobarFecha(fecha1)) {
                    return fecha;
                }
            } catch (InputMismatchException e){
                GestorIO.mostrarTextoEnError(e.getMessage());
            }
        } while (true);
    }

    public static void mostrarTextoEnError(String texto){
        System.out.println(COLOR_ROJO + texto + RESET_COLOR);
    }

    public static void mostrarTextoEnVerde(String texto){
        System.out.println(COLOR_VERDE + texto + RESET_COLOR);
    }

    public static void mostrarTextoEnAzul(String texto){
        System.out.print(COLOR_AZUL + texto + RESET_COLOR);
    }

    public static String tornarPreuEnFormato(float preu){
        return String.format("%.2f€", preu);
    }

    public static String tornarDescuentoEnFormato(float descuento){
        return String.format("%.2f%%", descuento);
    }

    private static String fechaYHoraAutomatica(){
        DateTimeFormatter formato = DateTimeFormatter.ofPattern(FORMATO_DE_FECHA);
        return LocalDate.now().format(formato) + "\n" + String.valueOf(LocalTime.now()).substring(0, 8);
    }

    private static boolean comprobarFecha(Fecha fecha){
        if (fecha.isCorrecta()) {
            return true;
        } else {
            throw new InputMismatchException(TEXTO_ERROR_INTRODUCIR_FECHA);
        }
    }

    private static boolean comprobarNumero(int numElegido, int indexInicial, int indexFinal){
        if (numElegido >= indexInicial && numElegido <= indexFinal) {
            return true;
        } else {
            throw new InputMismatchException();
        }
    }

    private static boolean comprobarPedido(Pedido pedido){
        if (pedido != null) {
            return true;
        } else {
            throw new NoEncontradoException(TEXTO_NO_EXISTE_PEDIDO);
        }
    }

    private static StringBuilder getNumerosDePedidos(ArrayList<Pedido> listaPedidos){
        StringBuilder cadena = new StringBuilder();

        for (int i = 0; i < listaPedidos.size(); i++) {
            cadena.append(listaPedidos.get(i).getIdentificador() + ",");
        }

        return cadena.append("\b");
    }
}