import exception.ReservaNoEncontradaException;
import exception.ReservaNoValidaException;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class Viaje {
    private String codigo;
    private String ruta;
    private LocalDateTime fechayHoraDeEmpezar;
    private float precio;
    private int duracionEnDias;
    private int plazasOferidas;
    private int plazasReservadas;
    protected ArrayList<Reserva> listaReservas;
    private boolean estaCancelado;

    public Viaje(String codigo, String ruta, LocalDateTime fechayHoraDeEmpezar, float precio, int duracionEnDias,
                 int plazasOferidas) {
        this.codigo = codigo;
        this.ruta = ruta;
        this.fechayHoraDeEmpezar = fechayHoraDeEmpezar;
        this.precio = precio;
        this.duracionEnDias = duracionEnDias;
        this.plazasOferidas = plazasOferidas;
        this.plazasReservadas = 0;
        this.estaCancelado = false;
    }

    public Viaje(String codigo, String ruta, LocalDateTime fechayHoraDeEmpezar, float precio, int duracionEnDias) {
        this.codigo = codigo;
        this.ruta = ruta;
        this.fechayHoraDeEmpezar = fechayHoraDeEmpezar;
        this.precio = precio;
        this.duracionEnDias = duracionEnDias;
        this.plazasOferidas = ((int) (Math.random()*6)) + 5;
        this.plazasReservadas = 0;
        this.estaCancelado = false;
    }

    public void realizarReserva(String nombreCompleto, int numeroDePlazasSolicitadas){
        try{
            sePuedeReservar(numeroDePlazasSolicitadas);

            listaReservas.add(new Reserva(listaReservas.size() + 1, nombreCompleto, numeroDePlazasSolicitadas));
            plazasReservadas += numeroDePlazasSolicitadas;
            plazasOferidas -= numeroDePlazasSolicitadas;
        } catch (ReservaNoValidaException e){
            System.out.println(e.getMessage());
        }
    }
    
    public Reserva getReserva(int codReserva) throws ReservaNoEncontradaException{
        existeLaReserva(codReserva);
        return listaReservas.get(getIndexReserva(codReserva));
    }

    public Viaje(String codigo){
        this.codigo = codigo;
    }

    public String getRuta() {
        return ruta;
    }

    public LocalDateTime getFechayHoraDeEmpezar() {
        return fechayHoraDeEmpezar;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setEstaCancelado(boolean estaCancelado) {
        this.estaCancelado = estaCancelado;
    }

    @Override
    public String toString() {
        return "Viaje -> " +
                "codigo='" + codigo +
                ", ruta='" + ruta +
                ", fechayHoraDeEmpezar=" + fechayHoraDeEmpezar +
                ", precio=" + precio +
                ", duracionEnDias=" + duracionEnDias +
                ", plazasOferidas=" + plazasOferidas +
                ", plazasReservadas=" + plazasReservadas +
                ", listaReservas=" + listaReservas +
                ", estaCancelado=" + estaCancelado;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Viaje)){
            return false;
        }

        Viaje viaje = (Viaje) o;
        return codigo.equals(viaje.codigo);
    }

    private int getIndexReserva(int codReserva){
        Reserva reserva = new Reserva(codReserva);

        for (int i = 0; i < listaReservas.size(); i++) {
            if(listaReservas.get(i).equals(reserva)){
                return i;
            }
        }

        return -1;
    }
    
    private boolean laFechaParaReservarEsCorrecta(){
        return fechayHoraDeEmpezar.isBefore(LocalDateTime.now());
    }

    private void sePuedeReservar(int numeroDePlazasSolicitadas){
        if(plazasOferidas >= numeroDePlazasSolicitadas && !estaCancelado && laFechaParaReservarEsCorrecta()){
        } else {
            throw new ReservaNoValidaException();
        }
    }
    
    private void existeLaReserva(int codReserva) throws ReservaNoEncontradaException{
        if(getIndexReserva(codReserva) == -1){
            throw new ReservaNoEncontradaException(codReserva);
        }
    }
}