public class Activitat14 {

    public static void main(String[] args) {

        int comtador = 0;
        while (comtador <= 10){
            System.out.print(comtador + ", ");
            comtador++;
        }
        System.out.println("Preparant la partida...");
    }
}
