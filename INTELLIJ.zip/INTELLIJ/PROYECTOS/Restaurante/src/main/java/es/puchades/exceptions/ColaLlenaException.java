package es.puchades.exceptions;

public class ColaLlenaException extends RuntimeException{
    public ColaLlenaException(int numPedidosMaximos){
        super("No puedes tener mas de " + numPedidosMaximos + " pedidos en pendientes");
    }
}