public class Activitat10 {
    public static void main(String[] args) {
        System.out.println("Primer sense ordenar");
        int[] vector1 = generararray(10);
        mostrarArray(vector1);
        System.out.println("\nPrimer ordenat");
        mostrarArray(ordenararray(vector1));

    }
    public static int[] generararray(int tamanyo){
        int[] array = new int[tamanyo];
        for (int i = 0; i <= tamanyo - 1; i++){
            array[i] = (int) (Math.random() * 9 + 0);
        }
        return array;
    }
    public static int[] ordenararray(int[] vector){
        int aux;
        for ( int i = 0; i < vector.length; i++){
            for( int j = i + 1; j < vector.length; j++){
                if (vector[j] < vector[i]){
                    aux = vector[i];
                    vector[i] = vector[j];
                    vector[j] = aux;
                }
            }
        }
        return vector;
    }

    public static void mostrarArray(int[] vector){
        for(int numN: vector) {
            System.out.print(numN + " ");
        }
    }
}