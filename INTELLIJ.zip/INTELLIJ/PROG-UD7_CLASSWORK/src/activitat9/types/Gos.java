package activitat9.types;

import activitat9.Animal;
import activitat9.Mascota;
import activitat9.enums.Comida;
import activitat9.enums.Tamany;

public class Gos extends Animal implements Mascota {
    public  Gos(boolean vacunado, Comida comida, int hambre, Tamany tamanio, String localizacion){
        super(vacunado, comida, hambre, tamanio, localizacion);
    }

    public void emitirSonido(){
        System.out.println("GUAU!!!");
    }

    public void vacunar(){
        System.out.println("Vacunando a un Perro...");
        super.vacunar();
        emitirSonido();
    }

    @Override
    public String toString() {
        return "Perro: " + super.toString();
    }

    @Override
    public void Mascota() {

    }

    @Override
    public void jugar() {

    }
}