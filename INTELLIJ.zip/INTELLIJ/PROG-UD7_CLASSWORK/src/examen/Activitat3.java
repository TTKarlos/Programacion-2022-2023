package examen;

import java.util.Arrays;
import java.util.Scanner;

public class Activitat3 {

    public static void main(String[] args) {
        String[] palabras = anadirPalabras();
        imprimirArray(ordenarArray(palabras));
    }

    public static String[] anadirPalabras(){
        Scanner teclado = new Scanner(System.in);
        String[] almacenPalabras = new String[20];

        String palabra;
        int contador = 1;
        do {
            System.out.printf("Introduce el nombre %d: ", contador);
            palabra = teclado.nextLine();

            if (comprobarTamanoPalabra(palabra)){
                for (int i = almacenPalabras.length - 1; i > 0; i--) {
                    almacenPalabras[i] = almacenPalabras[i-1];
                }
                almacenPalabras[0] = palabra;
            } else if (!palabra.equalsIgnoreCase("fin")) {
                System.out.print("¡Error! Debe contener al menos 4 carácteres\n");
            }
            contador++;
        } while (!palabra.equalsIgnoreCase("fin"));
        return almacenPalabras;
    }
    public static String[] ordenarArray(String[] array) {
        for (int i = 0; i < array.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < array.length; j++) {
                if (array[j] != null && array[j].compareTo(array[minIndex]) < 0) {
                    minIndex = j;
                }
            }
            String array2 = array[i];
            array[i] = array[minIndex];
            array[minIndex] = array2;
        }

        return array;
    }
    public static void imprimirArray(String[] array){
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            if(array[i] != null){
                System.out.print(array[i] + ", ");
            }
        }
        System.out.print("]");
    }

    public static boolean comprobarTamanoPalabra(String palabra){
        return palabra.length() >= 4;
    }

}
