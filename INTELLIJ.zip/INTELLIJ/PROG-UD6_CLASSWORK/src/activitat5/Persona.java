package activitat5;

public class Persona {

    private String nombre;
    private String apellidos;
    private int edad;
    private boolean casado;

    public Persona(String nombre, String apellidos, int edad, boolean casado){
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
        this.casado = casado;
    }

    public Persona(String nombre, String apellidos, int edad){
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
        this.casado = false;
    }
    public void saluda(){
        System.out.println("Hola " + nombre);
    }
}