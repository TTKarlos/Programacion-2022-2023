public class Actividad16_7 {

    /**
     * @Error: Per a poder llevar els decimals a un float hem de utilitzar el "%.0f" y no el %d ja que això el que fa es
     * es posarlo en int y no es pot al ser una float.
     * @Tipus: Temps de compilació.
     **/

    final static float NUMERO_SECRETO = 5f;

    public static void main(String[] args) {

        double numeroAEndevinar = NUMERO_SECRETO / 2;
        System.out.printf("El numero es %.0f", numeroAEndevinar);

    }

}
