package com.example.batoiflix.modelo.entities;

import com.example.batoiflix.modelo.enums.Calificacion;
import com.example.batoiflix.modelo.enums.Genero;
import java.time.LocalDate;
import java.util.ArrayList;

public class Produccion {
    private int id;
    private String titulo;
    private Calificacion calificacion;
    private LocalDate fechaLanzamiento;
    private int duracion;
    private ArrayList<Genero> genero;
    private Director director;
    private ArrayList<Actores> actores;
    private String guion;
    private String portada;
    private Productor productor;
    private String web;
    private String actor;

    public Produccion(int id, String titulo, Calificacion calificacion, LocalDate fechaLanzamiento, int duracion,
                      ArrayList<Genero> genero, Director director, ArrayList<Actores> actores, String guion, String portada,
                      Productor productor, String web) {
        this.id = id;
        this.titulo = titulo;
        this.calificacion = calificacion;
        this.fechaLanzamiento = fechaLanzamiento;
        this.duracion = duracion;
        this.genero = genero;
        this.director = director;
        this.actores = actores;
        this.guion = guion;
        this.portada = portada;
        this.productor = productor;
        this.web = web;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getActor() {
        return actor;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public Calificacion getCalificacion() {
        return calificacion;
    }

    public LocalDate getFechaLanzamiento() {
        return fechaLanzamiento;
    }

    public int getDuracion() {
        return duracion;
    }

    public ArrayList<Genero> getGenero() {
        return genero;
    }

    public Director getDirector() {
        return director;
    }

    public ArrayList<Actores> getActores() {
        return actores;
    }

    public String getGuion() {
        return guion;
    }

    public String getPortada() {
        return portada;
    }

    public Productor getProductor() {
        return productor;
    }

    public String getWeb() {
        return web;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDirector(Director director) {
        this.director = director;
    }

    public void setActores(ArrayList<Actores> actores) {
        this.actores = actores;
    }

    public void setProductor(Productor productor) {
        this.productor = productor;
    }
}