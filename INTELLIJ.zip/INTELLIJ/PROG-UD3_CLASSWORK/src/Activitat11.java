import java.awt.desktop.SystemEventListener;
import java.util.Scanner;

public class Activitat11 {

    final static float MENOR_A_40000 = 0.20f;
    final static float MAJOR_A_40000 = 0.30f;
    final static int BONO_MENOS_DE_10000 = 1500;
    final static int MESES_EN_UN_AÑO = 12;
    final static int SUELDO_10000 = 10000;
    final static int SUELDO_15000 = 15000;
    final static int SUELDO_40000 = 40000;

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introdueix el sou brut mensual(€): ");

        float dineroMensual;

        if (!teclado.hasNextFloat()) {
            System.out.println("Error! El tipus de dades introduït és incorrecte");
            return;
        } else {
            dineroMensual = teclado.nextFloat();
        }
        if (dineroMensual < 0) {
            System.out.println("Error! Sou incorrecte");
            return;
        }
        float dineroAnual;
        dineroAnual = dineroMensual * MESES_EN_UN_AÑO;
        System.out.printf("El teu sou anual ascendeix a un total de %.2f €\n", dineroAnual);

        float dineroMenosDe40000 = dineroAnual * MENOR_A_40000;
        float dineroMasDe40000 = dineroAnual * MAJOR_A_40000;

        if (dineroAnual < SUELDO_10000) {
            System.out.println("No has de pagar cap quantitat i reps una ajuda de 1500€");
        } else if (dineroAnual < SUELDO_15000) {
            System.out.printf("Has de pagar %.2f € i reps una ajuda de 1500€", dineroMenosDe40000);
        } else if (dineroAnual < SUELDO_40000) {
            System.out.printf("Has de pagar %.2f € i no reps cap ajuda", dineroMenosDe40000);
        } else if (dineroAnual > SUELDO_40000) {
            System.out.printf("Has de pagar %.2f € i no reps cap ajuda", dineroMasDe40000);
        }
    }
}
