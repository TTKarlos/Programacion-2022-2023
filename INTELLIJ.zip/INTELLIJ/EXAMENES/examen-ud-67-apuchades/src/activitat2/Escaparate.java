package activitat2;

public class Escaparate {
    final static int NUM_MAXIMS_DE_PUBLICACIONS = 20;
    private Publicacion[] publicacions;

    public Escaparate(){
        publicacions = new Publicacion[NUM_MAXIMS_DE_PUBLICACIONS];
    }

    public void anyadir(Publicacion publicacion){
        int numDePublicacioIdentica = numDePublicacionIdentica(publicacion);
        if(numDePublicacioIdentica != -1){
            publicacions[numDePublicacioIdentica] = publicacion;
            System.out.println("Se ha actualizado la vieja publicacion por la nueva");
        } else {
            anyadirPublicacioALaArray(publicacion);
            System.out.println("La nueva publicacion se ha añadido correctamente");
        }
    }

    public void mostrarTodas(){
        for (int i = 0; i < publicacions.length; i++) {
            if(publicacions[i] != null){
                System.out.printf("Publicacion: %s\nTrabajo realizado al %s sobre %s\n", publicacions[i].getMensaje(),
                        publicacions[i].getCliente().toString(), publicacions[i].getServicio().toString());
            }
        }
    }

    private void anyadirPublicacioALaArray(Publicacion publicacion){
        Publicacion[] publicacionesNuevas = new Publicacion[NUM_MAXIMS_DE_PUBLICACIONS];

        for (int i = 1; i < publicacionesNuevas.length; i++) {
            publicacionesNuevas[i] = publicacions[i - 1];
        }

        publicacionesNuevas[0] = publicacion;
        this.publicacions = publicacionesNuevas;
    }

    private int numDePublicacionIdentica(Publicacion publicacion){
        for (int i = 0; i < publicacions.length; i++) {
            if(publicacions[i] != null && publicacions[i].equals(publicacion)){
                return i;
            }
        }

        return -1;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}