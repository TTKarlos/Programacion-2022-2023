package activitat13;

public class TestFecha {
    public static void main(String[] args) {

        Fecha fechaPredeterminada = new Fecha();
        Fecha fecha = new Fecha(16, 1, 2021);

        mostrarInformacionPruebaDeConstructores(fechaPredeterminada, fecha);
        mostrarInformacionDeMetodosDeAnyadirYRestarDias(fecha);
        mostrarInformacionDeMetodoModificador(fecha);
    }

    public static void mostrarInformacionPruebaDeConstructores(Fecha fechaPredeterminada, Fecha fecha1){
        System.out.println("=== START - Prueba de Constructores - START ===");
        System.out.println();

        System.out.println("--- Creo un nuevo objeto utilizando el constructor parametrizado int int int (16,1,2021) ---");
        fecha1.mostrarInformacion();
        System.out.println();

        System.out.println("--- Creo un nuevo objeto utilizando la fecha anterior mediante el constructor por copia ---");
        Fecha fecha1Clone = fecha1.clone();
        fecha1Clone.mostrarInformacion();

        System.out.printf("--- Compruebo mediante el método equals que las fechas representadas por ambos objetos son iguales ---\n" +
                "La fecha creada con los constructores anteriores son iguales: %b -------------------------------\n",
                fecha1Clone.isEqual(fecha1));

        System.out.println("\n--- Creo un nuevo objeto utilizando el constructor String 16/1/2021 ---");
        Fecha fechaString = new Fecha("16/1/2021");
        fechaString.mostrarInformacion();

        System.out.println("\n--- Creo un nuevo objeto utilizando el constructor por defecto --- 01-01-1970");
        fechaPredeterminada.mostrarInformacion();
    }

    public static void mostrarInformacionDeMetodosDeAnyadirYRestarDias(Fecha fecha1){
        System.out.println("\n=== START - Prueba de Métodos anyadir/restar días - START ====");

        fecha1 = fecha1.anyadir(1);
        fecha1.mostrarInformacionDeAnyadir(1);
        System.out.println();

        fecha1.set(16, 1, 2021);
        fecha1 = fecha1.resto(1);
        fecha1.mostrarInformacionDeResto(1);
        System.out.println();

        fecha1.set(16, 1, 2021);
        fecha1 = fecha1.resto(30);
        fecha1.mostrarInformacionDeResto(30);

        System.out.println("=== FIN - Prueba de Métodos anyadir/restar - FIN ===");
    }

    public static void mostrarInformacionDeMetodoModificador(Fecha fecha1){
        System.out.println("\n=== START - Prueba del método modificador - START ===");

        fecha1.set(22, 1, 2021);
        System.out.printf("--- Modifico la fecha del primer objeto creado (16-1-2020) por la fecha 22-1-2021 ---\n");
        fecha1.mostrarInformacion();
    }
}