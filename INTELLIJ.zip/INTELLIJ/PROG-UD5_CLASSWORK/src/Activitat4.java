import java.util.Scanner;

public class Activitat4 {
    public static void main(String[] args) {

        int[] numero = new int[20];

        for (int i = 0; i < numero.length; i++){

            for (int j = 0; j <= 4; j++){
                int aleatorio = (int) (Math.random()*9+0);
                numero[i] += aleatorio*Math.pow(10,i);
            }
        }

        for (int i = 0; i < numero.length; i++){
            System.out.printf("Numero %d: %d\n", i, numero[i]);

        }
    }
}
