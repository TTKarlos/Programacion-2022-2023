import java.util.Scanner;

public class Activtat15A {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introdueix un número: ");

        int num = teclado.nextInt();

        int suma = sumaNumeros(num);
        System.out.println("La suma és " + suma);
    }
    public static int sumaNumeros(int num){

        int suma = 0;

        for (int i = 2; i >= 1; i = num){

            suma += num % 10;
            num = num / 10;
        }

        return suma;
    }
}