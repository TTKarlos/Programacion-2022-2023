package es.cipfpbatoi.plantillaexamen.model.repositorios;

import es.cipfpbatoi.plantillaexamen.model.dao.EditorialDAO;
import es.cipfpbatoi.plantillaexamen.model.dao.LibroDAO;
import es.cipfpbatoi.plantillaexamen.model.dao.interfaces.EditorialDAOInterface;
import es.cipfpbatoi.plantillaexamen.model.dao.interfaces.LibroDAOInterface;
import es.cipfpbatoi.plantillaexamen.model.exceptions.NotFoundException;
import es.cipfpbatoi.plantillaexamen.model.utils.libro.Libro;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;

@Service
public class LibroRepositorio {
    @Autowired
    private LibroDAOInterface libroDAOInterface;
    @Autowired
    private EditorialDAOInterface editorialDAOInterface;

    public LibroRepositorio(@Autowired LibroDAO libroDAO, @Autowired EditorialDAO editorialDAO){
        this.libroDAOInterface = libroDAO;
        this.editorialDAOInterface = editorialDAO;
    }

    public ArrayList<Libro> findAll(){
        return libroDAOInterface.findAll();
    }

    public ArrayList<Libro> findAllWithEditoriales(){
        ArrayList<Libro> librosOld = findAll();
        ArrayList<Libro> librosNew = new ArrayList<>();

        for (int i = 0; i < librosOld.size(); i++) {
            Libro libro = librosOld.get(i);
            libro.setEditorial(editorialDAOInterface.findById(librosOld.get(i).getIdEditorial()));
            librosNew.add(libro);
        }

        return librosNew;
    }

    public Libro findByTitulo(String titulo){
        try{
            return getByTitulo(titulo);
        } catch (NotFoundException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    public Libro getByTitulo(String titulo) throws NotFoundException {
        Libro libro = libroDAOInterface.findByTitulo(titulo);
        if(libro == null){
            throw new NotFoundException(titulo);
        }

        return libro;
    }

    public void remove(Libro libro){
        libroDAOInterface.remove(libro);
    }
}