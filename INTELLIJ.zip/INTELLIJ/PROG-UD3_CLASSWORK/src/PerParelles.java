import java.util.Scanner;

public class PerParelles {

    final static float PREU_PER_BOTELLA_AIGUA = 0.75f;
    final static float PREU_PER_BOTELLA_ENSUCRADES = 1.50f;
    final static float PREU_PER_BOTELLA_ALCOHOL = 3;
    final static float EUROS_PER_BOTELLA = 0.15f;
    final static float DESCOMPTE_MAJOR_A_250 = 0.15f;
    final static float MESSOS_EN_UN_ANY = 12;

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        int numBotellesAigua;
        System.out.print("Quantes botelles d'aigua has comprat enguany?: ");
        if (!teclado.hasNextInt()) {
            System.out.println("Error! El tipus de dades introduït és incorrecte");
            return;
        } else {
            numBotellesAigua = teclado.nextInt();
            if (numBotellesAigua < 0) {
                System.out.println("Error! El tipus de dades introduït és incorrecte");
                return;
            }
        }

        int numBotellesEnseucrades;
        System.out.print("Quantes botelles de begudes ensucrades has comprat enguany?: ");
        if (!teclado.hasNextInt()){
            System.out.println("Error! El tipus de dades introduït és incorrecte");
            return;
        } else {
            numBotellesEnseucrades = teclado.nextInt();
            if (numBotellesEnseucrades < 0) {
                System.out.println("Error! El tipus de dades introduït és incorrecte");
                return;
            }
        }

        int numbotellesAlcohol;
        System.out.print("Quantes botelles de begudes alcohòliques has comprat enguany?: ");
        if (!teclado.hasNextInt()){
            System.out.println("Error! El tipus de dades introduït és incorrecte");
            return;
        } else {
            numbotellesAlcohol = teclado.nextInt();
            if (numbotellesAlcohol < 0){
                System.out.println("Error! El tipus de dades introduït és incorrecte");
                return;
            }
        }

        double dinersEnBotellesDeAigua = numBotellesAigua * PREU_PER_BOTELLA_AIGUA;
        double dinersEnBotellesDeEnsucrades = numBotellesEnseucrades * PREU_PER_BOTELLA_ENSUCRADES;
        double dinersEnBotellesDeAlcohol = numbotellesAlcohol * PREU_PER_BOTELLA_ALCOHOL;
        double eurosTotalsGastats = dinersEnBotellesDeAlcohol + dinersEnBotellesDeAigua + dinersEnBotellesDeEnsucrades;
        double mitjaEurosAny = eurosTotalsGastats / MESSOS_EN_UN_ANY;
        System.out.println("Has gastat una mitjana de " + mitjaEurosAny + "€ cada mes.");

        double eurosPerReciclar = (numBotellesAigua + numBotellesEnseucrades + numbotellesAlcohol) * EUROS_PER_BOTELLA;
        System.out.printf("Al reciclar les botelles has obtingut %.2f €", eurosPerReciclar);

        if (eurosTotalsGastats > 100 && eurosTotalsGastats < 150){
            System.out.println(" i una bonificació per l'any vinent de 0.016€ per botella ");
        } else if (eurosTotalsGastats >= 150 && eurosTotalsGastats < 250){
            System.out.println(" i una bonificació per l'any vinent de 0.017€ per botella ");
        } else if (eurosTotalsGastats >= 250){
            double descompteDeMes250 = eurosTotalsGastats * DESCOMPTE_MAJOR_A_250;
            System.out.printf(" i un val/descompte de %.2f €",descompteDeMes250);
        } else if (eurosTotalsGastats > 10 && eurosTotalsGastats < 20){
            System.out.println(" i un val/descompte de 10,00€");
        } else {
            System.out.println(" i no reps cap bonificació.");
        }

    }
}
