package activitat7;

public class PersonaAnglesa extends Persona{

    private String passaport;

    public PersonaAnglesa(String nombre, String apellidos, int edad, String passaport){
        super(nombre, apellidos, edad);
        this.passaport = passaport;
    }

    public void mostrarPassaport() {
        System.out.println("Passaport: " + passaport);
    }

    public void saludar(){
        System.out.println("Hello " + getNombre());
    }
}