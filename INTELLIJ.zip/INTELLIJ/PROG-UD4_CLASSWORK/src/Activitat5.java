import java.util.Scanner;
import java.util.SortedMap;

public class Activitat5 {

    public static void main(String[] args) {

        taulaDeMultiplicar(4);

    }

    public static void taulaDeMultiplicar(int multiplicando) {

        for (int i = 1; i <= 10; i++) {
            System.out.println(multiplicando + " x " + i + " = " + (i * multiplicando));

        }
    }
}