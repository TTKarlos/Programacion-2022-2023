import java.util.Scanner;

public class Activitat12 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduce una letra: ");
        String caràcter = teclado.next();

        System.out.print("Introduce el numero de lineas: ");
        int numLineas = teclado.nextInt();

        System.out.println("PIRAMIDE:");

        imprimeixPiramidal(caràcter, numLineas);
    }

    public static void imprimeixPiramidal(String caràcter, int numLineas){

    int espaisEnBlanc = numLineas - 1;
    int numDeLletres = 1;

        for (int i = 1; i <= numLineas; i++) {
            System.out.print("\n");

            for (int x = 1; x <= espaisEnBlanc; x++) {
                System.out.print(" ");
            }

            espaisEnBlanc -= 1;

            for (int j = 1; j <= numDeLletres; j++) {
                System.out.print(caràcter);
            }

            numDeLletres += 2;
        }
    }
}
