package es.puchades.exceptions;

public class NoEncontradoException extends RuntimeException{
    public NoEncontradoException(String texto){
        super(texto);
    }
}