package es.puchades.view;

import de.vandermeer.asciitable.AT_Row;
import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;
import es.puchades.GestorIO;
import es.puchades.pedido.Pedido;

public class PedidoView {
    private Pedido pedido;
    public PedidoView(Pedido pedido){
        this.pedido = pedido;
    }

    private String getTablaPedido(){
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow(null, null, null, null, "=== Restaurante 20 Montaditos ===");
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow( null, null, "Pedido: " + pedido.getIdentificador(), "Cliente: " +
                        pedido.getNombreDelCliente(), "Fecha: " + pedido.getFechaDelPedido());
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow(null, null, null, null, "Listado productos solicitados");
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow("Codigo", "Nombre", "Precio", "Descuento", "PVP");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < pedido.getListaProductos().size(); i++) {
            table.addRule();
            row = table.addRow(pedido.getListaProductos().get(i).getCodigo(),
                    pedido.getListaProductos().get(i).getDescripcion(),
                    GestorIO.tornarPreuEnFormato(pedido.getListaProductos().get(i).getPrecioBase()),
                    GestorIO.tornarDescuentoEnFormato(pedido.getListaProductos().get(i).getDecuento()),
                    GestorIO.tornarPreuEnFormato(pedido.getListaProductos().get(i).calcularElPrecioPVP()));
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        }

        table.addRule();
        row = table.addRow(null, null, null, null, "TOTAL PRECIO = " +
                GestorIO.tornarPreuEnFormato(pedido.totalDineroDelPedido()));
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.RIGHT);

        table.addRule();
        row = table.addRow("*", "*", "*", "*", "*");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        table.addRule();

        return table.render();
    }

    @Override
    public String toString() {
        return getTablaPedido();
    }
}
