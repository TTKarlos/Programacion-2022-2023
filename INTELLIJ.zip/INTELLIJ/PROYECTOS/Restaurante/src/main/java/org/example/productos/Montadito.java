package org.example.productos;

import org.example.Producto;

public class Montadito extends Producto {
    public Montadito(String nombre, String descripcion, float precioBase, float decuento, float iva) {
        super(nombre, descripcion, precioBase, decuento, iva);
    }
}