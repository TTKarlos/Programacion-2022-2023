import java.util.Random;

public class Activitat5 {
    public static void main(String[] args) {

        int [] cadenaNumeros = new int[200];

        for (int i = 0; i < cadenaNumeros.length; i++){

            int numAleatori = (int) (Math.random()*200+0);

            cadenaNumeros[i] = numAleatori;
        }

        int suma = 0;

        for (int i = 0; i < cadenaNumeros.length; i++){
            if (cadenaNumeros[i] % 2 != 0){
                suma += cadenaNumeros[i];
            }
        }

        System.out.println(suma);
    }
}
