import java.util.Scanner;

public class Activitat1 {

    final static int NUMERO_DE_PALABRAS = 4;

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("introduce un numero N: ");
        int numN = teclado.nextInt();

        String[] array = adjuntarArray(numN);
        mostrarArray(array);
        mostrarArrayOrdenanada(array);

    }

    public static void mostrarArray(String[] array){

        System.out.print("Listado de palabras en el array: [");

        for (int i = 0; i < array.length; i++) {
            if (i != array.length - 1) {
                System.out.print(array[i] + ", ");
            } else {
                System.out.print(array[i]);
            }
        }
        System.out.print("]\n");
    }

    public static void mostrarArrayOrdenanada(String[] array){
        array = invertirArray(ordenarPerIntecanviAPartirDeDos(array));
        System.out.print("Listado de palabras ordenadas: ");
        for (int i = 0; i < array.length; i++){
            if(i != array.length - 1){
                System.out.print(array[i] + ", ");
            } else {
                System.out.print(array[i]);
            }
        }
    }

    public static String pedirPalabra(int index){

        Scanner teclado = new Scanner(System.in);

        do {

            System.out.print("Introduce una cadena [FIN para  terminar]: ");

            String palabra = teclado.next();

            if(palabra.equalsIgnoreCase("fin")){
                return palabra;
            }

            if(palabra.length() >= index){
                return palabra;
            } else {
                System.out.printf("¡Error! Debe contener al menos %d caracteres\n", index);
            }

        } while (true);
    }

    public static String[] adjuntarArray(int index){

         String[] array = new String[index];

        do {

            String palabra = pedirPalabra(NUMERO_DE_PALABRAS);

            if(!palabra.equalsIgnoreCase("fin")){
                array = moverArray(array, palabra);
            } else {
                return array;
            }

        } while (true);
    }

    public static String[] moverArray (String[] array, String palabra){

        String seguentParaula = array[0];


        for(int i = 1; i < array.length - 1; i++){

            String aux = array[i + 1];
            array[i + 1] = array[i];
            array[i] = seguentParaula;
            seguentParaula = aux;

        }

        array[0] = palabra;
        return array;
    }

    public static String[] ordenarPerIntecanviAPartirDeDos (String[] array) {
        for (int i = 0; i < array.length - 1; i++){
            for (int j = i + 1; j < array.length; j++){
                if (array[j].substring(0, array[j].length() - 1).compareToIgnoreCase(array[i].substring(0, array[i].length() - 1)) < 0) {
                    String aux = array[i];
                    array[i] = array[j];
                    array[j] = aux;
                }
            }
        }

        return array;
    }

    public static String[] invertirArray (String[] array){
        String[] arrayInvertida = new String[array.length];

        for (int i = 0; i < array.length; i++){
            arrayInvertida[i] = array[(array.length -1) - i];
        }

        return arrayInvertida;
    }
}