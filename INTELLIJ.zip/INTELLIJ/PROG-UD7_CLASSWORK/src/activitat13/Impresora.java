package activitat13;

public class Impresora {
    private String marca;
    private String modelo;
    private String numeroDeSerie;

    public Impresora(String marca, String modelo, String numeroDeSerie){
        this.marca = marca;
        this.modelo = modelo;
        this.numeroDeSerie = numeroDeSerie;
    }

    public void imprimir(Imprimible imprimible){
        System.out.println("Imprimiendo...");
        imprimible.obtenerTexto();
    }
}