package es.cipfpbatoi.plantillaexamen.utils.repositorios;

import es.cipfpbatoi.plantillaexamen.exceptions.NotFoundException;
import es.cipfpbatoi.plantillaexamen.model.dao.SQLUniversidadDAO;
import es.cipfpbatoi.plantillaexamen.model.dao.interfices.SQLUniversidadDAOInterfice;
import es.cipfpbatoi.plantillaexamen.utils.Universidad;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;

@Service
public class UniversidadRepositorio {
    @Autowired
    private SQLUniversidadDAOInterfice sqlUniversidadDAOInterfice;

    public UniversidadRepositorio(@Autowired SQLUniversidadDAO sqlUniversidadDAO){
        this.sqlUniversidadDAOInterfice = sqlUniversidadDAO;
    }

    public Universidad findById(int id){
        try {
            return sqlUniversidadDAOInterfice.findById(id);
        } catch (NotFoundException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    public ArrayList<Universidad> findAll(){
        return sqlUniversidadDAOInterfice.findAll();
    }

    public ArrayList<Universidad> findAllBuscador(String buscador){
        return sqlUniversidadDAOInterfice.findAllBuscador(buscador);
    }
}