package activitat9.enums;

public enum Tamany {
    PEQUEÑO {
        @Override
        public String toString() {
            return "pequeño";
        }
    },
    MEDIANO{
        @Override
        public String toString() {
            return "mediano";
        }
    },
    GRANDE{
        @Override
        public String toString() {
            return "grande";
        }
    },
}