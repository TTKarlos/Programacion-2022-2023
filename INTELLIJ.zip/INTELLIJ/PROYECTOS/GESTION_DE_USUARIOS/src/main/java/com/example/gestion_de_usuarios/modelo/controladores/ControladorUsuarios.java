package com.example.gestion_de_usuarios.modelo.controladores;

import com.example.gestion_de_usuarios.modelo.entidades.Usuario;
import com.example.gestion_de_usuarios.modelo.exceptions.NotFoundException;
import com.example.gestion_de_usuarios.modelo.repositorios.RepositorioUsuarios;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Map;

@Controller
public class ControladorUsuarios {

    private RepositorioUsuarios repositorioUsuarios = new RepositorioUsuarios();

    @GetMapping(value = "/usuarios-view")
    public String postAddAction(Model model) {
        model.addAttribute("usuarios", repositorioUsuarios.getListaUsuarios());
        return "usuarios-view";
    }


    @GetMapping("/usuario-formulario-view")
    public String usuarioFomularioView(){
        return "formulario-usuario";
    }

    @PostMapping(value = "/usuario-add")
    public String anyadirUsuario(@RequestParam Map<String, String> parametros) {
        try{
            Usuario tarea = new Usuario(parametros.get("nombre"), parametros.get("apellidos"), parametros.get("dni"),
                    parametros.get("correo"), parametros.get("codigoPostal"), parametros.get("telefono"),
                    parametros.get("fechaNacimiento"), parametros.get("password"));
            repositorioUsuarios.add(tarea);
            return "redirect:/usuarios-view";
        } catch (InputMismatchException e){
            System.out.println(e.getMessage());
            return "<html>" + "<body>Usuario no se ha registrado con exito</body>" + "</html>";
        }
    }

    @GetMapping(value = "/usuario-view")
    public String postAddAction(@RequestParam String nombre, Model model){
        try{
            Usuario usuarioBuscado = repositorioUsuarios.buscarUsuarioPorNombre(nombre);
            model.addAttribute("usuario", usuarioBuscado);
            return "usuario-view";
        } catch (NotFoundException e){
            return "No se ha encontrado este Usuario";
        }
    }

    @GetMapping(value = "/usuario-del")
    public String tareaDelAction(@RequestParam String nombre){
        try{
            repositorioUsuarios.remove(nombre);
            return "redirect:/usuarios-view";
        } catch (NotFoundException e){
            return "Tarea no eliminada, por que el usuario " + nombre + " no existe.";
        }
    }

    private LocalDate formDateTime(String fecha){
        return LocalDate.parse(fecha);
    }
}