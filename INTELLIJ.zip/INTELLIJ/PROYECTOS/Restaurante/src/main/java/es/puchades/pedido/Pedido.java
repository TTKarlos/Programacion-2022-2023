package es.puchades.pedido;

import es.puchades.productos.Producto;

import java.util.ArrayList;

public class Pedido {
    private int identificador;
    private String fechaDelPedido;
    private String nombreDelCliente;
    private boolean haSidoServidoEnMesa;
    private ArrayList<Producto> listaProductos;
    private boolean estaCancelado;
    private String comentarioDeCancelacion;

    public Pedido(int identificador){
        this.identificador = identificador;
    }

    public Pedido(int identificador, String fechaDelPedido, String nombreDelCliente, ArrayList<Producto> listaProductos) {
        this.identificador = identificador;
        this.fechaDelPedido = fechaDelPedido;
        this.nombreDelCliente = nombreDelCliente;
        this.haSidoServidoEnMesa = false;
        this.listaProductos = listaProductos;
    }

    public ArrayList<Producto> getListaProductos() {
        return listaProductos;
    }

    public int getIdentificador() {
        return identificador;
    }

    public String getNombreDelCliente() {
        return nombreDelCliente;
    }

    public String getFechaDelPedido() {
        return fechaDelPedido;
    }

    public boolean getHaSidoServidoEnMesa() {
        return haSidoServidoEnMesa;
    }

    public void setHaSidoServidoEnMesa(boolean haSidoServidoEnMesa) {
        this.haSidoServidoEnMesa = haSidoServidoEnMesa;
    }

    public void setEstaCancelado(boolean estaCancelado) {
        this.estaCancelado = estaCancelado;
    }

    public void setComentarioDeCancelacion(String comentarioDeCancelacion) {
        this.comentarioDeCancelacion = comentarioDeCancelacion;
    }

    public float totalDineroDelPedido(){
        float totalDinero = 0;

        for (int i = 0; i < listaProductos.size(); i++) {
            totalDinero += listaProductos.get(i).calcularElPrecioPVP();
        }

        return totalDinero;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Pedido)){
            return false;
        }
        Pedido pedido = (Pedido) obj;
        return identificador == pedido.identificador;
    }
}