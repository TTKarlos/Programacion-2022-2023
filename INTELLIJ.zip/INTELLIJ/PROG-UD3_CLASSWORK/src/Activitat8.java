import java.util.Scanner;

public class Activitat8 {

    final static float QUOTA = 500f;

    public static void main(String[] args) {

        Scanner teclat = new Scanner(System.in);

        System.out.println("Exemple d'execució");
        System.out.print("Insereix nom: ");
        String nom = teclat.next();
        System.out.print("Insereix edat: ");
        int edad = teclat.nextInt();

        if (edad > 65) {
            double euros = QUOTA - (QUOTA*0.45);
            System.out.println(nom + ", has de pagar " + euros + " euros.");
        } else if (edad < 18) {
            double euros = QUOTA -(QUOTA*0.25);
            System.out.println(nom + ", has de pagar " + euros + " euros.");
        } else System.out.println(nom + ", has de pagar " + QUOTA + " euros.");
    }
}
