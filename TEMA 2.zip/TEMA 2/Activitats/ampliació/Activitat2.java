package ampliació;

import java.util.Scanner;

public class Activitat2 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("Dades del punt A:");
        System.out.print("x1: ");
        int puntoX1 = teclado.nextInt();
        System.out.print("y1: ");
        int puntoY1 = teclado.nextInt();
        System.out.println("Dades del punt B:");
        System.out.print("x2: ");
        int puntoX2 = teclado.nextInt();
        System.out.print("y2: ");
        int puntoY2 = teclado.nextInt();

        double primerParentesis= Math.pow(puntoX2-puntoX1,2);
        double segundoParentesis= Math.pow(puntoY2-puntoY1,2);
        double formulaTotal = Math.sqrt(primerParentesis+segundoParentesis);

        System.out.printf("La distància entre (%d,%d) i (%d,%d) és %.2f", puntoX1, puntoY1, puntoX2, puntoY2, formulaTotal);

    }
}
