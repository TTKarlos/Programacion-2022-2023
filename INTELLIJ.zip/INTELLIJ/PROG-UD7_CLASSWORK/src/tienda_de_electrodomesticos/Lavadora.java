package tienda_de_electrodomesticos;

public class Lavadora extends Electrodomesticos implements Conectable {
    private int capacidadDeRopaMaxima;

    public Lavadora(String marca, String modelo, String codigo) {
        super(marca, modelo, codigo);
        this.capacidadDeRopaMaxima = 5;
    }

    public Lavadora(String marca, String modelo, String codigo, int capacidadDeRopaMaxima) {
        super(marca, modelo, codigo);
        this.capacidadDeRopaMaxima = capacidadDeRopaMaxima;
    }

    @Override
    public float obtenerPrecioVenta(){
        float precioVenta = super.obtenerPrecioVenta();

        if(capacidadDeRopaMaxima > 30){
            return precioVenta + 50;
        } else {
            return precioVenta;
        }
    }

    @Override
    public String toString() {
        return "[Lavadora] carga: " + capacidadDeRopaMaxima + ", " + super.toString() + ", Precio Venta: " +
                obtenerPrecioVenta() + ", Power: " + getEstaEncendido();
    }
}