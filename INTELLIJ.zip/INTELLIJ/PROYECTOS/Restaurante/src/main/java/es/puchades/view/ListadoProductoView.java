package es.puchades.view;

import de.vandermeer.asciitable.AT_Row;
import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;
import es.puchades.GestorIO;
import es.puchades.productos.Producto;
import es.puchades.productos.tipos.Bebida;
import es.puchades.productos.tipos.Entrante;
import es.puchades.productos.tipos.Montadito;
import java.util.ArrayList;

public class ListadoProductoView {
    private ArrayList<Producto> listaProductos;

    public ListadoProductoView(ArrayList<Producto> listaProductos){
        this.listaProductos = listaProductos;
        mostrarProductos();
    }

    public void mostrarProductos(){
        if(listaProductos.get(0) instanceof Bebida){
            mostrarTodosLasBebidas();
        } else if (listaProductos.get(0) instanceof Entrante){
            mostrarTodosLosEntrantes();
        } else if (listaProductos.get(0) instanceof Montadito){
            mostrarTodosLosMontaditos();
        } else {
            mostrarTodosLosPostres();
        }
    }

    private void mostrarTodosLosPostres(){
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow("Codigo", "Nombre", "Precio Base", "Precio PVP", "Caracteristicas");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < listaProductos.size(); i++) {
            table.addRule();
            row = table.addRow(listaProductos.get(i).getCodigo(), listaProductos.get(i).getDescripcion(),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).getPrecioBase()),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).calcularElPrecioPVP()),
                    getCaracteristicas(listaProductos.get(i).getAptoParaCeliacos(),
                            listaProductos.get(i).getAptoParaDiabeticos()));
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.RIGHT);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.RIGHT);
            row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        }

        table.addRule();
        System.out.println(table.render(100));
    }

    private void mostrarTodosLosMontaditos(){
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow("Codigo", "Nombre", "Precio Base", "Precio PVP");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < listaProductos.size(); i++) {
            table.addRule();
            row = table.addRow(listaProductos.get(i).getCodigo(), listaProductos.get(i).getDescripcion(),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).getPrecioBase()),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).calcularElPrecioPVP()));
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.RIGHT);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.RIGHT);
        }

        table.addRule();
        System.out.println(table.render(100));
    }

    private void mostrarTodosLasBebidas(){
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow("Codigo", "Nombre", "Precio Base", "Tamaño", "Rellenable", "Precio PVP");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(5).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < listaProductos.size(); i++) {
            table.addRule();
            row = table.addRow(listaProductos.get(i).getCodigo(), listaProductos.get(i).getDescripcion(),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).getPrecioBase()),
                    listaProductos.get(i).getTamanyoDeBebida(),
                    getEsRellenableEnFormato(listaProductos.get(i).getEsRellenable()),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).calcularElPrecioPVP()));
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.RIGHT);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.RIGHT);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(5).getContext().setTextAlignment(TextAlignment.RIGHT);
        }

        table.addRule();
        System.out.println(table.render(100));
    }

    private void mostrarTodosLosEntrantes(){
        AsciiTable table = new AsciiTable();
        AT_Row row;
        table.addRule();
        row = table.addRow("Codigo", "Nombre", "Precio Base", "Descuento", "Precio PVP");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < listaProductos.size(); i++) {
            table.addRule();
            row = table.addRow(listaProductos.get(i).getCodigo(), listaProductos.get(i).getDescripcion(),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).getPrecioBase()),
                    GestorIO.tornarDescuentoEnFormato(listaProductos.get(i).getDecuento()),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).calcularElPrecioPVP()));
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.RIGHT);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(4).getContext().setTextAlignment(TextAlignment.RIGHT);
        }

        table.addRule();
        System.out.println(table.render(100));
    }

    private String getEsRellenableEnFormato(boolean esRellenable){
        if (esRellenable){
            return "SI";
        } else {
            return "No";
        }
    }

    private String getCaracteristicas(boolean aptoParaCeliacos, boolean aptoParaDiabeticos){
        if(aptoParaCeliacos && aptoParaDiabeticos){
            return "Es apto para diabeticos y para celiacos";
        } else if(aptoParaCeliacos){
            return "No es apto para diabeticos, pero es apto para celiacos";
        } else if(aptoParaDiabeticos){
            return "No es apto para celiacos, pero es apto para diabeticos";
        } else {
            return "No es apto ni para diabeticos ni para celiacos";
        }
    }
}