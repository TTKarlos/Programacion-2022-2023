package activitat6;

public class Empleado {

    final static float INCREMENTAR_SALARI = 0.02f;
    private String nombre;
    private String apellidos;
    private String dni;
    private String fechaDeInicio;
    private String telefono;
    private float salario;

    public Empleado(String nombre, String apellidos, String dni, String fechaDeInicio, String telefono, float salario){
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
        this.fechaDeInicio = fechaDeInicio;
        this.telefono = telefono;
        this.salario = salario;
    }

    public void incrementarSalario(){
        this.salario = salario + (salario * INCREMENTAR_SALARI);
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public float getSalario() {
        return salario;
    }

    @Override
    public String toString() {
        return "nombre: " + nombre + ", apellidos: " + apellidos + ", dni: " + dni + ", sueldo: " + salario;
    }
}
