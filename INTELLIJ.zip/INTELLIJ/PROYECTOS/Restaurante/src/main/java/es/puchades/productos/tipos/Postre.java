package es.puchades.productos.tipos;

import es.puchades.exceptions.DescuetoNoAplicableException;
import es.puchades.productos.Producto;

public class Postre extends Producto {
    private boolean aptoParaDiabeticos;
    private boolean aptoParaCeliacos;

    public Postre(String nombre, String descripcion, float precioBase, float descuento, float iva,
                  boolean aptoParaDiabeticos, boolean aptoParaCeliacos) {

        super(nombre, descripcion, precioBase, descuento, iva);
        this.aptoParaDiabeticos = aptoParaDiabeticos;
        this.aptoParaCeliacos = aptoParaCeliacos;

        if(descuento != 0){
            throw new DescuetoNoAplicableException();
        }
    }

    @Override
    public boolean getAptoParaDiabeticos(){
        return aptoParaDiabeticos;
    }

    @Override
    public boolean getAptoParaCeliacos(){
        return aptoParaCeliacos;
    }
}