package org.example.productos;

import org.example.Producto;

public class Postre extends Producto {
    private boolean aptoParaDiabeticos;
    private boolean aptoParaCeliacos;

    public Postre(String nombre, String descripcion, float precioBase, float decuento, float iva,
                  boolean aptoParaDiabeticos, boolean aptoParaCeliacos) {
        super(nombre, descripcion, precioBase, decuento, iva);
        this.aptoParaDiabeticos = aptoParaDiabeticos;
        this.aptoParaCeliacos = aptoParaCeliacos;
    }

    @Override
    public String getCaracteristicas(){
        if(aptoParaCeliacos && aptoParaDiabeticos){
            return "Es apto para diabeticos y para celiacos";
        } else if(aptoParaCeliacos){
            return "No es apto para diabeticos, pero es apto para celiacos";
        } else if(aptoParaDiabeticos){
            return "No es apto para celiacos, pero es apto para diabeticos";
        } else {
            return "No es apto ni para diabeticos ni para celiacos";
        }
    }
}