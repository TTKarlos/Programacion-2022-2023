package com.example.gestion_de_usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDeUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
