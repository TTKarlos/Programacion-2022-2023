package activitat7;

import java.io.PrintStream;

public class Persona{
    private String nombre ;
    private String apellidos;
    private int edad;

    public Persona (String nombre, String apellidos, int edad){
        this.nombre=nombre;
        this.apellidos=apellidos;
        this.edad=edad;
        this.nombre=nombre;

    }

    public String getNombre() {
        return nombre;
    }

    public void saludar() {
        System.out.println("Hello " + nombre);
    }
}