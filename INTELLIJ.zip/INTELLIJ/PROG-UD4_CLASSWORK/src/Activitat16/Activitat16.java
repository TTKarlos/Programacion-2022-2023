package Activitat16;

public class Activitat16 {
    public static void main(String[] args) {

        System.out.println("SUMA\n----");
        suma(2, 4);
        suma(6, 8);
        suma(3, 2);

        System.out.println("\nRESTA\n-----");
        resta(2, 4);
        resta(6, 8);
        resta(3, 2);

        System.out.println("\nMULTIPLICAIÓ\n-------------");
        multiplicacio(2, 4);
        multiplicacio(6, 8);
        multiplicacio(3, 2);

        System.out.println("\nDIVISIÓ\n-------");
        divisio(2, 4);
        divisio(6, 8);
        divisio(3, 2);

        System.out.println("\nMÒDUL\n-----");
        modul(2, 4);
        modul(6, 8);
        modul(3, 2);

        System.out.println("\nARREL QUADRADA\n---------------");
        arrelquadrada(16.00);
        arrelquadrada(4.00);
        arrelquadrada(2.00);

        System.out.println("\nPOTÈNCIA\n---------------");
        potencia(2, 4);
        potencia(6, 8);
        potencia(3, 2);

        System.out.println("\nÀREA RECTANGLE\n--------------");
        areaRectangle(12, 34);
        areaRectangle(19.4, 42.4);
        areaRectangle(27, 56.4);

        System.out.println("\nVOLUM PRISMA\n------------");
        volumPrisma(12, 34, 10);
        volumPrisma(19.4, 42.4, 200);
        volumPrisma(27, 56.4, 50);

        equcioDeSegonGrau(12, 34, 7);
        equcioDeSegonGrau(19, -42, 23);
        equcioDeSegonGrau(27, 56, -16);
    }

    public static void suma(int num1, int num2) {
        System.out.printf("%d + %d = %d\n", num1, num2, Matematica.obtindreSuma(num1, num2));
    }

    public static void resta(int num1, int num2) {
        System.out.printf("%d - %d = %d\n", num1, num2, Matematica.obtindreResta(num1, num2));
    }

    public static void multiplicacio(int num1, int num2) {
        System.out.printf("%d * %d = %d\n", num1, num2, Matematica.obtindreMultiplicacio(num1, num2));
    }

    public static void divisio(int num1, int num2) {
        System.out.printf("%d / %d = %.3f\n", num1, num2, Matematica.obtindreDivisio(num1, num2));
    }

    public static void modul(int num1, int num2) {
        System.out.printf("%d %% %d = %d\n", num1, num2, Matematica.obtindreModul(num1, num2));
    }

    public static void arrelquadrada(double num1) {
        System.out.printf("√%.2f = %.2f\n", num1, Matematica.obtindreArrelQuadrada(num1));
    }

    public static void potencia(int num1, int num2) {
        System.out.printf("%d ^ %d = %d\n", num1, num2, Matematica.obtindrePotencia(num1, num2));
    }

    public static void volumPrisma(double ample, double alt, double profunditat) {
        System.out.printf("%.1f x %.1f x %.1f = %d\n", ample, alt, profunditat, Matematica.obtindreVolumPrisma(ample, alt, profunditat));
    }

    public static void areaRectangle(double base, double altura) {
        System.out.printf("%.1f x %.1f = %d\n", base, altura, Matematica.obtindreAreaRectangle(base, altura));
    }

    public static void equcioDeSegonGrau1(int a, int b, int c) {
        System.out.println("\nEQUACIÓ DE SEGON GRAU\n---------------------");
        System.out.printf("+%dx^2 +%dx +%d = 0 x1 = %.3f x2 = %.3f\n", a, b, c, Matematica.obtindreEquacioGrau2(a, b, c, true), Matematica.obtindreEquacioGrau2(a, b, c, false));
    }

    public static void equcioDeSegonGrau2(int a, int b, int c) {
        System.out.println("\nEQUACIÓ DE SEGON GRAU\n---------------------");
        System.out.printf("+%dx^2 %dx +%d = 0 x1 = %.3f x2 = %.3f\n", a, b, c, Matematica.obtindreEquacioGrau2(a, b, c, true), Matematica.obtindreEquacioGrau2(a, b, c, false));
    }

    public static void equcioDeSegonGrau(int a, int b, int c) {
        System.out.println("\nEQUACIÓ DE SEGON GRAU\n---------------------");
        System.out.printf("%+dx^2 %+dx %+d = 0 x1 = %.3f x2 = %.3f\n", a, b, c, Matematica.obtindreEquacioGrau2(a, b, c, true), Matematica.obtindreEquacioGrau2(a, b, c, false));
    }
}