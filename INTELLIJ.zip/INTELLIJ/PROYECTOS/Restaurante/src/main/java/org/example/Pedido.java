package org.example;

import org.example.enums.Catalogo;
import org.example.productos.Bebida;
import org.example.productos.Entrante;
import org.example.productos.Montadito;
import org.example.productos.Postre;
import org.example.view.ListadoProductoView;
import java.util.ArrayList;
import java.util.Scanner;

public class Pedido {
    final static String TEXTO_CODIGO_ERRONEO = "El codigo del producto es erróneo";
    final static String TEXTO_INTRODUCE_PRODUCTO = "Introduzca el código del producto que desea añadir (0 - Finalizar)";
    private int identificador;
    private String fechaDelPedido;
    private String nombreDelCliente;
    private boolean haSidoServidoEnMesa;
    private ArrayList<Producto> listaProductos;

    public Pedido(int identificador, String fechaDelPedido, String nombreDelCliente){
        this.identificador = identificador;
        this.fechaDelPedido = fechaDelPedido;
        this.nombreDelCliente = nombreDelCliente;
        this.haSidoServidoEnMesa = false;
        this.listaProductos = new ArrayList<>();
        pediProducto(Bebida.class);
        pediProducto(Entrante.class);
        pediProducto(Montadito.class);
        pediProducto(Postre.class);
    }

    public int getIdentificador() {
        return identificador;
    }

    public String getNombreDelCliente() {
        return nombreDelCliente;
    }

    public String getFechaDelPedido() {
        return fechaDelPedido;
    }

    public ArrayList<Producto> getPostres() {
        ArrayList<Producto> listaPostres = new ArrayList<>();

        for (int i = 0; i < listaProductos.size(); i++) {
            if(listaProductos.get(i) instanceof Postre){
                listaPostres.add(listaProductos.get(i));
            }
        }

        return listaPostres;
    }

    public ArrayList<Producto> getEntrantes() {
        ArrayList<Producto> listaEntrantes = new ArrayList<>();

        for (int i = 0; i < listaProductos.size(); i++) {
            if(listaProductos.get(i) instanceof Entrante){
                listaEntrantes.add(listaProductos.get(i));
            }
        }

        return listaEntrantes;
    }

    public ArrayList<Producto> getBebidas() {
        ArrayList<Producto> listaBebidas = new ArrayList<>();

        for (int i = 0; i < listaProductos.size(); i++) {
            if(listaProductos.get(i) instanceof Bebida){
                listaBebidas.add(listaProductos.get(i));
            }
        }

        return listaBebidas;    }

    public ArrayList<Producto> getMontaditos() {
        ArrayList<Producto> listaMontaditos = new ArrayList<>();

        for (int i = 0; i < listaProductos.size(); i++) {
            if(listaProductos.get(i) instanceof Montadito){
                listaMontaditos.add(listaProductos.get(i));
            }
        }

        return listaMontaditos;
    }

    public String getHaSidoServidoEnFormato(){
        if(haSidoServidoEnMesa){
            return "SI";
        } else {
            return "NO";
        }
    }

    public boolean getHaSidoServidoEnMesa() {
        return haSidoServidoEnMesa;
    }

    public void setHaSidoServidoEnMesa(boolean haSidoServidoEnMesa) {
        this.haSidoServidoEnMesa = haSidoServidoEnMesa;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Pedido)){
            return false;
        }
        Pedido pedido = (Pedido) obj;
        return identificador == pedido.identificador;
    }

    public float totalDineroDelPedido(){
        float totalDinero = 0;

        for (int i = 0; i < listaProductos.size(); i++) {
            totalDinero += listaProductos.get(i).calcularElPrecioPVP();
        }

        return totalDinero;
    }

    private void pediProducto(Class tipo) {
        Scanner teclado = new Scanner(System.in);
        Catalogo catalogo = new Catalogo(tipo);
        ArrayList<Producto> productos = catalogo.getListaProductos();
        System.out.println(new ListadoProductoView(productos));

        do {
            GestorIO.mostrarTextoEnAzul(TEXTO_INTRODUCE_PRODUCTO);
            String producto = teclado.next();

            if (producto.length() == 1 && Integer.parseInt(producto) == 0) {
                return;
            }

            if (catalogo.getProducto(producto) != null){
                Producto productoElegido = catalogo.getProducto(producto);
                listaProductos.add(productoElegido);
                mostrarProductoAnyadidoEnFormato(productoElegido);
            } else {
                GestorIO.mostrarTextoEnError(TEXTO_CODIGO_ERRONEO);
            }
        } while (true);
    }

    private void mostrarProductoAnyadidoEnFormato(Producto producto){
        System.out.print(GestorIO.COLOR_VERDE + producto.getNombre() + GestorIO.RESET_COLOR +
                " - " + producto.getDescripcion());
        GestorIO.mostrarTextoEnVerde(" [Añadido]");
    }
}