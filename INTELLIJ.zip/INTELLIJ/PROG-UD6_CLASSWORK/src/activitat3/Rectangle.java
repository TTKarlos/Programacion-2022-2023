package activitat3;

public class Rectangle {

    private int width;
    private int heigth;

    public Rectangle(int width, int heigth){

        this.width = width;
        this.heigth = heigth;
    }

    public int obtenerArea(){
        return width * heigth;
    }
}