package es.puchades.pedido;

import es.puchades.exceptions.ListaPedidosVacioException;

import java.util.ArrayList;

public class HistoricoPedidos {
    final static String TEXTO_NO_HAY_PEDIDOS = "Error! No hay pedidos";
    private ArrayList<Pedido> listaPedidosServidos;

    public HistoricoPedidos(){
        this.listaPedidosServidos = new ArrayList<>();
    }

    public ArrayList<Pedido> getListaPedidosServidos() {
        return listaPedidosServidos;
    }

    public void anyadirPedido(Pedido pedido){
        pedido.setHaSidoServidoEnMesa(true);
        listaPedidosServidos.add(pedido);
    }

    public ArrayList<Pedido> getIn(String fecha){
        ArrayList<Pedido> listaPedidosNueva = new ArrayList<>();

        for (int i = 0; i < listaPedidosServidos.size(); i++) {
            if(listaPedidosServidos.get(i).getFechaDelPedido().substring(0, 10).equals(fecha)){
                listaPedidosNueva.add(listaPedidosServidos.get(i));
            }
        }

        return listaPedidosServidos;
    }

    public boolean existenPedidos(){
        if (listaPedidosServidos.isEmpty()){
            throw new ListaPedidosVacioException(TEXTO_NO_HAY_PEDIDOS);
        }

        return true;
    }
}