import java.util.Scanner;

public class Activitat18 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int contador = 1;
        System.out.print("Escriu un enter: ");
        int numero = teclado.nextInt();
        System.out.println("--------------");

        while (contador <= 10){
            System.out.println(numero + " x " + contador + " = " + (contador * numero));
            contador++;
        }
    }
}
