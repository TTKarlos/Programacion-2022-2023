import java.util.Arrays;

public class Activitat11 {
    public static void main(String[] args) {
        String[] array = new String[] {"doha","carlos","kico","ivana","andreu","eric","jaume"};
        System.out.println(Arrays.toString(array));
        ordenarPerSeleccio(array);
        System.out.println(Arrays.toString(array));
    }

    public static void ordenarPerSeleccio(String[] vector){
        for (int i = 0; i < vector.length - 1; i++) {
            int elementMenor = i;
            for (int j = i + 1; j < vector.length; j++) {
                if (vector[j].compareTo(vector[elementMenor]) < 0){
                    elementMenor = j;
                }
                if(elementMenor != i){
                    String aux = vector[elementMenor];
                    vector[elementMenor] = vector[i];
                    vector[i] = aux;
                }
            }
        }
    }
}