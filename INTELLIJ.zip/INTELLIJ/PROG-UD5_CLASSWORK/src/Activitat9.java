import java.util.Scanner;

public class Activitat9 {

    final static int CONTANTE_MOSTRAR_OCUPACION = 10;
    final static int CLIENES_MAXIMOS_POR_SALAS = 10;
    final static int CLIENES_MAXIMOS_POR_GRUPO = 4;
    final static int NUMERO_DE_CLIENTES_MINIMOS = 1;
    final static int POSICION_INICIAL_DE_ARRAY = 0;
    final static int NUMERO_PARA_SALIR = -1;
    final static int NUMERO_DE_SALA_VACIA = 0;
    final static int NUMERO_DE_SALAS = 10;

    public static void main(String[] args) {

        //Es para que te lo pida por pantalla el numero de salas que quieras.
        //int[] cadenaOcupacio = generadorSalas(pedirNumeroSalas());
        int[] cadenaOcupacio = generadorSalas(NUMERO_DE_SALAS);
        int clientes;

        do{
            mostrarOcupacion(cadenaOcupacio);
            clientes = pedirNumeroClientes();
            ubicarAClientes(cadenaOcupacio, clientes);

        } while (clientes != NUMERO_PARA_SALIR);
    }

    public static void despedida(){
        System.out.println("Adios");
    }

    public static int[] generadorSalas(int numeroDeSalas){

        int[] salaAleatoria = new int[numeroDeSalas];

        for (int i = POSICION_INICIAL_DE_ARRAY; i < salaAleatoria.length; i++){

            int numRandom = (int) (Math.random()*8+0);
            salaAleatoria[i] = numRandom;
        }

        return salaAleatoria;
    }

    public static void mostrarOcupacion(int[] cadenaDeOcupacion){

        System.out.print("┌────────────");
        for(int i = POSICION_INICIAL_DE_ARRAY; i < cadenaDeOcupacion.length; i++){
            System.out.print("┬──────────");
        }
        System.out.println("┐");

        System.out.print("│Sala nº     ");
        for(int i = POSICION_INICIAL_DE_ARRAY; i < cadenaDeOcupacion.length; i++){
            int imprimri = i+1;
            if (imprimri < CONTANTE_MOSTRAR_OCUPACION ){
                System.out.print("│     "+imprimri+"    ");
            } else {
                System.out.print("│    "+imprimri+"    ");
            }
        }
        System.out.println("│");

        System.out.print("│────────────");

        for(int i = POSICION_INICIAL_DE_ARRAY; i < cadenaDeOcupacion.length; i++){
            System.out.print("│──────────");
        }
        System.out.println("┤");

        System.out.print("│Ocupación   ");
        for(int i = POSICION_INICIAL_DE_ARRAY; i < cadenaDeOcupacion.length ; i++){
            int imprimri = cadenaDeOcupacion[i];
            if (imprimri < CONTANTE_MOSTRAR_OCUPACION ){
                System.out.print("│     "+imprimri+"    ");
            } else {
                System.out.print("│    "+imprimri+"    ");
            }
        }
        System.out.println("│");

        System.out.print("└────────────");
        for(int i = POSICION_INICIAL_DE_ARRAY; i < cadenaDeOcupacion.length; i++){
            System.out.print("└──────────");
        }
        System.out.println("┘");
    }

    public static int[] ubicarAClientes(int[] estadoSalas, int clientes){
        if(clientes == NUMERO_PARA_SALIR){
            despedida();
            return estadoSalas;
        }

        for (int i = POSICION_INICIAL_DE_ARRAY; i < estadoSalas.length; i++){
            if (estadoSalas[i] == NUMERO_DE_SALA_VACIA){
                System.out.printf("Por favor, acuda a la sala número %d.\n", i+1);
                estadoSalas[i] = clientes;
                return estadoSalas;
            }
        }

        for (int i = 0; i < estadoSalas.length; i++){
            if (clientes + estadoSalas[i] == CLIENES_MAXIMOS_POR_SALAS){
                estadoSalas[i] += clientes;
                System.out.printf("Tendrán que compartir sala. Por favor, acudan a la sala número %d.\n",i+1);
                return estadoSalas;
            }
        }

        for (int i = 0; i < estadoSalas.length; i++) {

            int clientesSobrantes = CLIENES_MAXIMOS_POR_SALAS - estadoSalas[i];
            if(estadoSalas[i] + clientes < CLIENES_MAXIMOS_POR_SALAS && clientesSobrantes >= clientes){
                System.out.printf("Tendrán que compartir sala. Por favor, acudan a la sala número %d.\n",i+1);
                estadoSalas[i] += clientes;
                return estadoSalas;
            }
        }

        System.out.println("No queda hueco para vosotros. Deberéis volver otro día.");
        return estadoSalas;
    }

    public static int pedirNumeroClientes(){

        Scanner teclado = new Scanner(System.in);
        int numeroClientes;

        do{

            System.out.print("¿Cuántos son? [1-4] (Introduzca -1 para salir del programa): ");

            if(!teclado.hasNextInt()){
                System.out.println("No entiendo tu respuesta. Introduzca un nuevo número de clientes");
                teclado.next();
            } else {
                numeroClientes = teclado.nextInt();

                if (numeroClientes > CLIENES_MAXIMOS_POR_GRUPO){
                    System.out.println("Lo siento, no admitimos grupos de "+ numeroClientes +", haga grupos de 4 " +
                            "personas como máximo e intente de nuevo.");
                } else if (numeroClientes < NUMERO_PARA_SALIR){
                    System.out.println("Lo siento. La reserva sólo se puede hacer entre 1 y 4 personas. Introduzca " +
                            "un nuevo número de clientes");
                } else {
                    return numeroClientes;
                }
            }

        }while (true);
    }

    public static int pedirNumeroSalas(){

        Scanner teclado = new Scanner(System.in);
        int numeroClientes;

        do{

            System.out.print("¿Cuántas las salas son?: ");

            if(!teclado.hasNextInt()){
                System.out.println("No entiendo tu respuesta. Introduzca un nuevo número de salas");
                teclado.next();
            } else {
                numeroClientes = teclado.nextInt();

                if (numeroClientes < NUMERO_DE_CLIENTES_MINIMOS){
                    System.out.println("Lo siento, no admitimos menos de 1 sala.");
                } else {
                    return numeroClientes;
                }
            }

        }while (true);
    }
}