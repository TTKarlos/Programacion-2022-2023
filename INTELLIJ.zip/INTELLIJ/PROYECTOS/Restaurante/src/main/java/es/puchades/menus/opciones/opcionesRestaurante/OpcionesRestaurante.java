package entities.menu.opciones;

import es.puchades.Restaurante;
import es.puchades.menus.opciones.Opcion;

public abstract class OpcionesRestaurante extends Opcion {
    protected Restaurante restaurante;

    public OpcionesRestaurante(String titulo, Restaurante restaurante) {
        super(titulo);
        this.restaurante = restaurante;
    }
}