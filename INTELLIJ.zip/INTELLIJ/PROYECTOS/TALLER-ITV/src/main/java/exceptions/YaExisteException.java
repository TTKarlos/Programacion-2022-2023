package exceptions;

public class YaExisteException extends Exception{
    public YaExisteException(){
        super("Error! Ya existe el vehiculo");
    }
}