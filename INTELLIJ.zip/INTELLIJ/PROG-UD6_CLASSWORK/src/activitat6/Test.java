package activitat6;

import activitat3.Rectangle;

public class Test {
    public static void main(String[] args) {
        activitat3.Rectangle r1 = new activitat3.Rectangle(100, 200);
        System.out.println("El area de r1 es: " + r1.obtenerArea());
        activitat3.Rectangle r2 = new activitat3.Rectangle(40, 100);
        System.out.println("El area de r2 es: " + r2.obtenerArea());
        activitat3.Rectangle r3 = new activitat3.Rectangle(80, 43);
        System.out.println("El area de r3 es: " + r3.obtenerArea());
        activitat3.Rectangle r4 = new activitat3.Rectangle(56, 90);
        System.out.println("El area de r4 es: " + r4.obtenerArea());
        activitat3.Rectangle r5 = new activitat3.Rectangle(100, 150);
        System.out.println("El area de r5 es: " + r5.obtenerArea());
        activitat3.Rectangle r6 = new Rectangle(200, 120);
        System.out.println("El area de r6 es: " + r6.obtenerArea());
    }
}