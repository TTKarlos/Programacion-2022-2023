package es.cipfpbatoi.plantillaexamen.model.dao.interfaces;

import es.cipfpbatoi.plantillaexamen.model.utils.libro.Libro;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public interface LibroDAOInterface {
    ArrayList<Libro> findAll();
    Libro findByTitulo(String titulo);
    boolean save(Libro libro);
    boolean remove(Libro libro);
    ArrayList<Libro> findAllBuscador(String cadena);
}