import java.util.Scanner;

public class Activitat13 {

    final static float PI = 3.1415f;
    final static int DIVISOR_FORMULA_AREA_TRIANGLE = 2;

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introdueix el valor del 'radi' d'un cercle: ");
        float radiDelCircul= teclado.nextFloat();

        System.out.print("Ara introdueix el valor de la 'base' d'un triangle:  ");
        float baseDelTriangle= teclado.nextFloat();

        System.out.print("I finalment, la seua 'altura': ");
        float alturaDelTriangle= teclado.nextFloat();

        float areaDelCircul = PI * radiDelCircul*radiDelCircul;
        float perimetredelCircul = 2 * PI * radiDelCircul;
        float areaDelTriangle = (baseDelTriangle * alturaDelTriangle) / DIVISOR_FORMULA_AREA_TRIANGLE;

        System.out.println("\nRESULATS\n--------");
        System.out.printf("Cercle: Perímetre -> %.2f Àrea -> %.2f", perimetredelCircul, areaDelCircul);
        System.out.printf("\nTriangle: Àrea -> %.2f", areaDelTriangle);

    }
}