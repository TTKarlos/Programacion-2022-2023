package com.example.batoiflix.modelo.entities;

public class Productor {
    private int id;
    private String nombre;

    public Productor(int id, String nombre) {
        this.nombre = nombre;
        this.id = id;
    }

    public Productor(String nombre) {
        this.nombre = nombre;
        this.id = -1;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setId(int id) {
        this.id = id;
    }
}