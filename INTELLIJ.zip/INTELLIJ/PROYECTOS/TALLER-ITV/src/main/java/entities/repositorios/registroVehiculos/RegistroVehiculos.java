package entities.repositorios.registroVehiculos;

import entities.repositorios.registroVehiculos.type.VehiculoRegistrado;
import exceptions.ColaVaciaException;
import exceptions.YaExisteException;
import java.time.LocalDate;
import java.util.ArrayList;

public class RegistroVehiculos {
    private ArrayList<VehiculoRegistrado> vehiculoRegistrados;

    public RegistroVehiculos() {
        this.vehiculoRegistrados = new ArrayList<>();
    }

    public ArrayList<VehiculoRegistrado> getVehiculoRegistrados() {
        return vehiculoRegistrados;
    }

    public void anyadir(String matricula, LocalDate fechaRevision, String dniMecanico, double importe){
        VehiculoRegistrado vehiculoRegistrado = new VehiculoRegistrado(matricula, fechaRevision, dniMecanico, importe);

        try{
            existeVehiculo(vehiculoRegistrado);
            vehiculoRegistrado.setCodigo(vehiculoRegistrados.size() + 1);
            vehiculoRegistrados.add(vehiculoRegistrado);
        }catch (YaExisteException e){
            System.out.println(e.getMessage());
        }
    }

    public ArrayList<VehiculoRegistrado> devolverPorFecha(LocalDate fechaInicio, LocalDate fechaFinalizacion){
        ArrayList<VehiculoRegistrado> vehiculoRegistradosNuevos = new ArrayList<>();

        for (int i = 0; i < vehiculoRegistrados.size(); i++) {
            if(vehiculoRegistrados.get(i).getFechaRevision().isAfter(fechaInicio) &&
                    vehiculoRegistrados.get(i).getFechaRevision().isBefore(fechaFinalizacion)){
                vehiculoRegistradosNuevos.add(vehiculoRegistrados.get(i));
            }
        }

        return vehiculoRegistradosNuevos;
    }

    private boolean existeVehiculoIgual(VehiculoRegistrado vehiculoRegistrado){
        for (int i = 0; i < vehiculoRegistrados.size(); i++) {
            if(vehiculoRegistrados.get(i).equals(vehiculoRegistrado)){
                return true;
            }
        }

        return false;
    }

    private void existenVehiculos() throws ColaVaciaException {
        if (this.vehiculoRegistrados.isEmpty()) {
            throw new ColaVaciaException("vehiculos");
        }
    }

    private void existeVehiculo(VehiculoRegistrado vehiculoRegistrado) throws YaExisteException {
        if(existeVehiculoIgual(vehiculoRegistrado)){
            throw new YaExisteException();
        }
    }
}