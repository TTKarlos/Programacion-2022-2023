package com.example.batoiflix.modelo.entities;

public class Actores {
    private int codigo;
    private String nombre;

    public Actores(int codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    public Actores(String nombre){
        this.codigo = -1;
        this.nombre = nombre;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCodigo() {
        return codigo;
    }
}