package Activitat16;

public class Matematica {

    final static int NUM_DE_BASES_Y_ALTURES = 2;

    public static double obtindreEquacioGrau2(int a, int b, int c, boolean solucio1) {
        double raiz = obtindrePotencia(b, 2) - (obtindreMultiplicacio(4,obtindreMultiplicacio(a, c)));
        raiz = obtindreArrelQuadrada(raiz);
        double denominador = obtindreMultiplicacio(2, a);
        double numerador = obtindreMultiplicacio(-1, b);

        double solucio;

        if (solucio1) {
            numerador = obtindreSuma((int) numerador, (int) raiz);
        } else {
            numerador = obtindreResta((int) numerador, (int) raiz);
        }
        solucio = obtindreDivisio((int) numerador, (int) denominador);

        return solucio;
    }

    public static int obtindreAreaRectangle(double base, double altura){
        return (obtindreMultiplicacio((int) base, (int) altura));
    }

    public static int obtindreVolumPrisma(double ample, double alt, double profunditat){
        return obtindreMultiplicacio((int) ample, obtindreMultiplicacio((int) alt, (int) profunditat));
    }

    public static int obtindreSuma(int num1, int num2){
        return num1 + num2;
    }

    public static int obtindreResta(int num1, int num2){
        return num1 - num2;
    }

    public static int obtindreMultiplicacio(int num1, int num2){
        return num1 * num2;
    }

    public static double obtindreDivisio(int num1, int num2){
        return (double) num1 / num2;
    }

    public static int obtindreModul(int num1, int num2){
        return num1 % num2;
    }

    public static double obtindreArrelQuadrada(double num1){
        return (int) Math.sqrt(num1);
    }

    public static int obtindrePotencia(int base, int exponent){
        return (int) Math.pow(base, exponent);
    }
}
