package E2021;

import java.util.Scanner;

public class EjercicioCamion {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("PROGRAMA FACTURACIÓN “RECICLA Batoi”:");
        System.out.println("=========================");
        System.out.print("Número de Camiones (N): ");

        int numcCamiones = teclado.nextInt();

        float pagarPorDia = 0;
        float totalPagar = 0;
        int numDia = 1;
        int numServicio = 1;

        for (int i = 1; i <= numcCamiones; i++){
            for (numDia = 1; numDia <= 3; numDia++){
                for (numServicio = 1; numServicio <= 4; numServicio++){
                    System.out.print("Introduce los kg recogidos en el servicio " + numDia + " del dia " + numServicio + " por el camión " + i + ": ");
                    float kilosPorDia = teclado.nextFloat();

                    if (kilosPorDia < 1000){
                        pagarPorDia += kilosPorDia * 0.5f;
                    } else {
                        pagarPorDia += kilosPorDia * 0.25f;
                    }
                }
                System.out.printf("Los pagos por el camión " + i + " en el dia " + numDia + " es de %.2f€\n", pagarPorDia);

                totalPagar += pagarPorDia;

                pagarPorDia = 0;
            }
            System.out.printf("El total a pagar semanalmente por el camión " + i + " es %.2f€", totalPagar);
        }
    }
}
