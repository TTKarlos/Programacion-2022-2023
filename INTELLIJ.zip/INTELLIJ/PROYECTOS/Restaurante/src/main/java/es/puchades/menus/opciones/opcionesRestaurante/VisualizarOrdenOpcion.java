package entities.menu.opciones;

import es.puchades.GestorIO;
import es.puchades.Restaurante;
import es.puchades.menus.Menu;
import es.puchades.menus.opciones.Opcion;
import es.puchades.menus.opciones.opcionesVisualizarPedido.BuscarPedidoHistoricoOpcion;
import es.puchades.menus.opciones.opcionesVisualizarPedido.BuscarPedidoPreparado;

public class VisualizarOrdenOpcion extends OpcionesRestaurante {
    final static String TEXTO_MENU = "================\n" + GestorIO.COLOR_AZUL + "Visualizar Pedido" +
            GestorIO.RESET_COLOR + "\n================";
    protected Restaurante restaurante;

    public VisualizarOrdenOpcion(Restaurante restaurante) {
        super("Visualizar Orden", restaurante);
        this.restaurante = restaurante;
    }

    @Override
    public void ejecutar() {
        Menu menuVisualizarPedido = new Menu(TEXTO_MENU);
        Opcion opcion1 = new BuscarPedidoHistoricoOpcion(restaurante);
        Opcion opcion2 = new BuscarPedidoPreparado(restaurante);
        opcion1.setFinalizar(true);
        opcion2.setFinalizar(true);
        menuVisualizarPedido.anyadir(opcion1);
        menuVisualizarPedido.anyadir(opcion2);
        menuVisualizarPedido.ejecutar();
    }
}