package es.puchades.enums;

public enum TamanyoDeBebida {
    GRANDE{
        public String toString(){
            return "GRANDE";
        }
    },
    MEDIANA{
        public String toString(){
            return "MEDIANA";
        }
    },
    PEQUENYA{
        public String toString(){
            return "PEQUEÑA";
        }
    },
}