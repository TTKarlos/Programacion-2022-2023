import java.util.Scanner;

public class Activitat24 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introdueix un nombre: ");
        String cadena = teclado.nextLine();
        System.out.printf("\"%s\" --> %B ",cadena, esCapicua(cadena));
    }

    public static boolean esCapicua(String cadena){

        String cadenaInversa = "";
        String cadenaSenseEspais = "";

        for (int i = 0; i < cadena.length(); i++){

            String posicion = String.valueOf(cadena.charAt(i));

            if (posicion.equalsIgnoreCase(" ")){

            } else {
                cadenaSenseEspais = posicion + cadenaSenseEspais;
            }
        }

        for (int i = cadenaSenseEspais.length() - 1; i >= 0; i--){

            cadenaInversa += String.valueOf(cadenaSenseEspais.charAt(i));

        }

        return cadenaSenseEspais.equalsIgnoreCase(cadenaInversa);
    }
}