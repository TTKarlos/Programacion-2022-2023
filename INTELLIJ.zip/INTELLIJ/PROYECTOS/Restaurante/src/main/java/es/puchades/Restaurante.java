package es.puchades;

import es.puchades.exceptions.ColaVaciaExeption;
import es.puchades.exceptions.NoEncontradoException;
import es.puchades.pedido.ColaDePedidosPendientes;
import es.puchades.pedido.HistoricoPedidos;
import es.puchades.pedido.Pedido;
import es.puchades.view.ListadoPedidosView;
import es.puchades.view.PedidoView;
import java.util.ArrayList;

public class Restaurante {
    final static String TEXTO_ERROR_PEDIDO = "Elige un numero de pedido correcto";
    final static String TEXTO_NO_HAY_PEDIDOS = "Error! No hay pedidos";
    final static String TEXTO_SERVIR_PEDIDO = "Seguro que quieres servir este pedido [SI - NO]: ";
    final static String TEXTO_INTRODUCIR_COMENTARIO = "Introduce un comentario por la cancelacion: ";
    final static String TEXTO_INTRODUCIR_FECHA = "Introduce la fecha de los pedidos en formato dd/mm/yyyy: ";
    final static String TEXTO_ERROR_PEDIDO_INVALIDO = "Error! Elige un pedido correcto";
    private int numPedido;
    private Cambrer cambrer;
    private HistoricoPedidos historicoPedidos;
    private ColaDePedidosPendientes colaDePedidosPendientes;

    public Restaurante(Cambrer cambrer) {
        this.numPedido = 0;
        this.cambrer = cambrer;
        this.historicoPedidos = new HistoricoPedidos();
        this.colaDePedidosPendientes = new ColaDePedidosPendientes();
    }

    //-------------------------------------------CREAR NUEVO PEDIDO---------------------------------------------------\\
    public void anyadirPedido() {
        colaDePedidosPendientes.anyadir(cambrer.atenderMesa(numPedido + 1));
        this.numPedido++;
        System.out.println(new PedidoView(colaDePedidosPendientes.getListaPedidosPendientes().get(
                colaDePedidosPendientes.getListaPedidosPendientes().size() - 1)));
    }

    //--------------------------------------------LISTAR TODOS LOS PEDIDOS--------------------------------------------\\
    public void mostrarListaPedidos(){
        ArrayList<Pedido> todosLosPedidos = getTodosLosPedidos();

        if(todosLosPedidos.isEmpty()){
            GestorIO.mostrarTextoEnError(TEXTO_NO_HAY_PEDIDOS);
            return;
        }

        System.out.println(new ListadoPedidosView(todosLosPedidos));
    }

    //---------------------------------------------VISUALIZAR ORDEN--------------------------------------------------\\
    public void buscarHistorico() {
        String fechaPedido = GestorIO.pedirFecha(TEXTO_INTRODUCIR_FECHA).substring(0, 10);
        ArrayList<Pedido> pedidos = historicoPedidos.getIn(fechaPedido);

        try {
            if(historicoPedidos.existenPedidos()){
                if(comprobarSiHayPedidos(pedidos, "Error! No existe ningun pedido con la Fecha \"" + fechaPedido + "\"")){
                    System.out.println(new ListadoPedidosView(pedidos));
                    System.out.println(new PedidoView(GestorIO.elegirUnPedido(TEXTO_ERROR_PEDIDO_INVALIDO, pedidos)));
                }
            }
        } catch (Exception e){
            GestorIO.mostrarTextoEnError(e.getMessage());
        }
    }

    public void buscarPendientes() {
        String fechaPedido = GestorIO.pedirFecha(TEXTO_INTRODUCIR_FECHA).substring(0, 10);
        ArrayList<Pedido> pedidos = colaDePedidosPendientes.getIn(fechaPedido);

        try {
            if(colaDePedidosPendientes.existenPedidos()){
                if(comprobarSiHayPedidos(pedidos, "Error! No existe ningun pedido con la Fecha \"" + fechaPedido + "\"")){
                    System.out.println(new ListadoPedidosView(pedidos));
                    System.out.println(new PedidoView(GestorIO.elegirUnPedido(TEXTO_ERROR_PEDIDO_INVALIDO, pedidos)));
                }
            }
        } catch (Exception e){
            GestorIO.mostrarTextoEnError(e.getMessage());
        }
    }

    //------------------------------------------------PREPARAR PEDIDO------------------------------------------------\\
    public void prepararPedido() {
        try {
            Pedido pedidoSiguiente = colaDePedidosPendientes.obtenerSiguiente();
            System.out.println(new PedidoView(pedidoSiguiente));

            if(GestorIO.pediSiONo(TEXTO_SERVIR_PEDIDO)){
                historicoPedidos.anyadirPedido(pedidoSiguiente);
                colaDePedidosPendientes.eliminarPedido(pedidoSiguiente);
            } else {
                colaDePedidosPendientes.eliminarPedido(pedidoSiguiente);
                colaDePedidosPendientes.anyadir(pedidoSiguiente);
            }
        } catch (Exception e){
            GestorIO.mostrarTextoEnError(e.getMessage());
        }
    }

    //------------------------------------------------CANCELAR PEDIDO------------------------------------------------\\
    public void cancelarPedido(){
        try {
            if(!colaDePedidosPendientes.existenPedidos()){
                throw new ColaVaciaExeption();
            }
        } catch (ColaVaciaExeption e){
            GestorIO.mostrarTextoEnError(e.getMessage());
            return;
        }

        System.out.println(new ListadoPedidosView(colaDePedidosPendientes.getListaPedidosPendientes()));

        Pedido pedidoACancelar = GestorIO.elegirUnPedido(TEXTO_ERROR_PEDIDO, colaDePedidosPendientes.getListaPedidosPendientes());
        pedidoACancelar.setEstaCancelado(true);
        pedidoACancelar.setComentarioDeCancelacion(GestorIO.pedirTexto(TEXTO_INTRODUCIR_COMENTARIO));

        historicoPedidos.anyadirPedido(pedidoACancelar);
        colaDePedidosPendientes.eliminarPedido(pedidoACancelar);
    }

    //-----------------------------------------------------ÚTILES-----------------------------------------------------\\
    private ArrayList<Pedido> getTodosLosPedidos(){
        ArrayList<Pedido> todosLosPedidos = new ArrayList<>();

        for (int i = 0; i < colaDePedidosPendientes.getListaPedidosPendientes().size(); i++) {
            todosLosPedidos.add(colaDePedidosPendientes.getListaPedidosPendientes().get(i));
        }

        for (int i = 0; i < historicoPedidos.getListaPedidosServidos().size(); i++) {
            todosLosPedidos.add(historicoPedidos.getListaPedidosServidos().get(i));
        }

        return todosLosPedidos;
    }

    private boolean comprobarSiHayPedidos(ArrayList<Pedido> listaPedidos, String textoError){
        if(listaPedidos.isEmpty()){
            throw new NoEncontradoException(textoError);
        }

        return true;
    }
}