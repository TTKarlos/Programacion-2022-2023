package entities.vehiculos.type;

import entities.vehiculos.Vehiculo;
import java.time.LocalDate;

public class MicroBus extends Vehiculo {
    public MicroBus(String matricula, String marca, String modelo, LocalDate fechaUltimaRevision,
                    int cilindros, int numeroPlazas, int potenciaDeCC) {
        super(matricula, marca, modelo, fechaUltimaRevision, cilindros, numeroPlazas, potenciaDeCC);
    }

    public MicroBus(String matricula, String marca, String modelo, int cilindros,
                 int numeroPlazas, int potenciaDeCC) {
        super(matricula, marca, modelo, LocalDate.of(2021, 12 , 12), cilindros, numeroPlazas, potenciaDeCC);
    }

    @Override
    public double calcularPrecioRevision(){
        double precioAdicional = 0;

        precioAdicional += 2 * (numeroPlazas - 3);

        return precioAdicional + super.calcularPrecioRevision();
    }
}