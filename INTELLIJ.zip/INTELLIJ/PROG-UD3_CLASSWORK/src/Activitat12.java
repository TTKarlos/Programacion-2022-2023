import java.util.Scanner;

public class Activitat12 {

    final static int VALOR_12 = 12;
    final static int VALOR_13 = 13;
    final static int VALOR_8 = 8;
    final static float VALOR_85 = 8.5f;
    final static int VALOR_14 = 14;
    final static int VALOR_16 = 16;
    final static int VALOR_18 = 18;
    final static int VALOR_9 = 9;
    final static int VALOR_10 = 10;
    final static int VALOR_11 = 11;
    final static float MESURA_PER_A_TIPUS_DE_MESURA = 1.5f;

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        float sistolica;
        System.out.print("Introdueix la mesura sistòlica: ");
        if (!teclado.hasNextFloat()){
            System.out.println("Error! El tipus de dades introduït és incorrecte");
            return;
        } else sistolica = teclado.nextFloat();
        if (sistolica < 4 || sistolica > 25){
            System.out.println("Error! La mesura introduïda no és correcta");
            return;
        }
        System.out.print("Introdueix la mesura diastòlica: ");

        float diastolica;
        if (!teclado.hasNextFloat()){
            System.out.println("Error! El tipus de dades introduït és incorrecte");
            return;
        } else diastolica = teclado.nextFloat();
        if (diastolica < 2 || diastolica > 14){
            System.out.println("Error! La mesura introduïda no és correcta");
            return;
        }

        System.out.print("Tipus de tensió arterial -> ");

        if (sistolica < VALOR_12 && diastolica < VALOR_8){
            System.out.print("Òptima ");
        } else if (sistolica >= VALOR_12 && sistolica < VALOR_13 && diastolica >= VALOR_8 && diastolica < VALOR_85){
            System.out.print("Normal ");
        } else if (sistolica >= VALOR_13 && sistolica < VALOR_14 && diastolica >= VALOR_85 && diastolica < VALOR_9){
            System.out.print("Normal-Alta ");
        } else if (sistolica >= VALOR_14 && sistolica < VALOR_16 && diastolica >= VALOR_9 && diastolica < VALOR_10){
            System.out.print("Grau 1 ");
        } else if (sistolica >= VALOR_16 && sistolica < VALOR_18 && diastolica >= VALOR_10 && diastolica < VALOR_11){
            System.out.print("Grau 2 ");
        } else if (sistolica >= VALOR_18 && diastolica >= VALOR_11){
            System.out.print("Grau 3 ");
        } else if (sistolica >= VALOR_14 && diastolica <VALOR_9){
            System.out.print("Sistòlica aïllada ");
        } else {
            System.out.print("Error! Les mesures introduïdes no son suportades per un esser humà");
            return;
        }

        float tipusDeMesura = diastolica * MESURA_PER_A_TIPUS_DE_MESURA;

        if (sistolica >= tipusDeMesura - 0.5 && sistolica <= tipusDeMesura + 0.5){
            System.out.println("compensada");
        } else System.out.println("descompensada");
    }
}