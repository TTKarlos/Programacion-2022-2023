package es.cipfpbatoi.plantillaexamen.model.utils;

public class Editorial {
    private int id;
    private String nombre;
    private String nif;

    public Editorial(int id, String nombre, String nif) {
        this.id = id;
        this.nombre = nombre;
        this.nif = nif;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNif() {
        return nif;
    }
}