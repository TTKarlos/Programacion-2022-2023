package exceptions;

public class VehiculoIncorrectoException extends Exception{
    public VehiculoIncorrectoException(){
        super("Error! El vehiculo no esta permitido en nuestro taller");
    }
}