package activitat8;

public enum tamanio {
    }
