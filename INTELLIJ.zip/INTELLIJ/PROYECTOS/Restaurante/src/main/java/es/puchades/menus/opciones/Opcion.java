package entities.menu;

import es.puchades.GestorIO;

public abstract class Opcion {
    private String titulo;
    private boolean finalizar;

    public Opcion(String titulo) {
        this.titulo = titulo;
        this.finalizar = false;
    }

    public void mostrar(int numOpcion) {
        System.out.println(GestorIO.COLOR_ROJO + numOpcion + ") " + GestorIO.RESET_COLOR + titulo);
    }

    public abstract void ejecutar();

    public boolean finalizar() {
        return finalizar;
    }

    public void setFinalizar(boolean finalizar) {
        this.finalizar = finalizar;
    }
}
