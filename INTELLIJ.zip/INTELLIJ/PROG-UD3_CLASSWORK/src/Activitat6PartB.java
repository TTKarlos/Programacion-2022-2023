import java.util.Scanner;

public class Activitat6PartB {
    public static void main(String[] args) {
            Scanner teclado = new Scanner(System.in);

            System.out.println("Que tipus de brosa tens que tirar:\n 1. Plastic\n 1. Organic\n 3. Paper\n 4. Cartro\n 5. Un altre");
            System.out.println("Introdueix una opció [1-5]");
            int basuraNumero = teclado.nextInt();

            if (basuraNumero == 1){
                System.out.println("Deus de tirar-lo al contenidor groc");
            } else if (basuraNumero == 2){
                System.out.println("Deus de tirar-lo al contenidor gris");
            } else if (basuraNumero == 3){
                System.out.println("Deus de tirar-lo al contenidor blau");
            } else if (basuraNumero == 4){
                System.out.println("Deus de tirar-lo al contenidor blau");
            } else if (basuraNumero == 5){
                System.out.println("Deus de tirar-lo al contenidor verd");
            } else System.out.println("ERROR!");
    }
}
