package exceptions;

public class VehiculoNoExisteException extends RuntimeException{
    public VehiculoNoExisteException(){
        super("Error! El vehículo no se encuentra en nuestros talleres");
    }
}