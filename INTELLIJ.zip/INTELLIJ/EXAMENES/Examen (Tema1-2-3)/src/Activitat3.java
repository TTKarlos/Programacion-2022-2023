import java.util.Scanner;

public class Activitat3 {

    final static int NUMERO_DE_SEMANAS_TOTALES = 4;
    final static int NUMERO_DE_SERVICIOS_TOTALES = 4;
    final static int SUELO_FIJO_BASE = 900;
    final static int DINERO_POR_HORA = 6;

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        int numCocineros = 0;
        System.out.println("PROGRAMA NÓMINAS (Empresa CtaeringBuenp)\n-------------------------------------");
        System.out.print("Número de cocineros (N): ");
        if (!teclado.hasNextInt()){
            return;
        } else{
            numCocineros = teclado.nextInt();
        }

        for (int i = 1; i <= numCocineros; i++){

            float horasTotales = 0;
            float dineroDeHorasTotales = 0;
            float horasPorServicio = 0;

            for (int j = 1; j <= NUMERO_DE_SEMANAS_TOTALES; j++){

                float dineroSemanal = 0;
                float dineroDeSuplementos = 0;

                for( int x = 1; x <= NUMERO_DE_SERVICIOS_TOTALES; x++ ){
                    System.out.printf("Semana %d del cocinero %d del servicio %d (horas): ", j, i, x);

                    if(!teclado.hasNextFloat()){
                        return;
                    } else {
                        horasPorServicio = teclado.nextFloat();
                    }

                    float dineroDeSuplementoPorHoras = 0;

                    if (horasPorServicio < 5){
                        dineroDeSuplementoPorHoras = DINERO_POR_HORA * 0.15f;
                        dineroDeSuplementos = dineroDeSuplementoPorHoras * horasPorServicio;
                    } else {
                        dineroDeSuplementoPorHoras = DINERO_POR_HORA * 0.30f;
                        dineroDeSuplementos = dineroDeSuplementoPorHoras * horasPorServicio;
                    }
                    dineroSemanal += dineroDeSuplementos;
                    horasTotales += horasPorServicio;
                }
                System.out.printf("El suplemento del cocinero %d en la semana %d es de %.2f €\n", i, j, dineroSemanal);
                dineroDeHorasTotales += dineroSemanal;
            }
            float dineroTotal = horasTotales * DINERO_POR_HORA;
            dineroTotal += SUELO_FIJO_BASE + dineroDeHorasTotales;
            System.out.printf("El sueldo mensual del conicero %d es %.2f con un total de %.2f horas trabajadas.\n", i, dineroTotal, horasTotales);
        }
    }
}