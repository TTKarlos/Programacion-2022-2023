public class Actividad16_9 {

    /**
     * @Error: En la linea 13 sempre sera false, perque si comparem un int en un float mai sera igual ja que el
     * ordinador no enten la diferencia. el que faria seria en la linea 12 y 13 cambiar de "int" a "float", y al final
     * de cada numero possar una "f". Cambiar la posicio de la divisio al contrari --> boolean esCorrecte = operand2 / operand1 == resultatEsperat;
     * @Tipus: Temps de sintaxis.
     **/

    public static void main(String[] args) {

        float operand1 = 20f;
        float operand2 = 50f;
        float resultatEsperat = 2.5f;
        boolean esCorrecte = operand1 / operand2 == resultatEsperat;
        System.out.println("Es correcte el resultat: " + esCorrecte);

    }
}
