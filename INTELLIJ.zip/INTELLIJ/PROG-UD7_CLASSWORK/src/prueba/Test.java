package prueba;

public class Test {
    public static void main(String[] args) {
        A a = new A(3);
    }
}