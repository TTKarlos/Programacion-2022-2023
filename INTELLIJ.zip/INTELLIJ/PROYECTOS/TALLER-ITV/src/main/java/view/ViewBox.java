package view;

import de.vandermeer.asciitable.AT_Row;
import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;
import entities.Box;
import entities.vehiculos.Vehiculo;

public class ViewBox {
    private Box box;
    private int numBox;

    public ViewBox(Box box, int numBox){
        this.box = box;
        this.numBox = numBox;
    }

    private String getTablaPedido(){
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow(null, null, null, null, "BOX " + numBox);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow(null, null, null, null, "El Mecanico esta en la Fase " + (box.getPosicionMecanico() + 1));
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow("Fase", "Estado", "Matricula del Vehiculo", "Marca", "Modelo");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        Vehiculo[] vehiculos = box.getVehiculos();

        for (int i = 0; i < vehiculos.length; i++) {
            table.addRule();

            if(vehiculos[i] != null){
                row = table.addRow((i + 1), box.getFASES()[i], vehiculos[i].getMatricula(), vehiculos[i].getMarca(),
                        vehiculos[i].getModelo());
            } else {
                row = table.addRow((i + 1), box.getFASES()[i], null, null, "No hay ningun Vehiculo en esta Fase");
            }

            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        }

        table.addRule();
        row = table.addRow("*", "*", "*", "*", "*");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        table.addRule();

        return table.render();
    }

    @Override
    public String toString() {
        return getTablaPedido();
    }
}
