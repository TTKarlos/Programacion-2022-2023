import java.util.Scanner;

public class Activitat3 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Escriu una qualificació numerica: ");
        float qualificacio = teclado.nextFloat();

        if (qualificacio < 0 || qualificacio > 10){
            System.out.println("ERROR!");
        }if (qualificacio < 3){
            System.out.println("MOLT DEFICIENT");
        }else if (qualificacio < 5) {
            System.out.println("INSUFICIENT");
        }else if  (qualificacio < 6) {
            System.out.println("SUFICIENT");
        }else if  (qualificacio < 7) {
            System.out.println("BÉ");
        }else if (qualificacio < 9){
            System.out.println("NOTABLE");
        }else if (qualificacio <= 10){
            System.out.println("EXELENT");
        }
    }

}
