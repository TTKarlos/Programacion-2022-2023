package es.cipfpbatoi.gestorusuariosv2.model.dao.interfaces;

import es.cipfpbatoi.gestorusuariosv2.model.entities.Empresa;
import es.cipfpbatoi.gestorusuariosv2.model.entities.User;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public interface EmpresaDAO {
    ArrayList<Empresa> findAll();
    Empresa findById(int codigo);
    boolean save(Empresa empresa);
    boolean remove(Empresa empresa);
}