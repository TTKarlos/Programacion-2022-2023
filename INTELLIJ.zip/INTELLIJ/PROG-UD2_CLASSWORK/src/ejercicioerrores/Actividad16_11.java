import java.util.Scanner;

/**
 * @Error: Tenim que cambiar el "println" a "printf" en la linea 18 y ademès añadir un "Line" en la linea 15 per a que
 * al fer el salt de linea el seguent teclat.next no el salte. --> String nom = teclat.nextLine();
 * @Tipus: Temps de compilació.
 **/

public class Actividad16_11 {

    public static void main(String[] args) {

        Scanner teclat = new Scanner(System.in);
        System.out.println("Introdueix el teu nom");
        String nom = teclat.nextLine();

        System.out.println("Introdueix els teus cognoms separats per un espai");
        String cognoms = teclat.nextLine();

        System.out.printf("El teu nom complet es %s, %s", cognoms, nom);
    }
}
