package activitat7;

public class Coche {

    private String marca;
    private String modelo;
    private String color;
    private boolean pinturaMetalizada;
    private String matricula;
    private int añoDeFabricacion;

    public Coche(){
        this.marca = "Ferrari";
        this.modelo = "F40";
        this.color = "rojo";
        this.pinturaMetalizada = true;
        this.matricula = "A 5492 OR";
        this.añoDeFabricacion = 1980;
    }

    public Coche(String marca, String modelo, String color, boolean pinturaMetalizada,
                 String matricula, int añoDeFabricacion){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.pinturaMetalizada = pinturaMetalizada;
        this.matricula = matricula;
        this.añoDeFabricacion = añoDeFabricacion;
    }
    public void mostrarInformacion(){
        System.out.printf("Marca: %s\nModelo: %s\nColor: %s\nTiene pintura metalizada: %b\nMatricula: %s\nAño de fabricacion: %d\n", marca, modelo, color, pinturaMetalizada, matricula,añoDeFabricacion);
    }
}