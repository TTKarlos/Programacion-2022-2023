package exception;

public class ReservaNoEncontradaException extends Exception{
    public ReservaNoEncontradaException(int codReserva){
        super("La reserva " + codReserva + " no ha sido encontrada");
    }
}