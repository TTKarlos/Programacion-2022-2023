package entities.menu.opciones;

import es.puchades.Restaurante;

public class CancelarPedidoOpcion extends OpcionesRestaurante {
    protected Restaurante restaurante;

    public CancelarPedidoOpcion(Restaurante restaurante) {
        super("Cancelar un Pedido", restaurante);
        this.restaurante = restaurante;
    }

    @Override
    public void ejecutar() {
        restaurante.cancelarPedido();
    }
}