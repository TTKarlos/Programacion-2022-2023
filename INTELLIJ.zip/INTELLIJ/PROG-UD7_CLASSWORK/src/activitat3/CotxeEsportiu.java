package activitat3;

public class CotxeEsportiu extends Coxte{

    private boolean esportiu;

    public CotxeEsportiu(int velocitat, int carburante, String matricula, boolean esportiu){
        super(velocitat, carburante, matricula);
        this.esportiu = esportiu;
    }

    @Override
    public String toString() {
        return super.toString() + "esportiu: " + esportiu;
    }
}