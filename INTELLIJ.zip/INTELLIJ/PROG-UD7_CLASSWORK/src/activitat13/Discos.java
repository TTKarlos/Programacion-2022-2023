package activitat13;

public class Discos extends MaterialPrestamo{
    private String nombreDiscografia;

    public Discos(int codigoIdentificativo, String titulo, String autor, String nombreDiscografia) {
        super(codigoIdentificativo, titulo, autor);
        this.nombreDiscografia= nombreDiscografia;

    }
}