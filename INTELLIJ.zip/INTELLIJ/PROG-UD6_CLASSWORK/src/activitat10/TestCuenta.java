package activitat10;

public class TestCuenta {
    public static void main(String[] args) {

        CuentaBancaria listado[] = new CuentaBancaria[2];

        listado[0] = new CuentaBancaria("Pepe Perez", "00010021", 0, false);
        listado[1] = new CuentaBancaria("Juan Sánchez", "214521421", 30000, true);

        listado[0].ingreso(1000);
        listado[0].reintegro(100);

        listado[1].reintegro(500);

        for(int i = 0; i < listado.length; i++){
            listado[i].mostrarInformacion();
            System.out.println();
        }
    }
}