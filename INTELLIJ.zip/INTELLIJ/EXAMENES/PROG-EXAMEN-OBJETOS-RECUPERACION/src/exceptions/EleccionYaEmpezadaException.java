package exceptions;

public class EleccionYaEmpezadaException extends RuntimeException{
    public EleccionYaEmpezadaException(String mensaje){
        super(mensaje);
    }
}