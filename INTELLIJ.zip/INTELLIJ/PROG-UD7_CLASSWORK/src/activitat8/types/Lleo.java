package activitat8.types;

import activitat8.Animal;
import activitat8.enums.Comida;
import activitat8.enums.Tamany;

public class Lleo extends Animal {
    public  Lleo(boolean vacunado, Comida comida, int hambre, Tamany tamanio, String localizacion){
        super(vacunado, comida, hambre, tamanio, localizacion);
    }

    public void emitirSonido(){
        System.out.println("ARGHHHHHHHH!!!!!!!!!");
    }

    @Override
    public void vacunar(){
        System.out.println("Vacunando a un Leon...");
        super.vacunar();
        emitirSonido();
    }

    @Override
    public String toString() {
        return "Leon: " + super.toString();
    }
}