public class Resultado {
    private Partido partido;
    private int votos;

    public Resultado(Partido partido, int votos) {
        this.partido = partido;
        this.votos = votos;
    }

    public Partido getPartido() {
        return partido;
    }

    public int getVotos() {
        return votos;
    }
}