import java.util.Scanner;

public class Activitat7 {
    public static void main(String[] args) {

        Scanner teclat = new Scanner(System.in);

        System.out.println("Introduce un númeor entero: ");
        int num1 = teclat.nextInt();
        System.out.println("Introduce un númeor entero: ");
    }
}
