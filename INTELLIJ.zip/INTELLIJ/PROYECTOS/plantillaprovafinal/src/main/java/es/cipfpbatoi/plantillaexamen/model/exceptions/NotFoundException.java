package es.cipfpbatoi.plantillaexamen.model.exceptions;

public class NotFoundException extends Exception{
    public NotFoundException(String titulo){
        super("El libro con el titulo " + titulo + " no existe.");
    }
}