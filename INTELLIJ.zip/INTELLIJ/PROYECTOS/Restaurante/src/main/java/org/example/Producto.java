package org.example;

public class Producto {
    final static int BASE_DE_PORCENTAJE = 100;
    private String nombre;
    private String descripcion;
    private float precioBase;
    private float decuento;
    private float iva;

    public Producto(String codigoProducto) {
        this.nombre = codigoProducto;
    }

    public Producto(String nombre, String descripcion, float precioBase, float decuento, float iva){
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precioBase = precioBase;
        this.decuento = decuento;
        this.iva = iva;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public float getDecuento() {
        return decuento;
    }

    public float getPrecioBase() {
        return precioBase;
    }

    public float calcularElPrecioPVP(){
        float precioPVP = precioBase * (1 + (iva / BASE_DE_PORCENTAJE));
        return precioPVP - (precioPVP * (decuento / BASE_DE_PORCENTAJE));
    }

    public String getEsRellenableEnFormato() {
        return null;
    }

    public String getCaracteristicas() {
        return null;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Producto)) {
            return false;
        }
        Producto producto = (Producto) obj;
        return nombre.equalsIgnoreCase(producto.nombre);
    }
}