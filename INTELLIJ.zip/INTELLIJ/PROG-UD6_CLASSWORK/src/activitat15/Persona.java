package activitat15;

import activitat13.Fecha;

public class Persona {

    private NIF nif;
    private String nombre;
    private String primerApellido;
    private String segundoApellido;
    private Fecha fechaDenacimiento;
    private Direccion direccion;

    public Persona( NIF nif, String nombre, String primerApellido, String segundoApellido, Fecha fechaDenacimiento, Direccion direccion){
        this.nif = nif;
        this.nombre = nombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.fechaDenacimiento = fechaDenacimiento;
        this.direccion = direccion;
    }

    public boolean esMayorDeEdad(){
        Fecha anyoActual = new Fecha(30, 1, 2023);
        return (fechaDenacimiento.getAnyosTranscurridos(anyoActual) >= 18);
    }

    public boolean estaJubilado(){
        Fecha anyoActual = new Fecha(30, 1, 2023);
        return (fechaDenacimiento.getAnyosTranscurridos(anyoActual) >= 65);
    }
}