import java.util.Scanner;

public class Activitat6 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int num1 = teclado.nextInt();
        int num2 = teclado.nextInt();
        int num3 = teclado.nextInt();

    }

    public static int donamMajor3 (int num1, int num2, int num3){

        return num1;

    }
}
