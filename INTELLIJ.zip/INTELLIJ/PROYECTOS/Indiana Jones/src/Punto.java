public class Punto {

    final static int LARGARIA_ARRAY_XY = 2;
    final static int INICIAL_INDICE = 0;
    final static int PUNTO_X = 0;
    final static int PUNTO_Y = 1;

    public static boolean sonIguales(int[] punto1, int[] punto2){
        if(punto1.length == LARGARIA_ARRAY_XY && punto2.length == LARGARIA_ARRAY_XY){
            if(punto1[PUNTO_X] == punto2[PUNTO_X]){
                if (punto1[PUNTO_Y] == punto2[PUNTO_Y]){
                    return true;
                }
            }
        }

        return false;
    }

    public static boolean hayAlgunPuntoIgual(int[] punto, int[][] listaPuntos){
        for(int i = INICIAL_INDICE; i < listaPuntos.length; i++){
             if (sonIguales(punto, listaPuntos[i])) {
                 return true;
             }
        }

        return false;
    }
}