package Practica;

import java.util.Scanner;

public class Activitat1 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
/**
        System.out.println("Introduzca un año: ");
        int any = teclado.nextInt();

        if (any % 17 == 0){
            System.out.println("El año no es lunar");
            return;
        }
        if (any % 200 == 0){
            if (any % 500 == 0);{
            System.out.println("El año es lunar");
            } else {
                System.out.println("El año no es lunar");
                return;
            }
        } else { System.out.println("El año es lunar");}
        **/
    }
}
