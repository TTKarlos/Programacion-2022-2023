package org.example;
public class Fecha {
	final static int MESES_TOTALES = 12;
	final static int ANYO_MINIMO = 0;
	final static int ANYO_ACTUAL = 2023;

	private String cadena;
	private int dia;
	private int mes;
	private int anyo;

	public Fecha(String cadena){
		this.cadena = cadena;
		if(isCorrecta()){
			String[] array = cadena.split("/");
			this.dia = Integer.parseInt(array[0]);
			this.mes = Integer.parseInt(array[1]);
			this.anyo = Integer.parseInt(array[2]);
		}
	}

	public static int getDiasMes(int mes, int anyo) {
		if(mes == 2) {
			if(isBisiesto(anyo)){
				return 29;
			} else {
				return 28;
			}

		} else if(mes == 4 || mes == 6 || mes == 9 || mes == 11){
			return 30;
		} else {
			return 31;
		}
	}

	public static boolean isBisiesto(int anyo){
		return ((anyo % 4 == 0 && anyo % 100 != 0) || (anyo % 4 == 0 && anyo % 400 == 0 && anyo % 100 == 0));
	}

	public boolean isCorrecta(){
		if(cadena.length() == 10 && String.valueOf(cadena.charAt(2)).equalsIgnoreCase("/") &&
				String.valueOf(cadena.charAt(5)).equalsIgnoreCase("/")){
			return (dia <= getDiasMes(mes, anyo) && mes <= MESES_TOTALES && anyo >= ANYO_MINIMO && anyo <= ANYO_ACTUAL);
		} else {
			return false;
		}
	}
}