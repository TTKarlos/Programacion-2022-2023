package entities.menu.opciones;

import entities.Taller;
import entities.menu.Opcion;

public abstract class OpcionesTaller extends Opcion {
    protected Taller taller;

    public OpcionesTaller(String titulo, Taller taller) {
        super(titulo);
        this.taller = taller;
    }
}