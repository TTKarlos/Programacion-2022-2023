package exceptions;

public class FechaIncorrectaException extends Exception{
    public FechaIncorrectaException(){
        super("Error! La fecha es incorrecta");
    }
}