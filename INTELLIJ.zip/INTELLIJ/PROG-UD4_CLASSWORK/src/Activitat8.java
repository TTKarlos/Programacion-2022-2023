public class Activitat8 {
    public static void main(String[] args) {
        double resultado1 = obtenirMultiplicacio(4.0, 2.3, 1.0);
        double resultado2 = obtenirMultiplicacio(0, 3.5, 4.2);
        double resultado3 = obtenirMultiplicacio(1, 2.8, 3.6);
        System.out.printf("Primera multiplicació: %.2f\nSegona multiplicació: %.2f\nTercera multiplicació: %.2f", resultado1, resultado2, resultado3);

    }
    public static double obtenirMultiplicacio(double num1, double num2, double num3){

        double resultat = num1 * num2 * num3;
        return resultat;

    }
}
