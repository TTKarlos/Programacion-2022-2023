package entities.menu.opciones;

import es.puchades.GestorIO;
import es.puchades.menus.opciones.Opcion;

public class OpcionSalir extends Opcion {
    public final static String TEXTO_SALIR = "==============================================\n" + GestorIO.COLOR_AZUL +
            "=========== Esperamos verte pronto ===========" + GestorIO.RESET_COLOR +
            "\n============================================== ";
    public OpcionSalir() {
        super("Salir");
    }

    @Override
    public void ejecutar() {
        System.out.println(TEXTO_SALIR);
        this.setFinalizar(true);
    }
}