package es.cipfpbatoi.gestorusuariosv2.model.dao.interfaces;

import es.cipfpbatoi.gestorusuariosv2.model.entities.User;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public interface UserDAO {
    ArrayList<User> findAll();
    ArrayList<User> findAll(String searchField);
    User findById(int id);
    boolean save(User user);
    boolean remove(User user);
}