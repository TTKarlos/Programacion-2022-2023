package activitat2;

public class Cliente {
    private String dni;
    private String nombre;
    private String primerApellido;

    public Cliente(String dni, String nombre, String primerApellido){
        this.dni = dni;
        this.nombre = nombre;
        this.primerApellido = primerApellido;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Cliente)){
            return false;
        }
        Cliente cliente = (Cliente) obj;
        return dni.equalsIgnoreCase(cliente.dni);
    }

    @Override
    public String toString() {
        return "Cliente " + dni + " con nombre " + nombre + " " + primerApellido;
    }
}
