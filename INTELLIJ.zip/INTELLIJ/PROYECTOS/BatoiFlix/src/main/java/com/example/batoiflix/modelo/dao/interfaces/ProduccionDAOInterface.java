package com.example.batoiflix.modelo.dao.interfaces;

import com.example.batoiflix.modelo.entities.Produccion;
import java.util.ArrayList;

public interface ProduccionDAOInterface {
    ArrayList<Produccion> findAll();
    boolean save(Produccion produccion);
}