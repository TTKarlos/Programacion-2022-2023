package es.cipfpbatoi.plantillaexamen.model.dao.interfices;

import es.cipfpbatoi.plantillaexamen.exceptions.NotFoundException;
import es.cipfpbatoi.plantillaexamen.utils.Universidad;
import org.springframework.stereotype.Service;
import java.util.ArrayList;

@Service
public interface SQLUniversidadDAOInterfice {
    Universidad findById(int id) throws NotFoundException;

    ArrayList<Universidad> findAll();

    ArrayList<Universidad> findAllBuscador(String searchField);
}