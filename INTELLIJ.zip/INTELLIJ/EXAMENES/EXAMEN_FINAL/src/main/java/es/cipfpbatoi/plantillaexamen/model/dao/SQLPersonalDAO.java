package es.cipfpbatoi.plantillaexamen.model.dao;

import es.cipfpbatoi.plantillaexamen.exceptions.NotFoundException;
import es.cipfpbatoi.plantillaexamen.model.dao.interfices.SQLPersonalDAOInterfice;
import es.cipfpbatoi.plantillaexamen.utils.Trabajador;
import es.cipfpbatoi.plantillaexamen.utils.database.MySQLConnection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.sql.*;
import java.util.ArrayList;

@Service
public class SQLPersonalDAO implements SQLPersonalDAOInterfice {

    @Autowired
    MySQLConnection mySQLConnection;
    public SQLPersonalDAO(@Autowired MySQLConnection mySQLConnection){
        this.mySQLConnection = mySQLConnection;
    }

    @Override
    public boolean save(Trabajador trabajador){
        return insert(trabajador);
    }

    private boolean insert(Trabajador trabajador){
        String sql = "INSERT INTO personal (dni, nombre, universidad_id, contratado_en) VALUE (?,?,?,?)";
        try(
                Connection connection = mySQLConnection.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql)
                ){
            preparedStatement.setString(1, trabajador.getDni());
            preparedStatement.setString(2, trabajador.getNombre());
            preparedStatement.setInt(3, trabajador.getIdUniversidad());
            preparedStatement.setTimestamp(4, Timestamp.valueOf(trabajador.getFechaContratado()));
            int comprobador = preparedStatement.executeUpdate();
            return comprobador > 0;
        }catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    public Trabajador findById(String dni) throws NotFoundException{
        Trabajador trabajador = getById(dni);

        if(trabajador == null){
            throw new NotFoundException("El trabajador con el dni " + dni + " no existe.");
        }

        return trabajador;
    }

    private Trabajador getById(String dni){
        try(
                Connection connection = mySQLConnection.getConnection();
                Statement statement = connection.createStatement()){
            String sql = String.format("SELECT * FROM personal WHERE dni LIKE = %s%%", dni);
            ResultSet resultSet = statement.executeQuery(sql);

            if(resultSet.next()){
                return mapToResultset(resultSet);
            }

            return null;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    public ArrayList<Trabajador> findAll(){
        ArrayList<Trabajador> trabajadors = new ArrayList<>();

        try(
                Connection connection = mySQLConnection.getConnection();
                Statement statement = connection.createStatement()
        ) {
            String sql = "SELECT * FROM personal";
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()){
                trabajadors.add(mapToResultset(resultSet));

            }
            return trabajadors;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public ArrayList<Trabajador> findAllBuscador(String buscadorPor, String searchField) {
        ArrayList<Trabajador> trabajadors = new ArrayList<>();

        try(
                Connection connection = mySQLConnection.getConnection();
                Statement statement = connection.createStatement()
        ) {
            String sql = String.format("SELECT * FROM personal WHERE %s LIKE '%s%%'", buscadorPor, searchField);
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()){
                trabajadors.add(mapToResultset(resultSet));

            }
            return trabajadors;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private Trabajador mapToResultset(ResultSet resultSet){
        try {
            return new Trabajador(resultSet.getString("dni"), resultSet.getString("nombre"),
                    resultSet.getInt("universidad_id"), resultSet.getTimestamp("contratado_en").toLocalDateTime());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}