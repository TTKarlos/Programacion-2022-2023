public class Actividad5 {
    public static void main(String[] args) {

        boolean a = false;
        boolean b = false;

        System.out.println("A \t\t  B \t A && B");
        System.out.println("---------------------------");

        System.out.println(a + "\t" + b + "\t" + (a && b));
        a=true;
        b=false;
        System.out.println(a + "\t" + b + "\t" + (a && b));
        a=false;
        b=true;
        System.out.println(a + "\t" + b + "\t" + (a && b));
        a=true;
        b=true;
        System.out.println(a + "\t" + b + "\t" + (a && b));
    }
}
