package Amplicacio;

import java.util.Scanner;

public class Activitat1 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Introdueix els valors x,y del centre del 1er rectangle i la seua amplària i alçada: ");

        float rectangle1CentroX;
        float rectangle1CentroY;
        float rectangle1Amplaria;
        float rectangle1Altura;

        if (!teclado.hasNextFloat() || !teclado.hasNextFloat() || !teclado.hasNextFloat() || !teclado.hasNextFloat()) {
            System.out.println("Error! El tipus de dades introduït és incorrecte");
            return;
        } else {
            rectangle1CentroX = teclado.nextFloat();
            rectangle1CentroY = teclado.nextFloat();
            rectangle1Amplaria = teclado.nextFloat();
            rectangle1Altura = teclado.nextFloat();
        }
        if (rectangle1CentroX < 0 || rectangle1CentroY < 0 || rectangle1Amplaria < 0 || rectangle1Altura < 0) {
            System.out.println("Error! El tipus de dades introduït és incorrecte");
            return;
        }

        System.out.print("Introdueix els valors x,y del centre del 2on rectangle i la seua amplària i alçada: ");

        float rectangle2CentroX;
        float rectangle2CentroY;
        float rectangle2Amplaria;
        float rectangle2Altura;

        if (!teclado.hasNextFloat() || !teclado.hasNextFloat() || !teclado.hasNextFloat() || !teclado.hasNextFloat()) {
            System.out.println("Error! El tipus de dades introduït és incorrecte");
            return;
        } else {
            rectangle2CentroX = teclado.nextFloat();
            rectangle2CentroY = teclado.nextFloat();
            rectangle2Amplaria = teclado.nextFloat();
            rectangle2Altura = teclado.nextFloat();
        }
        if (rectangle2CentroX < 0 || rectangle2CentroY < 0 || rectangle2Amplaria < 0 || rectangle2Altura < 0) {
            System.out.println("Error! El tipus de dades introduït és incorrecte");
            return;
        }
        float rectangulo1EsquerraSuperiorX = rectangle1CentroX - (rectangle1Amplaria / 2);
        float rectangulo1EsquerraSuperiorY = rectangle1CentroY + (rectangle1Altura / 2);
        float rectangulo1DretSuperiorX = rectangle1CentroX + (rectangle1Amplaria / 2);
        float rectangulo1DretSuperiorY = rectangle1CentroY + (rectangle1Altura / 2);

        float rectangulo1EsquerraInferiorX = rectangle1CentroX - (rectangle1Amplaria / 2);
        float rectangulo1EsquerraInferiorY = rectangle1CentroY - (rectangle1Altura / 2);
        float rectangulo1DretInferiorX = rectangle1CentroX - (rectangle1Amplaria / 2);
        float rectangulo1DretInferiorY = rectangle1CentroY + (rectangle1Altura / 2);


        float rectangulo2EsquerraSuperiorX = rectangle2CentroX - (rectangle2Amplaria / 2);
        float rectangulo2EsquerraSuperiorY = rectangle2CentroY + (rectangle2Altura / 2);
        float rectangulo2DretSuperiorX = rectangle2CentroX + (rectangle2Amplaria / 2);
        float rectangulo2DretSuperiorY = rectangle2CentroY + (rectangle2Altura / 2);

        float rectangulo2EsquerraInferiorX = rectangle2CentroX - (rectangle2Amplaria / 2);
        float rectangulo2EsquerraInferiorY = rectangle2CentroY - (rectangle2Altura / 2);
        float rectangulo2DretInferiorX = rectangle2CentroX - (rectangle2Amplaria / 2);
        float rectangulo2DretInferiorY = rectangle2CentroY + (rectangle2Altura / 2);


        if (rectangulo1DretSuperiorX < rectangulo2EsquerraSuperiorX || rectangulo1EsquerraSuperiorX > rectangulo2DretSuperiorX
                || rectangulo1DretSuperiorY < rectangulo2DretInferiorY || rectangulo1EsquerraInferiorY > rectangulo2DretSuperiorY) {
            System.out.println("El segon rectangle està totalment fora del primer");

        } else if (rectangulo1EsquerraSuperiorX < rectangulo2EsquerraSuperiorX && rectangulo1EsquerraSuperiorY > rectangulo2EsquerraSuperiorY
                    || rectangulo1DretSuperiorX > rectangulo2DretSuperiorX && rectangulo1DretSuperiorY > rectangulo2DretSuperiorY
                    || rectangulo1EsquerraInferiorX < rectangulo2EsquerraInferiorX && rectangulo1EsquerraInferiorY < rectangulo2EsquerraInferiorY
                    || rectangulo1DretInferiorX > rectangulo2DretInferiorX && rectangulo1DretInferiorY < rectangulo2DretInferiorY) {
                System.out.println("El segon rectangle està dins del primer");
        } else {
            System.out.println("El segon rectangle solapa amb el primer");
        }
    }
}