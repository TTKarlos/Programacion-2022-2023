import java.util.Scanner;

public class Partida {
    final static int JUGADOR_1 = 0;
    final static int JUGADOR_2 = 1;
    final static String TEXTO_TABLERO_LLENO = "Habeis completado el tablero";

    public void jugar(Jugador[] jugadores, Icono icono){

        Tablero tablero = new Tablero(icono);
        boolean hasGanado;
        int eleccioDeJugador = JUGADOR_1;

        tablero.vaciar();

        do {
            tablero.mostrar();

            jugadores[eleccioDeJugador].ponerFicha(tablero);
            hasGanado = !queJugadorAGanado(jugadores[eleccioDeJugador], tablero);

            if(eleccioDeJugador == JUGADOR_2){
                eleccioDeJugador = JUGADOR_1;
            } else {
                eleccioDeJugador++;
            }

            if(mostrarElTableroEstaLleno(tablero)){
                hasGanado = false;
            }

        } while (hasGanado);
    }

    public boolean mostrarElTableroEstaLleno(Tablero tablero){
        if(tablero.estaLleno()){
            tablero.mostrar();
            System.out.println(TEXTO_TABLERO_LLENO);
            return true;
        }

        return false;
    }

    public boolean queJugadorAGanado(Jugador jugador, Tablero tablero){
        if(tablero.hayTresEnRaya(jugador)){
            tablero.mostrar();
            jugador.cantarVictoria();
            return true;
        }

        return false;
    }
}