package entities.menu.opciones;

import es.puchades.Restaurante;
import es.puchades.menus.opciones.opcionesRestaurante.OpcionesRestaurante;

public class PrepararPedidoOpcion extends OpcionesRestaurante {
    protected Restaurante restaurante;

    public PrepararPedidoOpcion(Restaurante restaurante){
        super("Preparar Pedido", restaurante);
        this.restaurante = restaurante;
    }

    @Override
    public void ejecutar() {
        restaurante.prepararPedido();
    }
}