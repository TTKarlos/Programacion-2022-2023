public class Actividad9 {
    final static int mbakb = 1024;

    public static void main(String[] args) {

        int mb = 40000;
        int mb2 = 36000;

        System.out.println( mb + " MB equivalen a " + ( mb*mbakb ) + " KB" );
        System.out.println(mb2 + " MB equivalen a " + ( mb2*mbakb ) + " KB" );

    }
}
