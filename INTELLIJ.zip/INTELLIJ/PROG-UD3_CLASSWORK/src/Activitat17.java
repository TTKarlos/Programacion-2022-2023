import java.util.Scanner;

public class Activitat17 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        int numero;

        do {
            System.out.print("Introduce un número: ");
            numero = teclado.nextInt();
        } while (numero == 10);

        System.out.println("Has introducido un número distinto de 10: " + numero);
    }
}