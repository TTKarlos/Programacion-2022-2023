package activitat9;

public class TestAsignatura {
    public static void main(String[] args) {
        Asignatura listado = new Asignatura("Matematicas", 1017, 1, true);
        listado.mostrarInfo();
    }
}