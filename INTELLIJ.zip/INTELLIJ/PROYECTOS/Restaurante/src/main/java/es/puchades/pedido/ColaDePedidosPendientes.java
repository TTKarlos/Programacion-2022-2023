package es.puchades.pedido;

import es.puchades.GestorIO;
import es.puchades.exceptions.ColaLlenaException;
import es.puchades.exceptions.ColaVaciaExeption;
import java.util.ArrayList;

public class ColaDePedidosPendientes {
    final static int NUM_MAXIMO_DE_PEDIDOS_PENDIENTES = 100;
    private ArrayList<Pedido> listaPedidosPendientes;

    public ColaDePedidosPendientes(){
        this.listaPedidosPendientes = new ArrayList<>();
    }

    public ArrayList<Pedido> getListaPedidosPendientes() {
        return listaPedidosPendientes;
    }

    public void anyadir(Pedido pedido){
        try {
            if(!estaLlena()){
                listaPedidosPendientes.add(pedido);
            }
        } catch (ColaLlenaException e){
            GestorIO.mostrarTextoEnError(e.getMessage());
        }
    }

    public Pedido obtenerSiguiente(){
        if(existenPedidos()){
            return listaPedidosPendientes.get(0);
        }

        return null;
    }

    public void eliminarPedido(Pedido pedido){
        listaPedidosPendientes.remove(pedido);
    }

    public ArrayList<Pedido> getIn(String fecha){
        ArrayList<Pedido> listaPedidosNuevos = new ArrayList<>();

        for (int i = 0; i < listaPedidosPendientes.size(); i++) {
            if(listaPedidosPendientes.get(i).getFechaDelPedido().substring(0, 10).equals(fecha)){
                listaPedidosNuevos.add(listaPedidosPendientes.get(i));
            }
        }

        return listaPedidosNuevos;
    }

    public boolean estaLlena(){
        if(listaPedidosPendientes.size() > NUM_MAXIMO_DE_PEDIDOS_PENDIENTES){
            throw new ColaLlenaException(NUM_MAXIMO_DE_PEDIDOS_PENDIENTES);
        }

        return false;
    }

    public boolean existenPedidos(){
        if(listaPedidosPendientes.isEmpty()){
            throw new ColaVaciaExeption();
        }

        return true;
    }
}