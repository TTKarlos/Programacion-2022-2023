package activitat13;

public class TestImprimir {
    public static void main(String[] args) {
        Impresora impresora = new Impresora("HP", "3094D", "35873578532DA");

        Imprimible documento1 = new Documentos("Normas Préstamo libros", "23-02-2020",
                "Lorem Ipsum is simply dummy text of the printing and typesetting industry.");
        Imprimible documento2 = new Documentos("Normas préstamo discos", "23-02-2020",
                "Lorem Ipsum is simply dummy text of the printing and typesetting industry.");

        Imprimible libro1 = new Libros(45555, "La madre de Franquestein","Anónimo", 234,
                "Capítulo introducción", "Lorem Ipsum");
        Imprimible libro2 = new Libros(45255, "El heredero", "Anónimo", 254,
                "Capítulo introducción", "Lorem Ipsum");

        impresora.imprimir(documento1);
        System.out.println();
        impresora.imprimir(documento2);
        System.out.println();
        impresora.imprimir(libro1);
        System.out.println();
        impresora.imprimir(libro2);
        System.out.println();
    }
}