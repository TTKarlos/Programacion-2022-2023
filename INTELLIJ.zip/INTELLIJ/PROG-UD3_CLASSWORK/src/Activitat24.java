public class Activitat24 {

    final static int NUMERO_DE_REPETICIO = 1000000;

    public static void main(String[] args) {

        int totalsCares = 0;
        int totalsCreus = 0;

        System.out.println("Nombre de tirades: 1.000.000\n----------------------------");

        for (int i = 0; i < NUMERO_DE_REPETICIO ; i++){

            int numero = (int) (Math.random()*2+1);
            if (numero == 1){
                totalsCares = totalsCares + 1;
            } else {
                totalsCreus = totalsCreus + 1;
            }
        }
        System.out.println("Nombre de cares: " + totalsCares + "\nNombre de creus: " + totalsCreus);
    }
}