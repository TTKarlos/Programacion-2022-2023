package entities.menu.opciones;

import es.puchades.Restaurante;

public class NuevoPedido extends OpcionesRestaurante {
    protected Restaurante restaurante;

    public NuevoPedido(Restaurante restaurante) {
        super("Crear Nuevo Pedido", restaurante);
        this.restaurante = restaurante;
    }

    @Override
    public void ejecutar() {
        restaurante.anyadirPedido();
    }
}