public class Serpientes {

    final static int INDEX_INICIAL = 0;
    static final int NUMERO_DE_BUSQUEDA = 3;
    final static int PUNTO_X = 0;
    final static int PUNTO_Y = 1;
    static final int[][]ARRAY_SERPIENTE = {{3, 2}, {4, 2}};

    public static int[][] obtenerPosicionesInicio(){

        return ARRAY_SERPIENTE;
    }

    public static void reestablecerAPosicionesIniciales(int[][] posicionesSerpientes){

        int[][] posicionInicial = obtenerPosicionesInicio();

        for(int i = INDEX_INICIAL; i < posicionesSerpientes.length; i++){
            for (int j = INDEX_INICIAL; j < posicionesSerpientes[i].length; j++) {
                posicionesSerpientes[i][j] = posicionInicial[i][j];
            }

        }
    }

    public static void mover(String[][] escenario, int[][] posicionSerpientes){

        for(int i = INDEX_INICIAL; i < posicionSerpientes.length; i++){

            int contador = INDEX_INICIAL;

            do{
                int movimientoAleatorio = Movimiento.obtieneDireccionAleatoria();
                int[] posicionCreada = Movimiento.obtenerCoordenadaAdyacente(movimientoAleatorio, posicionSerpientes[i]);

                if(!Escenario.hayGema(escenario, posicionCreada[PUNTO_X], posicionCreada[PUNTO_Y]) &&
                        Escenario.estaPermitidoElPaso(escenario, posicionCreada[PUNTO_X], posicionCreada[PUNTO_Y]) &&
                        !haySerpiente(posicionSerpientes, posicionCreada[PUNTO_X], posicionCreada[PUNTO_Y])){
                    posicionSerpientes[i] = posicionCreada;
                    break;
                } else {
                    contador++;
                }

            } while(contador <= NUMERO_DE_BUSQUEDA);

            if(contador == NUMERO_DE_BUSQUEDA){
                reestablecerAPosicionesIniciales(posicionSerpientes);
                posicionSerpientes[i] = busquedaPerfecta(escenario, posicionSerpientes[i]);
            }
        }
    }

    public static int[] busquedaPerfecta(String[][] escenario, int[] posicionSerpientes){

        for(int i = 1; i <= 4; i++){

            int[] posicionCreada = Movimiento.obtenerCoordenadaAdyacente(i, posicionSerpientes);

            if(!Escenario.hayGema(escenario, posicionCreada[PUNTO_X], posicionCreada[PUNTO_Y]) &&
                    Escenario.estaPermitidoElPaso(escenario, posicionCreada[PUNTO_X], posicionCreada[PUNTO_Y])){
                return posicionCreada;
            }
        }

        return posicionSerpientes;
    }

    public static boolean haySerpiente(int[][] posicionesSerientes, int x, int y){
        for(int i = INDEX_INICIAL; i < posicionesSerientes.length; i++){
            if(posicionesSerientes[i][PUNTO_X] == x && posicionesSerientes[i][PUNTO_Y] == y){
                return true;
            }
        }

        return false;
    }
}