import java.util.Scanner;

public class Activitat9 {

    final static float QUOTA = 500f;
    final static float PERCENT_MENOR_DE_EDAD = 0.25f;
    final static float PERCENT_MAJOR_A_65 = 0.45f;

    public static void main(String[] args) {

        Scanner teclat = new Scanner(System.in);

        System.out.println("Exemple d'execució");
        System.out.print("Insereix nom: ");
        String nom = teclat.next();

        System.out.print("Insereix edat: ");

        double euros;

        if (!teclat.hasNextInt()) {
            System.out.println("ERROR!");
            return;
        } else {
            int edad = teclat.nextInt();
            if (edad > 65) {
                euros = QUOTA - (QUOTA * PERCENT_MAJOR_A_65);
            } else if (edad < 18) {
                euros = QUOTA - (QUOTA * PERCENT_MENOR_DE_EDAD);
            } else euros = 500;
            System.out.println(nom + ", has de pagar " + euros + " euros.");
        }
}
}