package es.cipfpbatoi.plantillaexamen.controllers;

import es.cipfpbatoi.plantillaexamen.utils.Trabajador;
import es.cipfpbatoi.plantillaexamen.utils.repositorios.TrabajadoresRepositorio;
import es.cipfpbatoi.plantillaexamen.utils.repositorios.UniversidadRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.time.LocalDateTime;
import java.util.Map;

@Controller
public class Parte2Controller {
    @Autowired
    private TrabajadoresRepositorio trabajadoresRepositorio;
    @Autowired
    private UniversidadRepositorio universidadRepositorio;

    @GetMapping("/add-trabajador")
    public String addTrabajador(Model model){
        model.addAttribute("universidades", universidadRepositorio.findAll());
        return "nuevo-trabajador";
    }

    @PostMapping("/nuevo-trabajador")
    public String nuevoTrabajador(@RequestParam Map<String, String> params){
        String dni = params.get("dni");
        String nombre = params.get("nombre");
        String fechaContratado = params.get("fechaContratado");
        int id_universidad = Integer.parseInt(params.get("id_universidad"));

        Trabajador trabajador = new Trabajador(dni, nombre, id_universidad, getFechaContratado(fechaContratado));
        trabajadoresRepositorio.save(trabajador);

        return "redirect:/trabajadores";
    }

    private LocalDateTime getFechaContratado(String fechaString){
        return LocalDateTime.parse(fechaString);
    }
}