package activitat9.enums;

public enum Comida {
    OMNIVORO {
        @Override
        public String toString() {
            return "omnivoro";
        }
    },
    CARNIVORO{
        @Override
        public String toString() {
            return "carnivoro";
        }
    },
    HERBIVORO{
        @Override
        public String toString() {
            return "herbivoro";
        }
    },
}