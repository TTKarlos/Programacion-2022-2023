package activitat2;

import activitat2.enums.TiposPintura;

import java.security.PublicKey;

public class Servicio {
    private int numIdentifiacion;
    private String direccion;
    private int numMetrosCuadrados;
    private int numDiasParaFinalizar;
    private int numDeOperariosAsigandos;
    private float precioDeMateriales;
    private String observaciones;

    public Servicio(int numIdentifiacion, String direccion, int numMetrosCuadrados, int numDiasParaFinalizar,
                    int numDeOperariosAsigandos, float precioDeMateriales){
        this.numIdentifiacion = numIdentifiacion;
        this.direccion = direccion;
        this.numMetrosCuadrados = numMetrosCuadrados;
        this.numDiasParaFinalizar = numDiasParaFinalizar;
        this.numDeOperariosAsigandos = numDeOperariosAsigandos;
        this.precioDeMateriales = precioDeMateriales;
        this.observaciones = "Ninguna observacion";
    }

    public int getNumDeOperariosAsigandos() {
        return numDeOperariosAsigandos;
    }

    public int getNumDiasParaFinalizar() {
        return numDiasParaFinalizar;
    }

    public int getNumMetrosCuadrados() {
        return numMetrosCuadrados;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public void setNumDeOperariosAsigandos(int numDeOperariosAsigandos) {
        this.numDeOperariosAsigandos = numDeOperariosAsigandos;
    }

    public double calcularCosteTotal(){
        return precioDeMateriales;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Servicio)){
            return false;
        }
        Servicio servicio = (Servicio) obj;
        return numIdentifiacion == servicio.numIdentifiacion;
    }

    @Override
    public String toString() {
        return "de " + numMetrosCuadrados + "m2 en " + direccion + " con " + numDeOperariosAsigandos +
                " operarios aignados durante " + numDiasParaFinalizar + " dias (" + observaciones + ")";
    }
}