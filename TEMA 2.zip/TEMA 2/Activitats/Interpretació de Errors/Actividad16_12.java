import java.util.Scanner;

/**
 * @Error: Matematicament no podem dividir ningun numero entre 0, ja que es un error. Tenemos que cambiar de la linea
 * 18 la variable de num2 = 0 per altre número --> int num2 = 2;
 * @Tipus: Temps de compilació.
 **/

public class Actividad16_12 {

    public static void main(String[] args) {

        Scanner scannerKey = new Scanner(System.in);

        System.out.println("Introduce el número 1");
        int num1 = scannerKey.nextInt();

        int num2 = 2;
        int result = num1 / num2;
        System.out.println(result);

    }

}
