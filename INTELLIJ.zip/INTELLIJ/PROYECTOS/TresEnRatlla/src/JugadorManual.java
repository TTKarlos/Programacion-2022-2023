import java.util.Scanner;

public class JugadorManual extends Jugador{
    final static String COLOR_AZUL = "\u001B[34m";
    final static String RESET_COLOR = "\u001B[0m";
    final static String TEXTO_TIRADA_FILA = COLOR_AZUL + "Introduce fila [1-" + Tablero.DIMENSIONES_DEL_TABLERO +
            "]: " + RESET_COLOR;
    final static String TEXTO_TIRADA_COLUMNA = COLOR_AZUL + "Introduce columna [1-" + Tablero.DIMENSIONES_DEL_TABLERO +
            "]: " + RESET_COLOR;

    private EstadoCasilla estadoCasilla;
    private Icono icono;

    public JugadorManual(EstadoCasilla estadoCasilla, Icono icono){
        super(estadoCasilla, icono);
        this.estadoCasilla = estadoCasilla;
        this.icono = icono;
    }

    public EstadoCasilla getEstadoCasilla() {
        return estadoCasilla;
    }

    @Override
    public void ponerFicha(Tablero tablero){

        System.out.printf("Tira el jugador con %s\n", icono.obtenerSimbolo(estadoCasilla));

        do{
            Coordenada nuevaCordenada = recogerCoordenada();

            if(!tablero.isOcupada(nuevaCordenada)) {
                System.out.println(TEXTO_ERROR_CORDENADA);
            } else {
                tablero.ponerFicha(nuevaCordenada, estadoCasilla);
                return;
            }
        } while (true);
    }

    private Coordenada recogerCoordenada(){
        do {
            int fila = obtindreTirada(TEXTO_TIRADA_FILA);
            int columna = obtindreTirada(TEXTO_TIRADA_COLUMNA);
            Coordenada nuevaCordenada = new Coordenada( fila - 1, columna - 1);
            if(!nuevaCordenada.isValida(Tablero.DIMENSIONES_DEL_TABLERO)){
                System.out.println(TEXTO_CORDENADA_INVALIDA);
            } else {
                return nuevaCordenada;
            }

        } while(true);
    }

    private int obtindreTirada(String missatge){

        Scanner teclado = new Scanner(System.in);

        do {
            System.out.printf(missatge);

            if(!teclado.hasNextInt()){
                System.out.println(TEXTO_NUMERO_ENTERO_INVALIDO);
                teclado.next();
            } else {
                return teclado.nextInt();
            }
        } while (true);
    }
}