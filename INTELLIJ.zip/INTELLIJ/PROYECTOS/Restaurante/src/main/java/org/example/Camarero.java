package org.example;

import org.example.view.ListadoPedidosView;
import org.example.view.PedidoView;
import java.util.ArrayList;

public class Camarero {
    final static String TEXTO_ERROR_PEDIDO = "Elige un numero de pedido correcto";
    private ArrayList<Pedido> listaPedidos;
    private int numPedidos;

    public Camarero() {
        this.numPedidos = 0;
        this.listaPedidos = new ArrayList<>();
    }

    //-------------------------------------------CREAR NUEVO PEDIDO---------------------------------------------------\\
    public void anyadirPedido() {
        this.numPedidos = numPedidos + 1;
        listaPedidos.add(new Pedido(numPedidos, GestorIO.pedirFecha(), GestorIO.pedirNombre()));
        System.out.println(new PedidoView(listaPedidos.get(listaPedidos.size() - 1)));
    }

    //---------------------------------------------VISUALIZAR ORDEN--------------------------------------------------\\
    public void visualizarOrden() {
        if(listaPedidos.size() <= 0){
            GestorIO.mostrarTextoEnError("No hay ningun pedido");
            return;
        }

        System.out.println(new PedidoView(listaPedidos.get(GestorIO.elegirUnPedido(listaPedidos.size(), TEXTO_ERROR_PEDIDO))));
    }

    //----------------------------------------LISTAR TODOS LOS PEDIDOS------------------------------------------------\\
    public void mostrarListaPedidos(){
        System.out.println(new ListadoPedidosView(listaPedidos, true));
    }

    //----------------------------------------------SERVIR PEDIDO-----------------------------------------------------\\
    public void servirUnPedido() {
        if (!hayPedidosParaServir()) {
            GestorIO.mostrarTextoEnError("No existen pedidos pendientes de servir");
        } else {
            System.out.println(new ListadoPedidosView(listaPedidos, false));

            do {
                int elecionPedido = GestorIO.elegirUnPedido(listaPedidos.size(), TEXTO_ERROR_PEDIDO);

                if (!listaPedidos.get(elecionPedido).getHaSidoServidoEnMesa()) {
                    listaPedidos.get(elecionPedido).setHaSidoServidoEnMesa(true);
                    GestorIO.mostrarTextoEnVerde("El pedido ha sido marcado como servido");
                    return;
                } else {
                    GestorIO.mostrarTextoEnError("Este pedido ya esta servido");
                }
            } while (true);
        }
    }

    private boolean hayPedidosParaServir() {
        for (int i = 0; i < listaPedidos.size(); i++) {
            if (!listaPedidos.get(i).getHaSidoServidoEnMesa()) {
                return true;
            }
        }

        return false;
    }
}