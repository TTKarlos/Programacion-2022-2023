package activitat3;

public class TestCoche {
    public static void main(String[] args) {
        Coxte seat = new Coxte(0, 10, "FGS1234");
        CotxeEsportiu renault = new CotxeEsportiu(0, 10, "FDE2345", false);

        seat.proveir(50);
        renault.proveir(50);

        for (int i = 0; i < 5; i++) {
            seat.acelerar();
            renault.acelerar();
        }

        seat.frenar();
        renault.frenar();

        System.out.println(seat);
        System.out.println(renault);
    }
}