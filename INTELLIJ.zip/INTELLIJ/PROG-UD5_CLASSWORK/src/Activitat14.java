public class Activitat14 {
    public static void main(String[] args) {

        int[][] taula = new int[3][6];
        taula[0][1] = 30;
        taula[0][2] = 2;
        taula[0][5] = 5;

        taula[1][0] = 75;

        taula[2][1] = -2;
        taula[2][3] = 9;
        taula[2][5] = 11;
    }
}