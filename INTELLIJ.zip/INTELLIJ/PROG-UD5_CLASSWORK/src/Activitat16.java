public class Activitat16 {
    public static void main(String[] args) {

        String[][] taula = {{"Joan", "Perez Aura", "24" , "ASIX", "1"},
                            {"Maria", "Sanchez Garcia", "18" , "DAW", "1"},
                            {"Pepa", "Egea juan", "21" , "DAM", "1"},
                            {"Ana Maria", "Hernandez Julian", "20" , "DAW", "2"},
                            {"Francesc", "Juan Juan", "28" , "DAW", "1"}};

        mostrarTaula(taula);
        mostrarDawYAsix(taula);
        mitjanaDeEdad(taula);
        promocionarASegundos(taula);
        alumnesMatriculats(taula);
    }

    public static void mostrarTaula(String[][] taula){
        for(int i = 0; i < taula.length; i++){
            for(int j = 0; j < taula[i].length; j++){
                System.out.print(taula[i][j] + "    ");
            }
            System.out.println();
        }
    }

    public static void mostrarDawYAsix(String[][] taula){
        for (int i = 0; i < taula.length; i++){
            System.out.print(taula[0][i] + "        ");
        }
        System.out.println();

        for (int i = 0; i < taula.length; i++){
            System.out.print(taula[1][i] + "        ");
        }
        System.out.println();

        for (int i = 0; i < taula.length; i++){
            System.out.print(taula[3][i] + "        ");
        }
        System.out.println();

        for (int i = 0; i < taula.length; i++){
            System.out.print(taula[4][i] + "        ");
        }
        System.out.println();
    }

    public static void mitjanaDeEdad(String[][] taula){

        int edadTotal = 0;

        for(int i = 0; i < taula[2].length; i++){
            edadTotal += Integer.parseInt(taula[i][2]);
        }

        float edadMitjana = edadTotal / taula[2].length;
        System.out.printf("La edad mitjana es de: %.2f\n", edadMitjana);
    }

    public static void promocionarASegundos(String[][] tabla){
        for(int i = 0; i < tabla.length; i++){
            if (tabla[i][4].equalsIgnoreCase("1")){
                tabla[i][4] = "2";
            }
        }

        mostrarTaula(tabla);
    }

    public static void alumnesMatriculats(String[][] taula){

        int numDaw = 0;
        int numDam = 0;
        int numAsix = 0;

        for(int i = 0; i < taula.length; i++){
            if(taula[i][3].equalsIgnoreCase("daw")){
                numDaw++;
            } else if(taula[i][3].equalsIgnoreCase("dam")){
                numDam++;
            } else if(taula[i][3].equalsIgnoreCase("asix")){
                numAsix++;
            }
        }

        String[][] taulaAlumnes = {{"ASIX", String.valueOf(numAsix)},
                                    {"DAW", String.valueOf(numDaw)},
                                    {"DAM", String.valueOf(numDam)}};

        mostrarTaula(taulaAlumnes);
    }
}