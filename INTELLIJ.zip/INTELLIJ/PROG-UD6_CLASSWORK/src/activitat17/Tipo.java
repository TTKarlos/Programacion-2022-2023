package activitat17;

public enum Tipo {
    TURISMO, MONOVOLUMEN, DEPORTIVO, CROSSOVER, TODO_TERRENO
}