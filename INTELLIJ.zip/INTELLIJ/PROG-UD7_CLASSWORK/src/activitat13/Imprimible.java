package activitat13;

public interface Imprimible {
    void obtenerTexto();
}