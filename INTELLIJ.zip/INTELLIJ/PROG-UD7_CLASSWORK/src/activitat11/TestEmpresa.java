package activitat11;

public class TestEmpresa {
    public static void main(String[] args) {

        Empresa empresa = new Empresa();

        Administrativo[] administrativos = {new Administrativo("Empleado administrativo 1", "Garcia 1",
                "21566424R", "20/2/2022", "34564544544", 1024.00f, 23, "0020102920 "),
                new Administrativo("Empleado administrativo 2", "Garcia 2",
                "21566454Q", "20/2/2022", "34564544544", 2024.00f, 24, "0202727272")};

        Vendedor[] vendedors = {new Vendedor(" Empleado vendendor 1", "García 3", "21566454S",
                "20/2/2020", "654879123", 3024.00f, false, 2,
                new Cliente[]{}, 5), new Vendedor(" Empleado vendendor 2", "García 4",
                "21066454P", "20/2/2020", "654879123", 4024.00f,
                false, 2, new Cliente[]{}, 5)};

        empresa.anadirEmpleado(administrativos[0]);
        empresa.anadirEmpleado(administrativos[1]);
        empresa.anadirEmpleado(vendedors[0]);
        empresa.anadirEmpleado(vendedors[1]);

        System.out.println("------ Todos Los empleados --------");
        empresa.listaDeTodosLosEmpleados();
        System.out.println("------------------------");

        System.out.printf("\nEl coste mensual en salarios es %.2f\n", empresa.calcularElTotalDeSalariosDeLosEmpleados());

        administrativos[0].incrementarSalario();
        administrativos[1].incrementarSalario();
        vendedors[0].incrementarSalario();
        vendedors[1].incrementarSalario();
        System.out.println("\n------ Aumento salario de empleados ------\n");

        System.out.println("------ Todos Los empleados --------");
        empresa.listaDeTodosLosEmpleados();
        System.out.println("------------------------");

        System.out.printf("\nEl coste mensual en salarios es %.2f\n", empresa.calcularElTotalDeSalariosDeLosEmpleados());

        System.out.println("\n------ Listados con filtros ------");
        System.out.println("------ Administrativos --------");
        empresa.listaDeTodosLosAdministrativos();
        System.out.println("------------------------");

        System.out.println("------ Vendedores --------");
        empresa.listaDeTodosLosVendedores();
        System.out.println("------------------------");
    }
}