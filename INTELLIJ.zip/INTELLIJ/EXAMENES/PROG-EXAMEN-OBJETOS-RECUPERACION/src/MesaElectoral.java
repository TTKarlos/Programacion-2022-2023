import exceptions.MesaElectoralNoValidaException;

import java.util.ArrayList;

public class MesaElectoral {
    private String codigo;
    private ArrayList<String> ciudadanosConvocados;
    private ArrayList<Voto> votos;

    public MesaElectoral(String codigo, ArrayList<String>  dniCiudadanosNoVotados) {
        this.codigo = codigo;
        this.ciudadanosConvocados = dniCiudadanosNoVotados;
        this.votos = new ArrayList<>();
    }

    public int obtenerVoto(Partido partido){
        int contador = 0;
        for (int i = 0; i < votos.size(); i++) {
            if(votos.get(i).getPartido().equals(partido)){
                contador++;
            }
        }
        return contador;
    }

    public ArrayList<String> getCiudadanosConvocados() {
        return ciudadanosConvocados;
    }

    public void depositarVoto(Voto voto){
        comprobarDniRepetido(voto);
        votos.add(voto);
    }

    public boolean hayVotos(){
        if(!votos.isEmpty()){
            return true;
        }

        return false;
    }

    private void comprobarDniRepetido(Voto voto){
        for (int i = 0; i < votos.size(); i++) {
            if(votos.get(i).equals(voto)){
                throw new MesaElectoralNoValidaException("La perosna con el DNI " + voto.getDni() + " ya ha votado.");
            }
        }
    }
}