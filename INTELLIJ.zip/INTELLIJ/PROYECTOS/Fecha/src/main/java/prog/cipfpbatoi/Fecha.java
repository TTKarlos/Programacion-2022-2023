package activitat11;

public class Fecha {
	final static int MESES_TOTALES = 12;
	final static int ANYO_MINIMO = 0;
	final static int ANYO_ACTUAL = 2023;
	final static int INDICE_INICIAL = 0;
	final static int DIAS_DE_UNA_SEMANA = 7;
	private static final String[] DIAS_TEXTO = new String[] { "domingo", "lunes", "martes", "miercoles", "jueves", "viernes",
			"sábado"};
	private static final String[] MESES_TEXTO = new String[] { "enero", "febrero", "marzo", "abril", "mayo", "junio",
			"julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre" };

	private int dia;
	private int mes;
	private int anyo;

	public Fecha(){
		this.dia = 1;
		this.mes = 1;
		this.anyo = 1970;
	}

	public Fecha(int dia, int mes, int anyo){
		this.dia = dia;
		this.mes = mes;
		this.anyo = anyo;
	}

	public Fecha(String cadena){
		String[] array = cadena.split("/");
		this.dia = Integer.parseInt(array[0]);
		this.mes = Integer.parseInt(array[1]);
		this.anyo = Integer.parseInt(array[2]);
	}

	public int getDia() {
		return dia;
	}

	public int getMes() {
		return mes;
	}

	public int getAnyo() {
		return anyo;
	}

	public void set(int dia, int mes, int anyo){
		this.dia = dia;
		this.mes = mes;
		this.anyo = anyo;
	}

	public Fecha clone(){
		return new Fecha(dia, mes, anyo);
	}

	public void mostrarFromatoES(){
		System.out.printf("%02d-%02d-%d\n", dia, mes, anyo);
	}

	public void mostrarFormatoGB(){
		System.out.printf("%d-%02d-%02d\n", anyo, mes, dia);
	}

	public void mostrarFormatoTexto(){
		System.out.printf("%02d-%s-%d\n", dia, getMesTexto(mes), anyo);
	}

	public String getMesTexto(int mes){
		return MESES_TEXTO[mes - 1];
	}

	public boolean isEqual(Fecha fecha){
		return (fecha.getDia() == dia && fecha.getMes() == mes && fecha.getAnyo() == anyo);
	}

	public String getDiaSemana(){
		return DIAS_TEXTO[getNumeroDia()];
	}

	public boolean isFestivo(){
		return (getNumeroDia() == 6 || getNumeroDia() == 0);
	}

	public int getNumeroSemana() {
		int contador = 0;
		int diaSemana = getNumeroDia();

		for (int i = getDiasTranscurridosAnyo(); i >= 1; i--){
			if(diaSemana == 0 ){
				contador++;
				diaSemana = 6;
			} else {
				diaSemana--;
			}
		}

		return contador + 1;
	}

	public int getNumeroDia() {
		return  (getDiasTranscurridosAnyo() + getDiasTranscurridosOrigen()) % DIAS_DE_UNA_SEMANA;
	}

	public Fecha anyadir(int dias){

		if(dias > 30){
			return new Fecha(dia, mes, anyo);
		}

		int dia = this.dia + dias;
		int mes = this.mes;
		int anyo = this.anyo;

		while(dia > getDiasMes(mes, anyo)){

			dia -= getDiasMes(mes, anyo);
			mes++;

			if(mes > MESES_TOTALES){
				mes = 1;
				anyo++;
			}
		}

		return new Fecha(dia, mes, anyo);
	}

	public Fecha resto(int dias){

		if(dias > 30){
			return new Fecha(dia, mes, anyo);
		}

		int dia = this.dia;
		dia -= dias;
		int mes = this.mes;
		int anyo = this.anyo;

		while(dia < 1){
			mes--;
			if (mes < 1) {
				mes = MESES_TOTALES;
				anyo--;
			}

			int diasMes = getDiasMes(mes, anyo);

			dia += diasMes;
		}

		return new Fecha(dia, mes, anyo);
	}

	public static int getDiasMes(int mes, int anyo) {

		if(mes == 2) {
			if(isBisiesto(anyo)){
				return 29;
			} else {
				return 28;
			}

		} else if(mes == 4 || mes == 6 || mes == 9 || mes == 11){
			return 30;
		} else {
			return 31;
		}
	}

	public static boolean isBisiesto(int anyo){
		return ((anyo % 4 == 0 && anyo % 100 != 0) || (anyo % 4 == 0 && anyo % 400 == 0 && anyo % 100 == 0));
	}

	public boolean isCorrecta(){
		return (dia <= getDiasMes(mes, anyo) && mes <= MESES_TOTALES && anyo >= ANYO_MINIMO && anyo <= ANYO_ACTUAL);
	}

	private int getDiasTranscurridosAnyo(){

		int diasTotales = INDICE_INICIAL;

		for(int i = 1; i < mes; i++){
			diasTotales += getDiasMes(i, anyo);
		}

		diasTotales += dia;
		return diasTotales;
	}

	private int getDiasTranscurridosOrigen(){

		int diasTotales = INDICE_INICIAL;

		for(int i = 1; i < anyo; i++){
			diasTotales += getDiasMes(i);
		}

		return diasTotales;
	}

	public static int getDiasMes(int anyo){
		int diasTotales = INDICE_INICIAL;

		for(int i = 1; i <= MESES_TOTALES; i++){
			diasTotales += getDiasMes(i, anyo);
		}

		return diasTotales;
	}

	public void mostrarInformacion(){
		mostrarFromatoES();
		mostrarFormatoGB();
		mostrarFormatoTexto();
		System.out.printf("La fecha es correcta: %b\nLa fecha es festivo: %s\nEl día de la semana es: %s\n", isCorrecta()
				,isFestivo(), getDiaSemana());
		System.out.println("-------------------------------");
	}

	public void mostrarInformacionDeAnyadir(int suma){
		System.out.printf("--- Día siguiente a la fecha inicial (%d,%d,%d) - (+%d día) ---\n", dia, mes, anyo, suma);
		mostrarFromatoES();
		anyadir(suma);
		mostrarFormatoGB();
		mostrarFormatoTexto();
		System.out.printf("La fecha es correcta: %b\nLa fecha es festivo: %s\nEl día de la semana es: %s\n", isCorrecta()
				,isFestivo(), getDiaSemana());
		System.out.println("-------------------------------");
	}

	public void mostrarInformacionDeResto(int resto){
		System.out.printf("--- Día siguiente a la fecha inicial (%d,%d,%d) - (-%d día) ---\n", dia, mes, anyo, resto);
		mostrarFromatoES();
		resto(resto);
		mostrarFormatoGB();
		mostrarFormatoTexto();
		System.out.printf("La fecha es correcta: %b\nLa fecha es festivo: %s\nEl día de la semana es: %s\n", isCorrecta()
				,isFestivo(), getDiaSemana());
		System.out.println("-------------------------------");
	}
}