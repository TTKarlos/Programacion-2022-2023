package com.example.gestion_de_usuarios.modelo.entidades;

import java.time.LocalDate;

public class Usuario {
    private String nombre;
    private String apellidos;
    private String dni;
    private String correoElectronico;
    private String codigoPostal;
    private String telefono;
    private LocalDate fechaNacimiento;
    private String password;

    public Usuario(String nombre, String apellidos, String dni, String correoElectronico, String codigoPostal,
                   String telefono, String fechaNacimiento, String password) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
        this.correoElectronico = correoElectronico;
        this.codigoPostal = codigoPostal;
        this.telefono = telefono;
        this.fechaNacimiento = formDateTime(fechaNacimiento);
        this.password = password;
    }

    public Usuario(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCodigoPostal() {
        return codigoPostal;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String formContrasenyaEncriptada(){
        String contrasenyaEncriptada = "";
        for (int i = 0; i < password.length(); i++) {
            contrasenyaEncriptada += "*";
        }

        return contrasenyaEncriptada;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Usuario usuario)) return false;
        return usuario.nombre.equals(nombre);
    }

    private LocalDate formDateTime(String fecha){
        return LocalDate.parse(fecha);
    }
}