package RepàsExamen;

import java.util.Random;

public class Problema1 {
    public static void main(String[] args) {

        visualizarArray(generarArray());

    }

    public static void visualizarArray(int[] matriu){
        for(int i = 0; i < matriu.length; i++){
            System.out.print(matriu[i]);
        }
    }

    public static int[] generarArray (){

        int[] array = new int[5];

        for(int i = 0 ; i < array.length; i++){
            do{
                Random random = new Random();
                int numRandom = random.nextInt(10);
                if(!comprobarArray(array, i, numRandom)){
                    array[i] = numRandom;
                    break;
                }

            } while (true);
        }

        return array;
    }

    public static boolean comprobarArray (int[] array, int index, int numRandom){
        for(int i = 0; i <= index; i++){
            if(array[i] == numRandom){
                return true;
            }
        }

        return false;
    }
}
