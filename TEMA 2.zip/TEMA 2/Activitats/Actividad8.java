public class Actividad8 {
    public static void main(String[] args) {
        int x = 150;
        int e = 2000;
        System.out.println("Variable x=150 y variable e=2000");
        System.out.println("Suma:\t" + (x+e));
        System.out.println("Resta:\t" + (x-e));
        System.out.println("Multiplicaió:\t" + (x*e));
        System.out.println("Divisió:\t" + (x/(float)e));

    }
}
