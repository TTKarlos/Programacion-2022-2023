public class Actividad19 {
    public static void main(String[] args) {
        System.out.println("Andreu Puchades Pascual");
    }
}