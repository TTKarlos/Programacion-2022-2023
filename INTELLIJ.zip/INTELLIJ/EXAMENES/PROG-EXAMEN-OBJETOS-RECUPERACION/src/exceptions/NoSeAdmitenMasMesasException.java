package exceptions;

public class NoSeAdmitenMasMesasException extends RuntimeException{
    public NoSeAdmitenMasMesasException(String mensaje){
        super(mensaje);
    }
}
