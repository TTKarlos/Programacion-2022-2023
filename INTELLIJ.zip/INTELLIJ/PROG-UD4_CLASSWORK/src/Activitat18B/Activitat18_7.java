package Activitat18B;

import java.util.Scanner;

public class Activitat18_7 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        String frase;

        boolean esCorrecte;
        do{
            esCorrecte = false;
            System.out.print("Introduce cadena1: ");
            frase = teclado.nextLine();
            if (frase.length() < 5){
                esCorrecte = true;
            }
        } while (esCorrecte);

        String palabra;

        do{
            esCorrecte = false;
            System.out.print("Introduce cadena2: ");
            palabra = teclado.nextLine();
            if (palabra.length() <= 1){
                esCorrecte = true;
            }
        } while (esCorrecte);
        System.out.printf("Resultado: %s",cambiarPalabra(frase, palabra));
    }

    public static String cambiarPalabra(String frase, String palabra){
        return frase.substring(0,frase.lastIndexOf(palabra)) + palabra.toUpperCase() +
                frase.substring(frase.lastIndexOf(palabra) + palabra.length());
    }
}