package activitat10;

public class CuentaBancaria {

    private String nombreCliente;
    private String numeroCuenta;
    private double saldo;
    private float tipoDeInteres;
    private boolean estadoBloqueado;

    public CuentaBancaria(String nombreCliente, String numeroCuenta, double saldo, boolean estado){
        this.nombreCliente = nombreCliente;
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
        this.tipoDeInteres = 0.1f;
        this.estadoBloqueado = estado;
    }

    public boolean reintegro(float cantidad){
        if(!estadoBloqueado){
            saldo -= cantidad;
            return true;
        } else {
             return false;
        }
    }

    public boolean ingreso(float cantidad){
        if(!estadoBloqueado){
            saldo += cantidad;
            return true;
        } else {
            return false;
        }
    }

    public void mostrarInformacion(){
        System.out.printf("Cuenta: %s, Cliente: %s, Interés: %.2f, Saldo: %.2f", numeroCuenta, nombreCliente, tipoDeInteres, saldo);
    }
}