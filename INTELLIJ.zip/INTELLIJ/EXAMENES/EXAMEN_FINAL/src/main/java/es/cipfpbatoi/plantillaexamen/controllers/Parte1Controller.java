package es.cipfpbatoi.plantillaexamen.controllers;

import es.cipfpbatoi.plantillaexamen.utils.repositorios.TrabajadoresRepositorio;
import es.cipfpbatoi.plantillaexamen.utils.repositorios.UniversidadRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Parte1Controller {
    @Autowired
    UniversidadRepositorio universidadRepositorio;
    @Autowired
    TrabajadoresRepositorio trabajadoresRepositorio;

    @GetMapping("/universidad")
    public String universidad(@RequestParam int id, Model model){
        model.addAttribute("universidad", universidadRepositorio.findById(id));
        return "detalles-universidad";
    }

    @GetMapping("/trabajadores")
    public String trabajadores( Model model){
        model.addAttribute("trabajadores", trabajadoresRepositorio.findAllWithuniversities());
        return "listado-trabajadores";
    }
}