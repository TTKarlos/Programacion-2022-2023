package es.cipfpbatoi.plantillaexamen.utils;

public class Universidad {
    private int codigo;
    private String nombre;

    public Universidad(int codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }
}