public class Actividad3 {
    public static void main(String[] args) {
        String miNombre = "Andreu";
        String misApellidos = "Puchades Pascual";
        int edad = 19;
        boolean estasCasado = false;
        System.out.println(miNombre);
        System.out.println(misApellidos);
        System.out.println(edad);
        System.out.println(estasCasado);

    }
}
