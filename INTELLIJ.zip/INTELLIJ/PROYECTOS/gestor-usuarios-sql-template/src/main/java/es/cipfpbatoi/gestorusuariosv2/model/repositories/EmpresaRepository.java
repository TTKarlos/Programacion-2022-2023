package es.cipfpbatoi.gestorusuariosv2.model.repositories;

import es.cipfpbatoi.gestorusuariosv2.exceptions.UserNotFoundException;
import es.cipfpbatoi.gestorusuariosv2.model.dao.SQLEmpresaDAO;
import es.cipfpbatoi.gestorusuariosv2.model.dao.interfaces.EmpresaDAO;
import es.cipfpbatoi.gestorusuariosv2.model.entities.Empresa;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;

@Service
public class EmpresaRepository {
    @Autowired
    EmpresaDAO empresaDAO;

    public EmpresaRepository(@Autowired SQLEmpresaDAO sqlEmpresaDAO) {
        this.empresaDAO = sqlEmpresaDAO;
    }

    public void add(Empresa empresa) {
        empresaDAO.save(empresa);
    }

    public ArrayList<Empresa> findAll() {
        return empresaDAO.findAll();
    }

    public Empresa getById(int id) {
        Empresa empresa = findById(id);
        if (empresa == null) {
            throw new UserNotFoundException(id);
        }
        return empresa;
    }

     private Empresa findById(int id) {
        return empresaDAO.findById(id);
    }

    public void remove(Empresa empresa) {
        empresaDAO.remove(empresa);
    }
}