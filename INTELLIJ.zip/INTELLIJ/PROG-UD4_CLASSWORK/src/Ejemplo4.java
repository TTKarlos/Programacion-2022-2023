public class Ejemplo4 {
    public static int times = 3;
    public static void main(String[] args) {

        System.out.println("Before call," + " times is " + times);

        nPrintln("Welcome!", times);
        System.out.println("After call," + " times is " + times);
    }


    public static void nPrintln(String message, int n) {

        while (times > 0) {
            System.out.println("n = " + n);
            System.out.println(message);
            times--;
        }
    }
}