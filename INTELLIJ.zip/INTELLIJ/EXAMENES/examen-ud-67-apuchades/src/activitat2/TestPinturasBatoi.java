package activitat2;

import activitat2.enums.TiposPintura;
import activitat2.tipos_servicios.Lacado;
import activitat2.tipos_servicios.PinturaDomestica;
import activitat2.tipos_servicios.PinturaIndustrial;

public class TestPinturasBatoi {
    public static void main(String[] args) {
        //TEST DE SERVICIO
        Servicio[] servicios = {
                new PinturaIndustrial(1, "calle Isidro Medario",
                300, 2, 2500, TiposPintura.COMPLETO),
        new Lacado(2, "Avda. Marta Blero", 20, 4,
                2500, 4, 5),
        new PinturaDomestica(3, "C/. Maria Ojeda", 80, 2,
                1500, TiposPintura.INTERIOR)
        };

        servicios[0].setObservaciones("Nave industrial de 3 alturas, llevar grua de escalera");
        servicios[1].setObservaciones("Pitnado en blanco nuclear");
        servicios[2].setObservaciones("Piso pintado en colores, se necesitan 4 pasadas");

        servicios[1].setNumDeOperariosAsigandos(3);

        System.out.println(servicios[0]);
        System.out.println(servicios[1]);
        System.out.println(servicios[2]);

        mostrarPrecioTotalPorSevicio(servicios);

        //TEST CLIENTES
        Cliente[] clientes = {
                new Cliente("21563421L", "Pepa", "Gomez"),
                new Cliente("21654245R", "Juan", "Magan"),
                new Cliente("21563421L", "Maria", "Pino")
        };

        System.out.println();
        System.out.println(clientes[0]);
        System.out.println(clientes[1]);
        System.out.println(clientes[2]);
        System.out.println(clientes[0].equals(clientes[1]));
        System.out.println(clientes[0].equals(clientes[2]));
        System.out.println();

        //TEST DE ESCAPARATE
        Escaparate escaparate = new Escaparate();

        Publicacion[] publicacions = {
                new Publicacion(clientes[0], servicios[1], "¡Menudo cambio!¡Parece otra casa!"),
                new Publicacion(clientes[1], servicios[0], "Un trabajo espectacular"),
                new Publicacion(clientes[0], servicios[1], "La casa espectacular")
        };

        escaparate.anyadir(publicacions[0]);
        escaparate.anyadir(publicacions[1]);
        System.out.println();
        escaparate.mostrarTodas();
        System.out.println();
        escaparate.anyadir(publicacions[2]);
        System.out.println();
        escaparate.mostrarTodas();
    }

    public static void mostrarPrecioTotalPorSevicio(Servicio[] servicios){
        for (int i = 0; i < servicios.length; i++) {
            System.out.printf("El precio total del servicio %d es de %.2f€\n", i + 1, servicios[i].calcularCosteTotal());
        }
    }
}
