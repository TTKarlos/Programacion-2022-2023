package tienda_de_electrodomesticos;

public class TestElectrodomesticos {
    public static void main(String[] args) {
        Electrodomesticos[] electrodomesticos = {
                new Lavadora("Bosh", "Lo367-Extra-Load", "125DF6", 100),
                new Television("Lg", "HDQ5 true color", "224856EF"),
                new Television("Lg", "HDQ5 true color", "224856DF", 40, true)
        };
        Ordenador[] ordenador = {
                new Ordenador(16, 3.3f, 256, 300, "456654FD", 400),
                new Ordenador(16, 3.3f, 256, 300, "456654FDD", 400)};
        TomaCorriente tomaCorriente = new TomaCorriente();

        mostrarElectrodomesticos(electrodomesticos);

        System.out.println("==================================\n----- Parte A -------\n\n----- Parte B -------");

        tomaCorriente.conectar(electrodomesticos[0]);
        tomaCorriente.conectar(electrodomesticos[1]);
        tomaCorriente.conectar(electrodomesticos[2]);
        tomaCorriente.conectar(ordenador[0]);
        tomaCorriente.conectar(ordenador[1]);

        tomaCorriente.mostrarListadoConectados();
    }

    public static void mostrarElectrodomesticos(Electrodomesticos[] electrodomesticos){
        System.out.println("===== Listado Electrodomesticos =====");

        for (int i = 0; i < electrodomesticos.length; i++) {
            System.out.println(electrodomesticos[i]);
        }

        System.out.println("==================================");
    }
}
