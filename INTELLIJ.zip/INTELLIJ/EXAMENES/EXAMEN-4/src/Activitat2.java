public class Activitat2 {

    final static int[][] TABLA_DE_INMUEBLES = {
            {20, 10, 5, 8, 10},
            {18, 34, 18, 21, 20},
            {15, 10, 45, 21, 34},
            {8, 15, 4, 12, 12}};
    final static int[] TOTAL_INMUEBLES = {340, 420, 389, 485, 520};
    final static String[] MESSOS_DEL_ANY = {"ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO"};
    final static int PREU_PER_MOBLE = 250;
    final static int PORCENTAJE = 100;


    public static void main(String[] args) {

        int[][] tablaDeInmueble = TABLA_DE_INMUEBLES;
        int[] totalInmuebles = TOTAL_INMUEBLES;

        primeraPart(tablaDeInmueble, totalInmuebles);
        segonaPart(tablaDeInmueble, totalInmuebles);
        terceraPart(tablaDeInmueble, totalInmuebles);
        quartaPart(tablaDeInmueble, totalInmuebles);
    }

    public static void primeraPart(int[][] tablaDeInmuebles, int[] totalInmuebles) {

        int[] informacion = totalInmueblesVendidosYPrecio(tablaDeInmuebles);

        System.out.println("1. RESUMEN VENTAS");
        System.out.printf("Se han vendido %d inmuebles y han generado %d€ de beneficio\n\n", informacion[0], informacion[1]);
    }

    public static int[] totalInmueblesVendidosYPrecio(int[][] tabla) {

        int totalinmuebles = 0;

        for (int i = 0; i < tabla.length; i++) {
            for (int j = 0; j < tabla[i].length; j++) {
                totalinmuebles += tabla[i][j];
            }
        }

        return new int[]{totalinmuebles, totalinmuebles * PREU_PER_MOBLE};
    }

    public static void segonaPart(int[][] tablaDeInmuebles, int[] totalInmuebles){

        int[] informacion = totalInmueblesVendidosYPrecio(tablaDeInmuebles);

        System.out.println("2. TOTAL VENTAS POR AGENTE");
        for (int i = 1; i <= 4; i++){
            System.out.printf("Agente %d: %d Inmuebles vendidos (Media: %.2f inmuebles/mes\n", i,
                    inmueblesTotalPorAgente(i - 1, tablaDeInmuebles), mediaDeinmueblesPorMes(i - 1, tablaDeInmuebles));
        }
        System.out.println();
    }
    public static int inmueblesTotalPorAgente(int agente, int[][] tablaDeInmuebles){
        int totalInmuebles = 0;

        for(int i = 0; i <= 4; i++){
            totalInmuebles += tablaDeInmuebles[agente][i];
        }

        return totalInmuebles;
    }
    public static double mediaDeinmueblesPorMes(int agente, int[][]tablaDeInmuebles){
        double inmueblesPorAgente = inmueblesTotalPorAgente(agente, tablaDeInmuebles);
        double inmueblesTotales = tablaDeInmuebles[agente].length;

        return inmueblesPorAgente / inmueblesTotales;
    }

    public static void terceraPart(int[][] tablaDeInmuebles, int[] totalInmuebles) {

        System.out.println("3. TOTAL VENTAS MENSUALES");

        for (int i = 0; i < totalInmuebles.length; i++) {
            System.out.printf("%s, %d inmuebles disponibles - %d inmuebles vendidos (%.2f%%)\n", MESSOS_DEL_ANY[i],
                    totalInmuebles[i], inmueblesDisponiblesPorMes(tablaDeInmuebles, i),
                    porcentajeDeInmueblesVendidos(tablaDeInmuebles, totalInmuebles, i));
        }
    }

    public static int inmueblesDisponiblesPorMes(int[][] tablaDeInmuebles, int mes) {

        int totalInmuebles = 0;

        for (int i = 0; i < tablaDeInmuebles.length; i++) {
            totalInmuebles += tablaDeInmuebles[i][mes];
        }

        return totalInmuebles;
    }

    public static double porcentajeDeInmueblesVendidos(int[][] tablaDeInmuebles, int[] totalInmuebles, int mes) {
        double totalInmueble = inmueblesDisponiblesPorMes(tablaDeInmuebles, mes);
        double porcentaje = totalInmueble / totalInmuebles[mes];

        return porcentaje * PORCENTAJE;
    }

    public static void quartaPart(int[][] tablaDeInmuebles, int[] totalInmuebles) {
        System.out.println("\n4. MAXIMOS Y MINIMOS");
        System.out.printf("El agente %d es el que menos inmuebles ha vendido\n", elAgenteQueMenosAVendido(tablaDeInmuebles));
        System.out.printf("%s es el mes en el que mas inmuebles se han vendido\n", MESSOS_DEL_ANY[elMesMasVendido(totalInmuebles)]);

    }

    public static int elMesMasVendido(int[] totalInmuebles){

        int indice = 0;
        int num = totalInmuebles[0];

        for(int i = 1; i < totalInmuebles.length; i++){
            if(num < totalInmuebles[i]){
                num = totalInmuebles[i];
                indice = i;
            }
        }

        return indice;
    }

    public static int elAgenteQueMenosAVendido(int[][] tablaDeInmuebles){

        int[] arrayInmueblesPorAgente = new int[tablaDeInmuebles[0].length];

        for(int i = 0; i < 4; i++){
            arrayInmueblesPorAgente[i] = inmueblesTotalPorAgente(i, tablaDeInmuebles);
        }

        int aux = arrayInmueblesPorAgente[0];
        int indice = 0;
        for(int i = 1; i < arrayInmueblesPorAgente.length; i++){
            if(aux > arrayInmueblesPorAgente[i]){
                aux = arrayInmueblesPorAgente[i];
                indice = i;
            }
        }

        return indice;
    }
}