package activitat11;

class NIF {
    private int dni;
    private char letra;

    public NIF(int dni) {
        this.dni = dni;
        this.letra = calcularLetra(dni);
    }

    private char calcularLetra(int dni) {
        String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
        int num = dni % 23;
        return letras.charAt(num);
    }

    public String getNIF() {
        return dni + "" + letra;
    }

    public int getDni(){
        return dni;
    }

    public void mostrarInformacion(){
        System.out.printf("El NIF del DNI %d es %s\n", getDni(), getNIF());
    }
}