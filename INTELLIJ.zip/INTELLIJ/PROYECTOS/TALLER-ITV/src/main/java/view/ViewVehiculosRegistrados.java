package view;

import de.vandermeer.asciitable.AT_Row;
import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;
import entities.vehiculos.VehiculoRegistrado;
import java.util.ArrayList;

public class ViewVehiculosRegistrados {
    private ArrayList<VehiculoRegistrado> vehiculoRegistrados;

    public ViewVehiculosRegistrados(ArrayList<VehiculoRegistrado> vehiculoRegistrados) {
        this.vehiculoRegistrados = vehiculoRegistrados;
    }

    private String getTablaResgistrosVehiculos(){
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow(null, null, null, null, "Listado de Vehiculos Registrados");
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow("Codigo", "Matricula", "Fecha de Revision", "DNI del Mecanico", "Importe Total");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        if(!vehiculoRegistrados.isEmpty()){
            for (int i = 0; i < vehiculoRegistrados.size(); i++) {
                table.addRule();
                row = table.addRow(vehiculoRegistrados.get(i).getCodigo(), vehiculoRegistrados.get(i).getMatriculaVehiculo(),
                        vehiculoRegistrados.get(i).getFechaRevision(), vehiculoRegistrados.get(i).getDniMecanico(),
                        vehiculoRegistrados.get(i).getImporte());
                row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
                row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
                row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
                row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
                row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
            }
        } else {
            table.addRule();
            row = table.addRow(null, null, null, null, "No hay vehiculos registrados");
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        }


        table.addRule();
        row = table.addRow("*", "*", "*", "*", "*");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        table.addRule();

        return table.render();
    }

    @Override
    public String toString() {
        return getTablaResgistrosVehiculos();
    }
}