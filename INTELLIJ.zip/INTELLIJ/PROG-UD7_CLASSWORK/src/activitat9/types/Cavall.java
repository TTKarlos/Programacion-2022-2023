package activitat9.types;

import activitat9.Animal;
import activitat9.Mascota;
import activitat9.enums.Comida;
import activitat9.enums.Tamany;

public class Cavall extends Animal{
    public Cavall(boolean vacunado, Comida comida, int hambre, Tamany tamanio, String localizacion){
        super(vacunado, comida, hambre, tamanio, localizacion);
    }

    public void emitirSonido(){
        System.out.println("IJIJIJIJI!!!!!!!!!");
    }

    @Override
    public void vacunar(){
        System.out.println("Vacunando a un Caballo...");
        super.vacunar();
        emitirSonido();
    }

    @Override
    public String toString() {
        return "Caballo: " + super.toString();
    }
}