import java.util.Scanner;

public class Actividad3 {
    final static int NEUTRAL = 0;
    final static int INICIO = 1;
    final static int N = 2;
    final static int VENTAS_COMERCIAL = 4;
    final static int SEMANAS_UN_MES = 4;
    final static int SUELDO_MENSUAL_BASE = 800;
    final static int VALOR_DIFERENCIADOR_COMISIONES = 100;

    final static float COMISION_INFERIOR_100 = 0.05f;
    final static float COMISION_SUPERIOR_100 = 0.03f;

    public static void main(String[] args) {
        Scanner usuario = new Scanner(System.in);

        boolean datoCorrecto = false;

        int contadorComerciales = INICIO;

        float valorVenta = NEUTRAL;
        float totalCobroMes, comision;
        float totalComisionSemana = NEUTRAL;
        float totalComision = NEUTRAL;

        System.out.println("PROGRAMA NÓMINAS Empresa Desarrollos Móviles");
        System.out.println("============================================");
        System.out.println("Número de comerciales (N): " + N + "\n");

        while(contadorComerciales <= N) {
            for (int i = INICIO; i <= SEMANAS_UN_MES; i++) {
                for (int j = INICIO; j <= VENTAS_COMERCIAL; j++) {
                    while (!datoCorrecto) {
                        System.out.printf("Venta %d de la semana %d del comercial %d(€): ", j, i, contadorComerciales);

                        if(usuario.hasNextFloat()){
                            valorVenta = usuario.nextFloat();

                            datoCorrecto = true;

                        } else{
                            return;
                        }
                    }

                    if(valorVenta >= VALOR_DIFERENCIADOR_COMISIONES){
                        comision = valorVenta * COMISION_SUPERIOR_100;

                    } else{
                        comision = valorVenta * COMISION_INFERIOR_100;
                    }

                    totalComisionSemana += comision;

                    datoCorrecto = false;
                }

                System.out.printf("Las comisiones del comercial %d en la semana %d es de %.2f€\n\n",
                        contadorComerciales, i, totalComisionSemana);

                totalComision += totalComisionSemana;

                totalComisionSemana = NEUTRAL;
            }

            totalCobroMes = SUELDO_MENSUAL_BASE + totalComision;

            System.out.printf("El sueldo mensual a recibir por el comercial %d es %.2f€\n\n\n", contadorComerciales,
                    totalCobroMes);

            totalComision = NEUTRAL;

            contadorComerciales++;
        }
    }
}