public class IndianaJones {

    final static int[] ARRAY_INDIANA_JONES = {1, 1};
    final static int PUNTO_X = 0;
    final static int PUNTO_Y = 1;

    public static int[] obtenerPosicionInicio(){
        return ARRAY_INDIANA_JONES;
    }

    public static void reestablecerAPosicionInicial(int[] posicion){

        int[] posicionInicial = obtenerPosicionInicio();

        posicion[PUNTO_X] = posicionInicial[PUNTO_X];
        posicion[PUNTO_Y] = posicionInicial[PUNTO_Y];
    }

    public static void moverEnDireccion(String[][] escenario, int direccion, int[] posicion) {
        int[] nuevaPosicion = Movimiento.obtenerCoordenadaAdyacente(direccion, posicion);
        if (Escenario.esUnPuntoDelEscenario(escenario,nuevaPosicion[PUNTO_X], nuevaPosicion[PUNTO_Y]) &&
                Escenario.estaPermitidoElPaso(escenario, nuevaPosicion[PUNTO_X], nuevaPosicion[PUNTO_Y])){
            posicion[PUNTO_X] = nuevaPosicion[PUNTO_X];
            posicion[PUNTO_Y] = nuevaPosicion[PUNTO_Y];
        }
    }
}