package com.example.gestion_de_usuarios.modelo.exceptions;

public class NotFoundException extends RuntimeException{
    public NotFoundException(){
        super();
    }
}