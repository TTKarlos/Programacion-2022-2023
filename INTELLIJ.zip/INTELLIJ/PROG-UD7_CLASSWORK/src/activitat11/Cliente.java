package activitat11;

public class Cliente {

    private String nombre;
    private int telefono;
    private String dni;
    private String nombreDeCompañia;

    public Cliente(String nombre, int telefono, String dni, String nombreDeCompañia){
        this.nombre = nombre;
        this.telefono = telefono;
        this.dni = dni;
        this.nombreDeCompañia = nombreDeCompañia;
    }

    public String getDni() {
        return dni;
    }
}
