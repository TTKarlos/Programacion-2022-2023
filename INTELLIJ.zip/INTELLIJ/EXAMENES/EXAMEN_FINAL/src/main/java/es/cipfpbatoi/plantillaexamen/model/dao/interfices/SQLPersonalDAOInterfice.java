package es.cipfpbatoi.plantillaexamen.model.dao.interfices;

import es.cipfpbatoi.plantillaexamen.exceptions.NotFoundException;
import es.cipfpbatoi.plantillaexamen.utils.Trabajador;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public interface SQLPersonalDAOInterfice {
    boolean save(Trabajador trabajador);
    Trabajador findById(String dni) throws NotFoundException;
    ArrayList<Trabajador> findAll();
    ArrayList<Trabajador> findAllBuscador(String buscadorPor, String searchField);
}