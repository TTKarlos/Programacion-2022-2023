package activitat11;

public class Vendedor extends Empleado {

    final static float INCREMENTAR_SALARI = 0.1f;
    final static int CLIENTES_MAXIMOS = 10;
    private boolean tieneCocheDeLaEmpresa;
    private int areaDeVenta;
    private Cliente[] listaDeClientes;
    private float porcentajeDeVentas;

    public Vendedor(String nombre, String apellidos, String dni, String fechaDeInicio, String telefono, float salario,
                    boolean tieneCocheDeLaEmpresa, int areaDeVenta, Cliente[] listaDeClientes, float porcentajeDeVentas){
        super(nombre, apellidos, dni, fechaDeInicio, telefono, salario);
        this.tieneCocheDeLaEmpresa = tieneCocheDeLaEmpresa;
        this.areaDeVenta = areaDeVenta;
        this.listaDeClientes = listaDeClientes;
        this.porcentajeDeVentas = porcentajeDeVentas;
    }

    public void incrementarSalario(){
        setSalario(getSalario() + (getSalario() * INCREMENTAR_SALARI));
    }

    public void añadirCliente(Cliente cliente){

        if(listaDeClientes.length >= CLIENTES_MAXIMOS){
            System.out.printf("Máximo puedes tener %d clientes.", CLIENTES_MAXIMOS);
            return;
        }

        if(hayNull(cliente)){
            return;
        }

        Cliente[] nuevosClientes = new Cliente[listaDeClientes.length + 1];

        for (int i = 0; i < listaDeClientes.length; i++) {
            nuevosClientes[i] = listaDeClientes[i];
        }
        nuevosClientes[nuevosClientes.length - 1] = cliente;
        this.listaDeClientes = nuevosClientes;
    }

    private boolean hayNull(Cliente cliente){
        for (int i = 0; i < listaDeClientes.length; i++) {
            if (listaDeClientes[i] == null) {
                listaDeClientes[i] = cliente;
                return true;
            }
        }

        return false;
    }

    public void eliminarCliente(Cliente nombre){
        for (int i = 0; i < listaDeClientes.length; i++) {
            if(nombre.getDni().equalsIgnoreCase(listaDeClientes[i].getDni())){
                listaDeClientes[i] = null;
                return;
            }
        }
    }

    private int numClientes(){

        int contador = 0;

        for (int i = 0; i < listaDeClientes.length; i++){
            if(listaDeClientes[i] != null){
                contador++;
            }
        }

        return contador;
    }

    @Override
    public String toString() {
        return "Puesto en la empresa: VENDEDOR, " + super.toString() + ", Numero Clientes: " + numClientes();
    }
}