import activitat17.Cambio;
import activitat17.Cotxe;
import activitat17.Tipo;

public class TestCotxe {

    public static void main(String[] args) {

        Cotxe ibiza = new Cotxe("Seat", Cambio.AUTOMATIC, Tipo.TURISMO);
        Cotxe renault = new Cotxe(Tipo.CROSSOVER, "Renault");
        Cotxe renault2 = new Cotxe(Tipo.DEPORTIVO, "Renault");
        Cotxe citroen = new Cotxe("citroen");

        System.out.println(ibiza);
        System.out.println(renault);
        System.out.println(renault2);
        System.out.println(citroen);

    }
}
