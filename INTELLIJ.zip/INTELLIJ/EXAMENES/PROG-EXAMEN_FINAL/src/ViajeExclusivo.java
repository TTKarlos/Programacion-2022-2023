import exception.ReservaNoValidaException;

import java.time.LocalDateTime;

public class ViajeExclusivo extends Viaje{
    private boolean estaCerrado;
    public ViajeExclusivo(String codigo, String ruta, LocalDateTime fechayHoraDeEmpezar, float precio,
                          int duracionEnDias, int plazasOferidas){
        super(codigo, ruta, fechayHoraDeEmpezar, precio, duracionEnDias, plazasOferidas);
        this.estaCerrado = false;
    }

    @Override
    public void realizarReserva(String nombreCompleto, int numeroDePlazasSolicitadas){
        try {
            estaPermitidoLaReserva();
            super.realizarReserva(nombreCompleto, numeroDePlazasSolicitadas);
            estaCerrado = true;
        } catch (ReservaNoValidaException e){
            System.out.println(e.getMessage());
        }
    }

    private void estaPermitidoLaReserva(){
        if(estaCerrado){
            throw new ReservaNoValidaException();
        }
    }
}