import java.util.Scanner;

public class Activitat13 {

    final static String CAS1 = "Mico";
    final static String CAS2 = "Gall";
    final static String CAS3 = "Gos";
    final static String CAS4 = "Porc";
    final static String CAS5 = "Rata";
    final static String CAS6 = "Bou";
    final static String CAS7 = "Tigre";
    final static String CAS8 = "Conill";
    final static String CAS9 = "Drac";
    final static String CAS10 = "Serp";
    final static String CAS11 = "Cavall";
    final static String CAS12 = "Ovella";
    final static int MESES_EN_UN_ANY = 12;

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int any;

        System.out.print("Introdueix l'any (D.C) del qual vols saber l'horòscop xinés: ");

        if (!teclado.hasNextInt()){
            System.out.println("Error! El tipus de dades introduït és incorrecte");
            return;
        } else {
            any = teclado.nextInt();
        } if (any < 0){
            System.out.println("Error! L’any introduït no és correcte");
            return;
        } else System.out.print("El teu horòscop xinés correspon a ");

        int ciclo = (any % MESES_EN_UN_ANY) + 1;

        switch (ciclo){
            case 1 -> System.out.println(CAS1);
            case 2 -> System.out.println(CAS2);
            case 3 -> System.out.println(CAS3);
            case 4 -> System.out.println(CAS4);
            case 5 -> System.out.println(CAS5);
            case 6 -> System.out.println(CAS6);
            case 7 -> System.out.println(CAS7);
            case 8 -> System.out.println(CAS8);
            case 9 -> System.out.println(CAS9);
            case 10 -> System.out.println(CAS10);
            case 11 -> System.out.println(CAS11);
            case 12 -> System.out.println(CAS12);
        }
    }
}
