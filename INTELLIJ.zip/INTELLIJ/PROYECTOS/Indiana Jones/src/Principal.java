import java.util.Scanner;

public class Principal {

    final static int VELOCIDAD_DEL_TEXTO = 40;
    final static String RESET_COLOR = "\u001B[0m";
    final static String TEXTO_INSTRUCCIONES =
            "Eʀᴇs ᴜɴ ʟᴀᴅʀᴏ́ɴ ʏ ᴅᴇʙᴇs ᴄᴏɴsᴇɢᴜɪʀ ʀᴏʙᴀʀ ᴛᴏᴅᴀs ʟᴀs ᴊᴏʏᴇʀɪ́ᴀs ᴅᴇ ᴛᴜ ᴄɪᴜᴅᴀᴅ ᴘᴀʀᴀ ᴘᴏᴅᴇʀ ɢᴀɴᴀʀ,\n" +
            "ᴘᴏʀ ᴇʟ ᴄᴀᴍɪɴᴏ ᴛᴇ ᴘᴜᴇᴅᴇs ᴇɴᴄᴏɴᴛʀᴀʀ ᴘᴇᴏᴜᴇɴ̃ᴀs ᴛɪᴇɴᴅᴀs ᴏᴜᴇ ᴛᴇ ᴅᴀʀᴀ́ɴ ᴜɴ ᴘᴏᴄᴏ ᴍᴀs ᴅᴇ ᴅɪɴᴇʀᴏ.\n" +
            "Es ᴍᴜʏ ɪᴍᴘᴏʀᴛᴀɴᴛᴇ ᴘᴇɴsᴀʀ ʙɪᴇɴ ᴛᴜs ᴍᴏᴠɪᴍɪᴇɴᴛᴏs ᴀɴᴛᴇs ᴅᴇ ɪɴᴛᴇɴᴛᴀʀ ᴇsᴄᴀᴘᴀʀ ᴅᴇ ʟᴀ ᴘᴏʟɪᴄɪ́ᴀ,\n" +
            "ᴘᴏʀ ᴏᴜᴇ sɪ ᴛᴇ ᴘɪʟʟᴀɴ ᴍᴀs ᴅᴇ 3 ᴠᴇᴄᴇs ᴇɴᴛʀᴀʀᴀ́s ᴇɴ ᴘʀɪsɪᴏ́ɴ.\n\n";
    final static String TEXTO_BIENVENVENIDA =
            "▒█▀▀█ ░▀░ █▀▀ █▀▀▄ ▀█░█▀ █▀▀ █▀▀▄ ░▀░ █▀▀▄ █▀▀█ 　 █▀▀█ \n" +
            "▒█▀▀▄ ▀█▀ █▀▀ █░░█ ░█▄█░ █▀▀ █░░█ ▀█▀ █░░█ █░░█ 　 █▄▄█ \n" +
            "▒█▄▄█ ▀▀▀ ▀▀▀ ▀░░▀ ░░▀░░ ▀▀▀ ▀░░▀ ▀▀▀ ▀▀▀░ ▀▀▀▀ 　 ▀░░▀ \n" +
            "\n" +
            "▒█░░░ █▀▀█ █▀▀▄ █▀▀█ █▀▀█ █▀▀▄ █▀▀ █▀▀ 　 █░░█ 　 ▒█▀▀█ █▀▀█ █░░ ░▀░ █▀▀ ░▀░ █▀▀█ █▀▀ \n" +
            "▒█░░░ █▄▄█ █░░█ █▄▄▀ █░░█ █░░█ █▀▀ ▀▀█ 　 █▄▄█ 　 ▒█▄▄█ █░░█ █░░ ▀█▀ █░░ ▀█▀ █▄▄█ ▀▀█ \n" +
            "▒█▄▄█ ▀░░▀ ▀▀▀░ ▀░▀▀ ▀▀▀▀ ▀░░▀ ▀▀▀ ▀▀▀ 　 ▄▄▄█ 　 ▒█░░░ ▀▀▀▀ ▀▀▀ ▀▀▀ ▀▀▀ ▀▀▀ ▀░░▀ ▀▀▀ \n" + RESET_COLOR;
    static Scanner scanner;

    public static void main(String[] args) throws InterruptedException {
        scanner = new Scanner(System.in);
        inicio();
    }

    public static void inicio() throws InterruptedException {

        System.out.println(TEXTO_BIENVENVENIDA);
        Juego.mostrarTexto(TEXTO_INSTRUCCIONES, VELOCIDAD_DEL_TEXTO);

        String[][] escenario = Escenario.creaEscenario();
        int[] posicionIndianaJones = IndianaJones.obtenerPosicionInicio();
        int[][] posicionSerpientes = Serpientes.obtenerPosicionesInicio();

        do {
            Juego.imprimirEscenario(escenario, posicionIndianaJones, posicionSerpientes);
            Juego.moverATodos(escenario, posicionIndianaJones, posicionSerpientes);
            Juego.actualizarDatos(escenario, posicionIndianaJones, posicionSerpientes);
        } while(!Juego.seHaTerminado(escenario));

        Juego.imprimirMensajeFinDeJuego(escenario);
    }
}