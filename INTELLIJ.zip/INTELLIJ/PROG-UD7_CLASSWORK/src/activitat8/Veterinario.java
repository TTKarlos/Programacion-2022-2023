package activitat8;

public class Veterinario {

    public static void vacunar(Animal animal){
    }
}