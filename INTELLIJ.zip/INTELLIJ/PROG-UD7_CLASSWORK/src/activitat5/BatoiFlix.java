package activitat5;

public class BatoiFlix {
    public static void main(String[] args) {

        Pelicula pelicula = new Pelicula("News of the World", "AVI" ,"2h 0min 0s",
                2020, "Tom Hanks", "Carolina Betller");
        pelicula.setDescripcion("Lorem Ipsum Lorem Ipsum Lorem Ipsum");

        Documental documental = new Documental("Dream Songs", "MPG", "1h 0min 0s",
                2021, "Enrique Juncosa", "Movimiento Hippie");
        documental.setDescripcion("Lorem Ipsum Lorem Ipsum Lorem Ipsum");

        Serie serie = new Serie("El hacker", "FLV", "0h 40min 0s", 2001,
                1,20 );
        serie.setDescripcion("Lorem Ipsum Lorem Ipsum Lorem Ipsum");

        System.out.println("Listado Producciones (Uso toString()):");
        System.out.println(pelicula);
        System.out.println(serie);
        System.out.println(documental);

        System.out.println("\nDetalle Producciones (Uso mostrarDetalle()):");
        pelicula.mostrarDetalle();
        serie.mostrarDetalle();
        documental.mostrarDetalle();
    }

}