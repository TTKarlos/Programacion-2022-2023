package activitat3;

public class Coxte extends Vehiculo{
    private float carburant;
    private String matricula;

    public Coxte(int velocitat, int carburant, String matricula){
        super(velocitat);
        this.carburant = carburant;
        this.matricula = matricula;
    }

    @Override
    public void acelerar(){
        super.acelerar();
        carburant -= 0.5;
    }

    public void proveir(int quantitat){
        carburant += quantitat;
    }

    @Override
    public String toString() {
        return super.toString() + "carbutant:" + carburant;
    }
}