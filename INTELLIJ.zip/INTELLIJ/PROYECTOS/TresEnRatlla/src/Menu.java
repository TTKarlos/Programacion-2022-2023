import java.util.Scanner;

public class Menu {
    final static String COLOR_ROJO = "\u001B[31m";
    final static String COLOR_NARANJA = "\u001B[35m";
    final static String COLOR_AZUL = "\u001B[34m";
    final static String RESET_COLOR = "\u001B[0m";
    final static int NUM_PRIMERA_OPCION = 1;
    final static int NUM_SEGUNDA_OPCION = 2;
    final static int NUM_TERCERA_OPCION = 3;
    final static int NUM_OPCION_SALIR = 4;
    final static String TEXTO_ERROR_DE_SELECCION = COLOR_ROJO + "Error!" + RESET_COLOR + " Introduce una opcion correcta";

    private Jugador[] jugadores;
    private Icono icono;

    public Menu(){
        this.jugadores = jugadoresSeleccionados();
    }

    public Jugador[] getJugadores() {
        return jugadores;
    }

    public Icono getIcono() {
        return icono;
    }

    private int eleccionDeModoDeJuego(){
        Scanner teclado = new Scanner(System.in);

        System.out.printf("%s1)%s Jugador 1 %svs%s Jugador 2\n%s2)%s Ordenador %svs%s Ordenador\n%s3)%s Jugador " +
                        "%svs%s Ordenador\n%s4)%s Salir\n", COLOR_ROJO, RESET_COLOR, COLOR_NARANJA, RESET_COLOR,
                COLOR_ROJO, RESET_COLOR, COLOR_NARANJA, RESET_COLOR, COLOR_ROJO, RESET_COLOR, COLOR_NARANJA,
                RESET_COLOR, COLOR_ROJO, RESET_COLOR);

        do{
            System.out.printf(COLOR_AZUL + "Elige opcion [1-%d]: %s", NUM_OPCION_SALIR, RESET_COLOR);

            if(!teclado.hasNextInt()){
                System.out.println(TEXTO_ERROR_DE_SELECCION);
            } else {
                int num = teclado.nextInt();

                if(num >= NUM_PRIMERA_OPCION && num <= NUM_OPCION_SALIR){
                    return num;
                }
            }
        } while (true);
    }

    private Jugador[] jugarDosJugadoresManuales(){
        this.icono = new Icono();
        Jugador[] jugadores = {new JugadorManual(EstadoCasilla.FICHA_X, icono),
                new JugadorManual(EstadoCasilla.FICHA_O, icono)};
        return jugadores;
    }

    private Jugador[] jugarDosJugadoresPCs(){
        this.icono = new Icono();
        Jugador[] jugadores = {new JugadorPC(EstadoCasilla.FICHA_X, icono),
                new JugadorPC(EstadoCasilla.FICHA_O, icono)};
        return jugadores;
    }

    private Jugador[] jugarUnJugadorYUnoDePc(){
        this.icono = new Icono();
        Jugador[] jugadores = {new JugadorManual(EstadoCasilla.FICHA_X, icono),
                new JugadorPC(EstadoCasilla.FICHA_O, icono)};
        return jugadores;
    }

    private Jugador[] jugadoresSeleccionados(){
        switch (eleccionDeModoDeJuego()){
            case NUM_PRIMERA_OPCION -> {
                return jugarDosJugadoresManuales();
            }
            case NUM_SEGUNDA_OPCION -> {
                return jugarDosJugadoresPCs();
            }
            case NUM_TERCERA_OPCION -> {
                return jugarUnJugadorYUnoDePc();
            }
            default -> {
                return new Jugador[]{null, null};
            }
        }
    }
}