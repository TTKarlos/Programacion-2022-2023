package com.example.batoiflix.modelo.dao.interfaces;

import com.example.batoiflix.modelo.entities.Usuario;
import java.util.ArrayList;

public interface UsuarioDAOInterface {
    ArrayList<Usuario> findAll() throws Exception;
    boolean save(Usuario usuario) throws Exception;
    Usuario getByID(int id) throws Exception;
    Usuario getByName(String nombre,String apellidos) throws Exception;
    Usuario getByEmail(String email) throws Exception;

}