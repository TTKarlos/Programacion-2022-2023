public class Coordenada {
    final static int DIMENSIO_MINIMA = 0;
    private int fila;
    private int columna;

    public Coordenada(int filas, int columnas){
        this.fila = filas;
        this.columna = columnas;
    }
    public boolean isValida(int dimension){
        return (fila >= DIMENSIO_MINIMA && fila <= dimension - 1 && columna <= dimension - 1 && columna >= DIMENSIO_MINIMA);
    }

    public int getColumna() {
        return columna;
    }

    public int getFila() {
        return fila;
    }
}