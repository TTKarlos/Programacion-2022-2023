package activitat2;

import activitat2.Persona;

public class TestPersona {
    Persona persona = new Persona("Andreu");
}