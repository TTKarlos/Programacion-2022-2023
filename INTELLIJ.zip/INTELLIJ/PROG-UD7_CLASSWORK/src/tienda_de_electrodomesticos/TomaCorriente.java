package tienda_de_electrodomesticos;

public class TomaCorriente {
    private Conectable[] listadoConectados;

    public TomaCorriente(){
        listadoConectados = new Conectable[10];
    }

    public int obtenerNumeroTomasLibres(){
        int contador = 0;

        for (int i = 0; i < listadoConectados.length; i++){
            if(listadoConectados[i] == null){
                contador++;
            }
        }

        return contador;
    }

    public void desconectar(Conectable conectable){
        for (int i = 0; i < listadoConectados.length; i++) {
            if(listadoConectados[i] != null && listadoConectados[i].equals(conectable)){
                listadoConectados[i] = null;
                conectable.apagar();
                return;
            }
        }

        System.out.println("El conectable no existe");
    }

    public void conectar(Conectable conectable){
        for (int i = 0; i < listadoConectados.length; i++) {
            if(listadoConectados[i] == null){
                listadoConectados[i] = conectable;
                conectable.encender();
                return;
            }
        }

        System.out.println("El conectable no existe");
    }

    public void mostrarListadoConectados(){
        System.out.println("===== Listado Aparatos Conectados =====");

        for (int i = 0; i < listadoConectados.length; i++) {
            if(listadoConectados[i] != null){
                System.out.println(listadoConectados[i].toString());
            }
        }

        System.out.println("==================================");
    }
}