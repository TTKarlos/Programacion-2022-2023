package es.puchades.menus.opciones.opcionesVisualizarPedido;

import es.puchades.Restaurante;

public class BuscarPedidoHistoricoOpcion extends OpcionesVisualizarPedido{
    protected Restaurante restaurante;

    public BuscarPedidoHistoricoOpcion(Restaurante restaurante) {
        super("Buscar y visualizar pedidos del Histórico", restaurante);
        this.restaurante = restaurante;
    }

    @Override
    public void ejecutar() {
        restaurante.buscarHistorico();
    }
}