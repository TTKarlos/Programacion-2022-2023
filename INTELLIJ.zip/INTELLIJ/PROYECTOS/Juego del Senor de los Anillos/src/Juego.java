public class Juego {
    public static void main(String[] args) {

        if(Niveles.inici() && Niveles.nivel1() && Niveles.nivel2() && Niveles.nivel3() && Niveles.nivel4() && Niveles.nivel5()){
            Niveles.guanyar();
            Niveles.fi();
        } else {
            Niveles.perdre();
        }
    }
}