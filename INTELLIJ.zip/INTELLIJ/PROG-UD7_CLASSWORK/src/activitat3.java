import java.util.Random;
import java.util.Scanner;

public class activitat3 {
    public static void main(String[] args) {

        int[][] array = crearArray();
        int[] sumaFilas = sumaDeFilas(array);
        int[] sumaColumnas = sumaDeColumnas(array);
        int sumaTotal = sumaDeArray(sumaFilas) + sumaDeArray(sumaColumnas);

        mostrarInformacion(array, sumaFilas, sumaColumnas, sumaTotal);
    }

    public static int[][] crearArray(){
        Random random = new Random();

        int[][] array = new int[4][5];

        int contador = 1;

        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[0].length; j++) {
                array[i][j] = random.nextInt(899) + 100;
                contador++;
            }
        }

        return array;
    }

    public static int[] sumaDeFilas(int[][] array){
        int[] sumaFilas = new int[array.length];

        for (int i = 0; i < array.length; i++) {
            int contador = 0;

            for (int j = 0; j < array[i].length; j++) {
                contador += array[i][j];
            }

            sumaFilas[i] = contador;
        }

        return sumaFilas;
    }

    public static int[] sumaDeColumnas(int[][] array){
        int[] sumaColumnas = new int[array[0].length];

        for (int i = 0; i < array[0].length; i++) {
            int contador = 0;

            for (int j = 0; j < array.length; j++) {
                contador += array[j][i];
            }

            sumaColumnas[i] = contador;
        }

        return sumaColumnas;
    }

    public static int sumaDeArray(int[] array){
        int contador = 0;

        for (int i = 0; i < array.length; i++) {
            contador += array[i];
        }

        return contador;
    }

    public static void mostrarInformacion(int[][] array, int[] sumaFilas, int[] sumaColumnas, int sumaTotal){

        int indice = 0;

        for(int i = 0; i < array.length; i++){
            for (int j = 0; j < array[i].length; j++){
                System.out.print(array[i][j] + "  ");
            }
            System.out.println("= " + sumaFilas[indice]);
            indice++;
        }

        for (int i = 0; i < sumaColumnas.length; i++) {
            System.out.print("=" + sumaColumnas[i] + " ");
        }

        System.out.println("=" + sumaTotal);
    }
}
