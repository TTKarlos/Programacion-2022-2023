package entities;

import entities.repositorios.ColaInicial;
import entities.repositorios.RegistroVehiculos;
import entities.vehiculos.Vehiculo;
import entities.vehiculos.type.Camion;
import entities.vehiculos.type.Coche;
import entities.vehiculos.type.Furgoneta;
import entities.vehiculos.type.MicroBus;
import exceptions.*;
import utils.GestioIO;
import view.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class Taller {
    private static final int INDEX_INICIAL = 0;
    private static final int NUM_PRIMER_BOX = 1;
    private static final int NUMERO_ERROR_POSICION = -1;
    private ColaInicial colaInicial;
    private RegistroVehiculos registroVehiculos;
    private Box[] boxes;

    public Taller(Box[] boxes) {
        this.boxes = boxes;
        this.colaInicial = new ColaInicial();
        this.registroVehiculos = new RegistroVehiculos();
    }

    public void recepcionarVehiculo(){
        try {
            Vehiculo vehiculo = crearVehiculo();
            System.out.println(new ViewVehiculo(vehiculo));

            if(GestioIO.eligeSiONo("Quieres añadir este vehiculo a la cola ")){
                colaInicial.anyadir(vehiculo);
            }
        } catch (FechaIncorrectaException | YaExisteException | VehiculoIncorrectoException | ColaLlenaException e){
            GestioIO.mostrarTextoEnError(e.getMessage());
        }
    }

    public void reclamarVehiculo(){
        Vehiculo vehiculo = null;
        try{
            vehiculo = colaInicial.sacar();
            System.out.println(new ViewVehiculo(vehiculo));

            System.out.println(new ViewBoxes(boxes));
            int opcion = GestioIO.devolverNumeroEntreXyY("En que Box quieres meter el vehiculo ",
                    NUM_PRIMER_BOX, boxes.length) - 1;
            boxes[opcion].reclamarVehiculo(vehiculo);

        } catch (ColaVaciaException e){
            GestioIO.mostrarTextoEnError(e.getMessage());
        } catch (FaseOcupadaException e) {
            GestioIO.mostrarTextoEnError(e.getMessage());
            colaInicial.devolver(vehiculo);
        }
    }

    public void moverVehiculoDeFase(){

        try{
            Scanner teclado = new Scanner(System.in);
            ArrayList<Vehiculo> vehiculos = getAllVehiculos();

            existenVehiculos(vehiculos);
            System.out.println(new ViewVehiculos(vehiculos));
            int posicionBox;
            String matricula;

            do{
                GestioIO.mostrarTextoEnAzul("Elige una matricula: ");
                matricula = teclado.next();
                posicionBox = getPosicionVehiculoEnBox(matricula);
            } while (posicionBox == NUMERO_ERROR_POSICION);

            Vehiculo vehiculo = boxes[posicionBox].moverVehiculoDeFase(matricula);

            if(vehiculo != null){
                registroVehiculos.anyadir(vehiculo.getMatricula(), vehiculo.getFechaUltimaRevision(),
                        boxes[posicionBox].getMecanico().getDni(), vehiculo.calcularPrecioRevision());
            }
        } catch (ColaVaciaException e){
            GestioIO.mostrarTextoEnError(e.getMessage());
        } catch (FaseOcupadaException | SinMecanicoException e) {
            throw new RuntimeException(e);
        }
    }

    public void moverMecanicoDeFase(){
        try{
            ArrayList<Mecanico> mecanicos = getAllMecanicos();
            existenMecanicos(mecanicos);
            System.out.println(new ViewMecanicos(mecanicos));
            int posicionBox = getPosicionMecanicoPorDNI();

            do {
                int posicionMecanico = GestioIO.devolverNumeroEntreXyY("Elige la Fase donde ira el Mecanico ",
                        NUM_PRIMER_BOX, boxes.length) - 1;

                if((boxes[posicionBox].getPosicionMecanico()) == posicionMecanico){
                    GestioIO.mostrarTextoEnError("Error! El mecanico ya esta en la fase " + (posicionMecanico));
                } else {
                    boxes[posicionBox].setPosicionMecanico(posicionMecanico);
                    return;
                }
            } while (true);
        } catch (ColaVaciaException e){
            GestioIO.mostrarTextoEnError(e.getMessage());
        }
    }

    public void mostrarInformacionDeUnBoxConcreto(){
        GestioIO.mostrarTextoEnAzul("Eliga un Box para mostrar su informacion:\n");
        int posicionBox = GestioIO.devolverNumeroEntreXyY("Introduce un numero entre",
                NUM_PRIMER_BOX, boxes.length) - 1;

        System.out.println(new ViewBox(boxes[posicionBox], posicionBox + 1));
    }

    public void mostrarInformacionDeTodosLosBoxes(){
        System.out.println(new ViewBoxes(boxes));
    }

    public void mostrarInformacionDeTodosLosVehiculosRegistrados(){
        LocalDate fechaInicial = GestioIO.pedirFecha("Elige una fecha de inicio de busqueda");
        LocalDate fechaFinal = GestioIO.pedirFecha("Elige una fecha de fin de busqueda");

        System.out.println(new ViewVehiculosRegistrados(registroVehiculos.devolverPorFecha(fechaInicial, fechaFinal)));
    }

    //--------------------------------------------------UTILIDADES--------------------------------------------------\\
    private int getPosicionMecanicoPorDNI(){
        Scanner teclado = new Scanner(System.in);

        do{
            System.out.print("Introduce el DNI del Mecanico que quieres elegir: ");
            String dniMecanico = teclado.next();
            int posicionBox = getPosicionBoxConElDniDelMecanico(dniMecanico);

            if(posicionBox == NUMERO_ERROR_POSICION){
                GestioIO.mostrarTextoEnError("Error! El dni " + dniMecanico + " no corresponde a ningun mecanico.");
            } else {
                return posicionBox;
            }
        } while (true);
    }

    private int getPosicionBoxConElDniDelMecanico(String dniDelMecanico){
        Mecanico mecanico = new Mecanico(dniDelMecanico);

        for (int i = INDEX_INICIAL; i < boxes.length; i++) {
            if(boxes[i].getMecanico().equals(mecanico)){
                return i;
            }
        }

        return NUMERO_ERROR_POSICION;
    }

    private int getPosicionVehiculoEnBox(String matricula){
        for (int i = INDEX_INICIAL; i < boxes.length; i++) {
            for (int j = INDEX_INICIAL; j < boxes[i].getVehiculos().length; j++) {
                if(boxes[i].getVehiculos()[j] != null && boxes[i].getVehiculos()[j].getMatricula().equalsIgnoreCase(matricula)){
                    return i;
                }
            }
        }

        return NUMERO_ERROR_POSICION;
    }

    private ArrayList<Vehiculo> getAllVehiculos(){
        ArrayList<Vehiculo> vehiculos = new ArrayList<>();

        for (int i = INDEX_INICIAL; i < boxes.length; i++) {
            for (int j = INDEX_INICIAL; j < boxes[i].getVehiculos().length; j++) {
                if(boxes[i].getVehiculos()[j] != null){
                    vehiculos.add(boxes[i].getVehiculos()[j]);
                }
            }
        }

        return vehiculos;
    }

    private ArrayList<Mecanico> getAllMecanicos(){
        ArrayList<Mecanico> mecanicos = new ArrayList<>();

        for (int i = INDEX_INICIAL; i < boxes.length; i++) {
            mecanicos.add(boxes[i].getMecanico());
        }

        return mecanicos;
    }

    private Vehiculo crearVehiculo(){
        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduce la matricula: ");
        String matricula = teclado.next();
        System.out.print("Introduce la marca: ");
        String marca = teclado.next();
        System.out.print("Introduce el modelo: ");
        String modelo = teclado.next();
        int cilindros = GestioIO.devolverNumeroEntreXyY("Introduce el numero de Cilindrada ", 1, 100);
        int numeroPlazas = GestioIO.devolverNumeroEntreXyY("Introduce el numero de Plazas ", 1, 100);
        int potenciaCC = GestioIO.devolverNumeroEntreXyY("Introduce el numero de PotenciaCC ", 1, 10000);
        Class tipoVehiculo = GestioIO.devolverTipoVehiculo();

        if(tipoVehiculo == Coche.class){
            return new Coche(matricula, marca, modelo, cilindros, numeroPlazas, potenciaCC);
        } else if (tipoVehiculo == MicroBus.class) {
            return new MicroBus(matricula, marca, modelo, cilindros, numeroPlazas, potenciaCC);
        } else if (tipoVehiculo == Furgoneta.class) {
            System.out.print("Introduce el PMA: ");
            float PMA = teclado.nextFloat();
            return new Furgoneta(matricula, marca, modelo, cilindros, numeroPlazas, potenciaCC, PMA);
        } else {
            System.out.print("Introduce el PMA: ");
            float PMA = teclado.nextFloat();
            return new Camion(matricula, marca, modelo, cilindros, numeroPlazas, potenciaCC, PMA);
        }
    }

    private void existenVehiculos(ArrayList<Vehiculo> vehiculos) throws ColaVaciaException {
        if(vehiculos.isEmpty()){
            throw new ColaVaciaException("vehiculos");
        }
    }

    private void existenMecanicos(ArrayList<Mecanico> mecanicos) throws ColaVaciaException {
        if(mecanicos.isEmpty()){
            throw new ColaVaciaException("mecanicos");
        }
    }
}