import entities.Box;
import entities.Mecanico;
import entities.Taller;
import entities.menu.Menu;
import entities.menu.Opcion;
import entities.menu.opciones.*;

public class AppITV {
    public static void main(String[] args) {
        Mecanico[] mecanicos = {
                new Mecanico("Aitor Tilla", "11111111A"),
                new Mecanico("Roberto Mate", "22222222B"),
                new Mecanico("David Aomuerte ", "33333333C"),
                new Mecanico("Estela Marinera", "44444444D"),
                new Mecanico("Ana Tomía", "55555555E"),
                new Mecanico("Carmelo Cotón", "66666666F")};

        Box[] boxes = {new Box(mecanicos[0]), new Box(mecanicos[1]), new Box(mecanicos[2]), new Box(mecanicos[3]),
                new Box(mecanicos[4]), new Box(mecanicos[5])};

        Taller taller = new Taller(boxes);

        Opcion[] opcions = {
                new OpciónRecepcionarVehículo(taller), new OpcionReclamarVehiculo(taller),
                new OpcionMoverVehiculoDeFase(taller), new OpcionMoverMecanicoDeFase(taller),
                new OpcionMostrarInformacionBox(taller), new OpcionMostrarInformacionBoxes(taller),
                new OpcionesMostrarVehiculosRegistrados(taller) ,new OpcionSalir()};

        Menu menu = new Menu(opcions);
        menu.show();
    }
}