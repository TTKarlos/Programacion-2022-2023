package es.cipfpbatoi.plantillaexamen.model.utils.libro;

import es.cipfpbatoi.plantillaexamen.model.utils.Editorial;
import java.time.LocalDate;

public class Libro {
    private String titulo;
    private String autor;
    private LocalDate fechaPublicacion;
    private int idEditorial;
    private Editorial editorial;

    public Libro(String titulo, String autor, LocalDate fechaPublicacion, Editorial editorial) {
        this.titulo = titulo;
        this.autor = autor;
        this.fechaPublicacion = fechaPublicacion;
        this.editorial = editorial;
    }

    public Libro(String titulo, String autor, LocalDate fechaPublicacion, int idEditorial) {
        this.titulo = titulo;
        this.autor = autor;
        this.fechaPublicacion = fechaPublicacion;
        this.idEditorial = idEditorial;
    }

    public String getTitulo() {
        return titulo;
    }

    public Editorial getEditorial() {
        return editorial;
    }

    public LocalDate getFechaPublicacion() {
        return fechaPublicacion;
    }

    public String getAutor() {
        return autor;
    }

    public int getIdEditorial() {
        return idEditorial;
    }

    public void setEditorial(Editorial editorial) {
        this.editorial = editorial;
    }
}