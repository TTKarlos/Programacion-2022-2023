import java.util.Scanner;

public class Activitat27 {

    final static float VALOR_GASOLINA_PER_LITRE = 1.5678f;
    final static float DESCOMPE_DE_GASOLINA = 0.20f;

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("-----Benvingut a Combustibles batoi----");

        boolean sonIntentsCorectes = false;
        int numeroDeSurtidor;


        do {
            System.out.print("Quants assortidors vols activar?: ");

            if (!teclado.hasNextInt()) {
                System.out.println("Error! El tipus de dades introduït és incorrecte");
                return;
            } else {
                numeroDeSurtidor = teclado.nextInt();

                switch (numeroDeSurtidor) {
                    case 1, 2, 3, 4, 5 -> sonIntentsCorectes = false;
                    default -> {
                        System.out.println("Error! Ha d'introduir un número de assortidors correcte");
                        sonIntentsCorectes = true;
                    }
                }
            }
        } while (sonIntentsCorectes);

        double preuInicial = 0;

        double litrosTotales = 0;
        for (int j = 1; j <= numeroDeSurtidor; j++) {
            System.out.println("-------------------");
            System.out.printf("Assortidor " + j + "\nPreu carburant %.2f \n", VALOR_GASOLINA_PER_LITRE);

            do {
                System.out.print("Quants euros vols repostar? (Ex.0,0): ");
                if (!teclado.hasNextFloat()) {
                    System.out.println("Error! El tipus de dades introduït és incorrecte");
                    return;
                } else {
                    preuInicial = teclado.nextFloat();
                }

                if (preuInicial <= 0 || preuInicial > 150) {
                    sonIntentsCorectes = true;
                    System.out.println("Error! Ha d'introduir una quantitat entre 0 i 150");
                } else {
                    sonIntentsCorectes = false;
                }
            } while (sonIntentsCorectes);

            litrosTotales = preuInicial / VALOR_GASOLINA_PER_LITRE;

            float i;

            for (i = (float) 0.01; i <= preuInicial; i = (float) (i + 0.01)) {
                double x = 0.01;
                double litrosPosats = 0;
                if (x <= litrosTotales){
                    litrosPosats = litrosTotales + 0.01;
                }
                System.out.print("--> ");
                System.out.printf("%05.2f litros %05.2f€", litrosPosats, i);
                System.out.print("\r");
            }
        }

        System.out.printf("\r--> %05.2f litros %.2f€", litrosTotales, preuInicial);

        double descompte = DESCOMPE_DE_GASOLINA * preuInicial;
        double preuFinal = preuInicial - descompte;

        System.out.printf("\nTotal en €: %.2f\nTotal descompte del govern: %.2f€\nTotal a pagar: %.2f€\n", preuFinal, descompte, preuFinal);
    }
}