package es.cipfpbatoi.plantillaexamen.exceptions;

public class ErrorAnyadirException extends RuntimeException{
    public ErrorAnyadirException(String text){
        super(text);
    }
}