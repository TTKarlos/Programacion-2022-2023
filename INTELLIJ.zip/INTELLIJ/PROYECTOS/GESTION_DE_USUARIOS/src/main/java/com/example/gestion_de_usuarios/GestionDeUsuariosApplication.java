package com.example.gestion_de_usuarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionDeUsuariosApplication {
	public static void main(String[] args) {
		SpringApplication.run(GestionDeUsuariosApplication.class, args);
	}
}