import java.util.Scanner;

public class Activitat17 {

    final static int INICIO_INDICE = 0;
    final static int NUMERO_BINARIO_PEQUEÑO = 0;
    final static int NUMERO_BINARIO_GRANDE = 1;
    final static int NUMERO_ERROR = -1;

    public static void main(String[] args) {

        int[][] matriu = generaMatrizBinaria(pedirNumero());

        mostrarMatriu(matriu);
        mostrarInformacion(matriu);
    }

    public static int pedirNumero(){

        Scanner teclado = new Scanner(System.in);

        do{
            System.out.print("Introduce el tamaño de la matriz: ");

            if(!teclado.hasNextInt()){
                System.out.println("Por favor, introduce un número.");
                teclado.next();
            } else {

                int num = teclado.nextInt();

                if (num > 0){
                    return num;
                } else {
                    System.out.println("El tamaña de la matriz tiene que ser mayor a 0.");
                }
            }

        } while(true);
    }

    public static int[][] generaMatrizBinaria(int index){
        int[][] matriz = new int[index][index];

        for (int i = INICIO_INDICE; i < matriz.length; i++){
            for(int j = INICIO_INDICE; j < matriz[i].length; j++){
                matriz[i][j] = (int) (Math.random()*2+0);
            }
        }

        return matriz;
    }

    public static void mostrarMatriu(int[][] matriu){
        for(int i = INICIO_INDICE; i < matriu.length; i++){
            for(int j = INICIO_INDICE; j < matriu[i].length; j++){
                System.out.print(matriu[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void mostrarInformacion(int[][] matriz){

        mostrarIndicesFilasConMasUnos(indicesFilasConMasUnos(matriz));

        mostrarIndicesColumnasConMasUnos(indicesColumnasConMasUnos(matriz));

        int filaConTodoZeros = indicesFilasConMismoValor(matriz, NUMERO_BINARIO_PEQUEÑO);
        int filaConTodoUnos = indicesFilasConMismoValor(matriz, NUMERO_BINARIO_GRANDE);
        if(filaConTodoZeros == NUMERO_ERROR && filaConTodoUnos == NUMERO_ERROR){
            System.out.println("3. No hay filas con el mismo número");
        } else {
            if(filaConTodoZeros != NUMERO_ERROR){
                System.out.printf("3. Fila índice %d con todo 0’s\n", filaConTodoZeros);
            }
            if(filaConTodoUnos != NUMERO_ERROR){
                System.out.printf("3. Fila índice %d con todo 1’s\n", filaConTodoUnos);
            }
        }

        int columnaConTodoZeros = indicesColumnasConMismoValor(matriz, NUMERO_BINARIO_PEQUEÑO);
        int columnaConTodoUnos = indicesColumnasConMismoValor(matriz, NUMERO_BINARIO_GRANDE);
        if(columnaConTodoZeros == NUMERO_ERROR && columnaConTodoUnos == NUMERO_ERROR){
                System.out.println("4. No hay columnas con el mismo número");
        } else {
            if(columnaConTodoZeros != NUMERO_ERROR){
                System.out.printf("4. Columna índice %d con todo 0’s\n", columnaConTodoZeros);
            }
            if(columnaConTodoUnos != NUMERO_ERROR){
                System.out.printf("4. Columna índice %d con todo 1’s\n", columnaConTodoUnos);
            }
        }

        if(tieneDiagonalMayorMismoValor(matriz, NUMERO_BINARIO_PEQUEÑO)){
            System.out.printf("5. Diagonal mayor con todo %d's\n", NUMERO_BINARIO_PEQUEÑO);

        } else if(tieneDiagonalMayorMismoValor(matriz, NUMERO_BINARIO_GRANDE)){
            System.out.printf("5. Diagonal mayor con todo %d's\n", NUMERO_BINARIO_GRANDE);

        } else{
            System.out.printf("5. Diagonal mayor con mezcla de %d's y %d's\n", NUMERO_BINARIO_PEQUEÑO, NUMERO_BINARIO_GRANDE);
        }

        if(tieneSubdiagonalMismoValor(matriz, NUMERO_BINARIO_PEQUEÑO)){
            System.out.printf("6. Subdiagonal con todo %d's\n", NUMERO_BINARIO_PEQUEÑO);

        } else if(tieneSubdiagonalMismoValor(matriz, NUMERO_BINARIO_GRANDE)){
            System.out.printf("6. Subdiagonal con todo %d's\n", NUMERO_BINARIO_GRANDE);

        } else{
            System.out.printf("6. Subdiagonal con mezcla de %d's y %d's\n", NUMERO_BINARIO_PEQUEÑO, NUMERO_BINARIO_GRANDE);
        }
    }

    public static int numeroMajorEnUnaArray(int[] cadena){

        int numMaxim = cadena[INICIO_INDICE];

        for (int i = 1; i < cadena.length; i++){
            if (numMaxim < cadena[i]){
                numMaxim = cadena[i];
            }
        }

        return numMaxim;
    }

    public static int[] trobarIndexDeUnNumero(int[] cadena, int num){

        int [] cadenaIndex = new int[cadena.length];

        for (int i = INICIO_INDICE; i < cadena.length; i++){
            if(num == cadena[i]){
                cadenaIndex[i] = i + 1;
            }
        }

        return cadenaIndex;
    }

    public static int[] indicesFilasConMasUnos(int[][] matrizBinaria){

        int[] cadenaNumeros = new int[matrizBinaria.length];

        for(int i = INICIO_INDICE; i < matrizBinaria.length; i++){
            int contadorDeUnos = INICIO_INDICE;

            for(int j = INICIO_INDICE; j < matrizBinaria[i].length; j++){
                if(matrizBinaria[i][j] == NUMERO_BINARIO_GRANDE){
                    contadorDeUnos++;
                }
            }

            cadenaNumeros[i] = contadorDeUnos;
        }



        return trobarIndexDeUnNumero(cadenaNumeros, numeroMajorEnUnaArray(cadenaNumeros));
    }

    public static void mostrarIndicesFilasConMasUnos(int[] cadenaIndex){

        int contador = 0;

        for(int i = 0; i < cadenaIndex.length; i++){
            if(cadenaIndex[i] > 0){
                System.out.printf("1. Fila índice %d con mayor número de 1’s\n", cadenaIndex[i]);
            }

            contador += cadenaIndex[i];
        }

        if(contador == 0){
            System.out.println("1. La matriz sólo tiene ceros");
        }
    }

    public static int[] indicesColumnasConMasUnos(int[][] matrizBinaria){

        int[] cadenaNumeros = new int[matrizBinaria.length];

        for(int i = INICIO_INDICE; i < matrizBinaria.length; i++){
            int contadorDeUnos = INICIO_INDICE;

            for(int j = INICIO_INDICE; j < matrizBinaria[i].length; j++){
                if(matrizBinaria[j][i] == NUMERO_BINARIO_GRANDE){
                    contadorDeUnos++;
                }
            }

            cadenaNumeros[i] = contadorDeUnos;
        }

        return trobarIndexDeUnNumero(cadenaNumeros, numeroMajorEnUnaArray(cadenaNumeros));
    }

    public static void mostrarIndicesColumnasConMasUnos(int[] cadenaIndex){

        int contador = 0;

        for(int i = 0; i < cadenaIndex.length; i++){
            if(cadenaIndex[i] > 0){
                System.out.printf("2. Columna índice %d con mayor número de 1’s\n", cadenaIndex[i]);
            }

            contador += cadenaIndex[i];
        }

        if(contador == 0){
            System.out.println("2. La matriz sólo tiene ceros\n");
        }
    }

    public static int indicesFilasConMismoValor(int[][] matrizBinaria, int valorBinario){

        for(int i = INICIO_INDICE; i < matrizBinaria.length; i++){

            int indice = INICIO_INDICE;

            for(int j = INICIO_INDICE; j < matrizBinaria[i].length; j++){
                if(matrizBinaria[i][j] == valorBinario){
                    indice++;
                }
            }

            if(indice == matrizBinaria.length){
                return i + 1;
            }
        }

        return NUMERO_ERROR;
    }

    public static int indicesColumnasConMismoValor(int[][] matrizBinaria, int valorBinario){
        for(int i = INICIO_INDICE; i < matrizBinaria.length; i++){

            int indice = INICIO_INDICE;

            for(int j = INICIO_INDICE; j < matrizBinaria[i].length; j++){
                if(matrizBinaria[j][i] == valorBinario){
                    indice++;
                }
            }

            if(indice == matrizBinaria.length){
                return i + 1;
            }
        }

        return NUMERO_ERROR;
    }

    public static boolean tieneDiagonalMayorMismoValor(int[][] matrizBinaria, int valorBinario){
        int contadorRepeticiones = INICIO_INDICE;

        if(valorBinario > NUMERO_BINARIO_GRANDE || valorBinario < NUMERO_BINARIO_PEQUEÑO) {
            return false;
        }

        for (int i = INICIO_INDICE; i < matrizBinaria.length; i++) {
            for (int j = INICIO_INDICE; j < matrizBinaria.length; j++) {
                if (matrizBinaria[i][j] > NUMERO_BINARIO_GRANDE || matrizBinaria[i][j] < 0) {
                    return false;
                }

                if(i == j && matrizBinaria[i][j] == valorBinario) {
                    contadorRepeticiones++;
                }
            }
        }

        if(contadorRepeticiones == matrizBinaria.length){
            return true;
        }

        return false;
    }

    public static boolean tieneSubdiagonalMismoValor(int[][] matrizBinaria, int valorBinario){
        int contadorRepeticiones = INICIO_INDICE;

        if(valorBinario > NUMERO_BINARIO_GRANDE || valorBinario < NUMERO_BINARIO_PEQUEÑO) {
            return false;
        }

        for (int i = INICIO_INDICE; i < matrizBinaria.length; i++) {
            for (int j = matrizBinaria.length - 1; j >= INICIO_INDICE; j--) {
                if (matrizBinaria[i][j] > NUMERO_BINARIO_GRANDE || matrizBinaria[i][j] < NUMERO_BINARIO_PEQUEÑO) {
                    return false;
                }

                if(i + j == matrizBinaria.length - 1 && matrizBinaria[i][j] == valorBinario) {
                    contadorRepeticiones++;
                }
            }
        }

        if(contadorRepeticiones == matrizBinaria.length){
            return true;
        }

        return false;
    }
}