package examen;

import java.util.Scanner;

public class Activitat1 {
    public static void main(String[] args) {
        int[] numerosJugadas = crearArrayDeJugadas();
        int[] numerosPremiados = {1, 56, 67, 35635, 36763, 99999, 34523};
        int[] numerosGanados = comprobarNumeros(numerosPremiados, numerosJugadas);

        System.out.print("Numeros jugadas: ");
        mostrarArray(numerosJugadas);
        System.out.print("Numeros premiados: ");
        mostrarArray(numerosPremiados);
        System.out.print("Mis jugadas premiadas: ");
        mostrarArray(numerosGanados);
    }
    public static void mostrarArray(int[] array){
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] +", ");
        }
        System.out.println("]");
    }
    public static int pediNumero(int indice){
        Scanner teclado = new Scanner(System.in);

        do {
            System.out.printf("Introduce el numero %d: ", indice);
            if(!teclado.hasNextInt()){
                System.out.println("Introduce un numero correcto");
            } else {
                int num = teclado.nextInt();
                if(num <= 99999 && num >= 1){
                    return num;
                }
            }
        } while (true);
    }
    public static int[] comprobarNumeros(int[] numerosPremiados, int[] numerosJugadas){
        int[] numerosGanados = new int[numerosJugadas.length];
        int contador = 0;
        for (int i = 0; i < numerosJugadas.length; i++){
            for (int j = 0; j < numerosPremiados.length; j++) {
                if(esPrimo(numerosJugadas[i]) && numerosJugadas[i] == numerosPremiados[j] ){
                    numerosGanados[contador] = numerosJugadas[i];
                    contador += 1;
                }
            }
        }
        return numerosGanados;
    }
    public static boolean esPrimo(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
    public static int[] crearArrayDeJugadas(){
        int[] array = new int[10];
        for (int i = 0; i < array.length; i++) {
            array[i] = pediNumero(i);
        }
        return array;
    }
}
