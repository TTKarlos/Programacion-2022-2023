package entities.menu.opciones;

import entities.Taller;

public class OpcionMoverVehiculoDeFase extends OpcionesTaller{
    protected Taller taller;

    public OpcionMoverVehiculoDeFase(Taller taller) {
        super("Mover Vehiculo de una Fase", taller);
        this.taller = taller;
    }

    @Override
    public void ejecutar() {
        taller.moverVehiculoDeFase();
    }
}