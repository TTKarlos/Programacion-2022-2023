package entities.vehiculos.type;

import entities.vehiculos.Vehiculo;
import java.time.LocalDate;

public class Coche extends Vehiculo {
    public Coche(String matricula, String marca, String modelo, LocalDate fechaUltimaRevision, int cilindros,
                 int numeroPlazas, int potenciaDeCC) {
        super(matricula, marca, modelo, fechaUltimaRevision, cilindros, numeroPlazas, potenciaDeCC);
    }

    public Coche(String matricula, String marca, String modelo, int cilindros,
                 int numeroPlazas, int potenciaDeCC) {
        super(matricula, marca, modelo, LocalDate.of(2021, 12 , 12), cilindros, numeroPlazas, potenciaDeCC);
    }

    public double calcularPrecioRevision(){
        double precioAdicional = 0;

        if (numeroPlazas > 3) {
            precioAdicional += 1.5 * (numeroPlazas - 3);
        }

        if (potenciaDeCC > 1200) {
            precioAdicional += 10;
        }

        return precioAdicional + super.calcularPrecioRevision();
    }
}