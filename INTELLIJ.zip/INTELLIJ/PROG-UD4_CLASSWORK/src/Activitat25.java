import java.util.Scanner;

public class Activitat25 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Introdueix nom 1: ");
        String nom1 = teclado.next();
        System.out.print("Introdueix nom 2: ");
        String nom2 = teclado.next();
        System.out.print("Introdueix nom 3: ");
        String nom3 = teclado.next();

        System.out.println(concatenades(nom1, nom2, nom3));

    }

    public static String concatenades(String nom1, String nom2, String nom3){
        StringBuilder cadena = new StringBuilder("");
        cadena = cadena.append(nom1 + " " + nom2 + " " + nom3);

        StringBuilder cadenaInvertida = new StringBuilder("");

        for (int i = 0; i < cadena.length(); i++){
            StringBuilder posicio = new StringBuilder(String.valueOf(cadena.charAt(i)));
            cadenaInvertida =  posicio.append(cadenaInvertida);
        }
        return cadena + " --> " + cadenaInvertida;
    }
}