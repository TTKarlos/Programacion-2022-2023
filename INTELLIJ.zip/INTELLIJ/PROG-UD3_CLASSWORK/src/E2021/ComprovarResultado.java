package E2021;

import java.util.Scanner;

public class ComprovarResultado {
    public static final String ERROR_MSG = "Error 001";
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Introduce 2 números:");
        if (teclado.hasNextInt()){
            int num1 = teclado.nextInt();
            if (teclado.hasNextInt()){
                int num2 = teclado.nextInt();
                int num3 = (num1 > num2) ? num1 : num2;
                int res = 1;
                for (int i = num3; i > 1; i--) {
                    if (num1 % i == 0 && num2 % i == 0) {
                        res = i;
                        break;
                    }
                }
                System.out.printf("El num buscado es %d", res);
            } else {
                System.out.println(ERROR_MSG);
            }
        } else {
            System.out.println(ERROR_MSG);
        }
    }
}