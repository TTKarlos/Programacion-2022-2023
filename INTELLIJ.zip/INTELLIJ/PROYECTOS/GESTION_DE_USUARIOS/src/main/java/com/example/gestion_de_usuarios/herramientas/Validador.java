package com.example.gestion_de_usuarios.herramientas;

public class Validador {
    public final static String VALIDADOR_DATA = "^([0-2][0-9]|(3)[0-1])(\\/)(((0)[0-9])|((1)[0-2]))(\\/)\\d{4}$";
    public final static String PRODUCT_CODE_REGEXP = "[b|e|m|p|]\\d{1,10}";
    public final static String ORDER_CODE_REGEXP = "o\\d{1,10}";
    public final static String VALIDADOR_CODIGO_POSTAL = "[0-9]{5}";
    public final static String VALIDADOR_CONTRASENYA = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{5,20}$";
    public final static String VALIDADOR_TELEFONO = "[0-9]{9}";

    public static boolean isValidProductCode(String productCode) {
        return productCode.matches(PRODUCT_CODE_REGEXP);
    }

    public static boolean isValidContrasenya(String contrasenya) {
        return contrasenya.matches(VALIDADOR_CONTRASENYA);
    }

    public static boolean isValidCodigoPostal(String codigoPostal) {
        return codigoPostal.matches(VALIDADOR_CODIGO_POSTAL);
    }

    public static boolean isValidTelefono(String telefono) {
        return telefono.matches(VALIDADOR_TELEFONO);
    }

    public static boolean isValidOrderCode(String orderCode) {
        return orderCode.matches(ORDER_CODE_REGEXP);
    }
}