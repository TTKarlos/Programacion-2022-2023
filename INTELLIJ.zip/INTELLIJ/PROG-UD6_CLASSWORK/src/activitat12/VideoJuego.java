package activitat12;

public class VideoJuego {

    private String nombreJuego;
    private String genero;
    private float precio;
    private boolean multijugados;

    public VideoJuego(String nombreJuego, String genero, float precio, boolean multijugados){
        this.nombreJuego = nombreJuego;
        this.genero = genero;
        this.precio = precio;
        this.multijugados = multijugados;
    }

    public String getNombreJuego(){
        return nombreJuego;
    }

    public String getGenero(){
        return genero;
    }

    public float getPrecio(){
        return precio;
    }

    public boolean getMultijugador(){
        return multijugados;
    }

    public static void mostrarelJuegoMasCaro(VideoJuego[] listado){

        float num = listado[0].getPrecio();
        int index = 0;

        for (int i = 1; i < listado.length; i++) {
            if(num < listado[i].getPrecio()){
                num = listado[i].getPrecio();
                index = i;
            }
        }

        System.out.printf("El videojuego más caro es: \"%s\" con un precio de %.2f€\n", listado[index].nombreJuego, listado[index].precio);
    }

    public static void mostrarelJuegoMasBarato(VideoJuego[] listado){

        float num = listado[0].getPrecio();
        int index = 0;

        for (int i = 1; i < listado.length; i++) {
            if(num > listado[i].getPrecio()){
                num = listado[i].getPrecio();
                index = i;
            }
        }

        System.out.printf("El videojuego más barato es: \"%s\" con un precio de %.2f€\n", listado[index].nombreJuego, listado[index].precio);
    }

    public static void mostrarElTotalDelPrecioDeVideoJuegos(VideoJuego[] listado){

        float totalPrecio = 0;

        for (int i = 0; i < listado.length; i++){
            totalPrecio += listado[i].getPrecio();
        }

        System.out.printf("El coste total de los videojuegos es %.2f\n", totalPrecio);
    }
}