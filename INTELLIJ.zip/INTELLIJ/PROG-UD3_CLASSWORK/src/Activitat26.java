import java.util.Scanner;

public class Activitat26 {

    final static int CREMANT = 10;
    final static int CALENT = 20;
    final static int TEMPLAT = 30;
    final static String ROIG = "\u001B[31m";
    final static String BLAU = "\u001B[34m";
    final static String GROC = "\u001B[33m";
    final static String PURPURA = "\u001B[35m";
    final static String RESET_COLOR = "\u001B[0m";

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("BENVINGUT AL JOC: ENDEVINA EL NÚMERO SECRET");
        System.out.println("-------------------------------------------");

        String nivel;
        int numeroDeIntentos = 0;
        
        boolean sonIntentsCorectes;
        do {
            System.out.print("Selecciona el nivell [fàcil|intermedi|difícil]: ");
            nivel = teclado.next();

            switch (nivel) {
                case "facil", "fàcil" -> {
                    numeroDeIntentos = 10;
                    sonIntentsCorectes = false;
                }
                case "difìcil", "dificil" -> {
                    numeroDeIntentos = 5;
                    sonIntentsCorectes = false;
                }
                case "intermedi" -> {
                    numeroDeIntentos = 8;
                    sonIntentsCorectes = false;
                }
                default -> {
                    System.out.println("Error! Nivell incorrecte");
                    sonIntentsCorectes = true;
                }
            }
        } while (sonIntentsCorectes);



        int valorFormula;
        //int numeroAleatori = (int) (Math.random() * (198) - 99);
        int numeroAleatori = -45;
        int numeroIntroduit;

        for (int i = 1; i <= numeroDeIntentos; i++) {
            System.out.print("\nIntent " + i + " [-99 - 99]: ");

            if (!teclado.hasNextInt()){
                System.out.println("Error! El tipus de dades introduït és incorrecte");
                continue;
            } else numeroIntroduit = teclado.nextInt();

            if (numeroDeIntentos < -99 || numeroIntroduit > 99){
                System.out.print("Número incorrecte. Introduïx-lo de nou");
                i = i - 1;
                continue;
            }

            if (numeroAleatori > 0){
                valorFormula =  Math.abs(numeroIntroduit - numeroAleatori) ;
            } else {
                valorFormula = Math.abs(numeroAleatori - numeroIntroduit);
            }

            if (numeroIntroduit == numeroAleatori) {
                System.out.println("Enhorabona! L'has encertat\nFi");
                break;
            } else if (CREMANT > valorFormula) {
                System.out.print(ROIG + "Cremant" + RESET_COLOR);
            } else if (CALENT > valorFormula) {
                System.out.print(PURPURA + "Calent" + RESET_COLOR);
            } else if (TEMPLAT > valorFormula) {
                System.out.print(GROC + "Templat" + RESET_COLOR);
            } else {
                System.out.print(BLAU + "Fret" + RESET_COLOR);
            }
            if (i == numeroDeIntentos){
                System.out.println("\rHo senc. No l'has encertat\nFi");
            }
        }
    }
}