package activitat11;

public class Empresa {

    final static int NUM_MAXIM_EMPLEADOS = 20;
    final static int NO_HAY_EMPLEADO = -1;
    private Empleado[] empleados = new Empleado[0];

    public void anadirEmpleado(Empleado empleado){

        if(empleados.length >= NUM_MAXIM_EMPLEADOS){
            System.out.printf("Maximo puedes tener %d empleados\n", NUM_MAXIM_EMPLEADOS);
            return;
        }

        if(!esEmpleado(empleado)){
            anyadirNuevoEmpleado(empleado);
        } else {
            System.out.println("Hay un empleado con el mismo DNI");
        }
    }

    public void borrarEmpleado(String dni){
        int indiceEmpleado = buscarEmpleadoPorDni(dni);

        if(indiceEmpleado == NO_HAY_EMPLEADO){
            System.out.printf("No existe ningun empleado con el dni --> %s\n", dni);
        } else {
            empleados[indiceEmpleado] = null;
        }
    }

    public void visualizarInformacionDeEmpleadoPorDni(String dni){
        System.out.println(empleados[buscarEmpleadoPorDni(dni)]);
    }

    public void listaDeTodosLosEmpleados(){
        for (int i = 0; i < empleados.length; i++){
            System.out.println((i + 1) + ") " + empleados[i]);
        }
    }

    public void listaDeTodosLosVendedores(){
        for (int i = 0; i < empleados.length; i++){
            if(empleados[i] instanceof Vendedor && empleados[i] != null){
                System.out.println((i + 1) + ") " + empleados[i]);
            }
        }
    }

    public void listaDeTodosLosAdministrativos(){
        for (int i = 0; i < empleados.length; i++){
            if(empleados[i] instanceof Administrativo && empleados[i] != null){
                System.out.println((i + 1) + ") " + empleados[i]);
            }
        }
    }

    public float calcularElTotalDeSalariosDeLosEmpleados(){
        float contador = 0;

        for (int i = 0; i < empleados.length; i++) {
            if(empleados[i] != null){
                contador += empleados[i].getSalario();
            }
        }

        return contador;
    }

    private int buscarEmpleadoPorDni(String dni){
        for (int i = 0; i < empleados.length; i++) {
            if(empleados[i].getDni().equalsIgnoreCase(dni)){
                return i;
            }
        }

        return NO_HAY_EMPLEADO;
    }

    private boolean esEmpleado(Empleado empleado){
        for (int i = 0; i < empleados.length; i++) {
            if(empleados[i].equals(empleado)){
                return true;
            }
        }

        return false;
    }

    private void anyadirNuevoEmpleado(Empleado empleado){
        Empleado[] empleadosNuevos = new Empleado[empleados.length + 1];
        for (int i = 0; i < empleados.length; i++) {
            empleadosNuevos[i] = empleados[i];
        }
        empleadosNuevos[empleadosNuevos.length - 1] = empleado;
        this.empleados = empleadosNuevos;
    }
}