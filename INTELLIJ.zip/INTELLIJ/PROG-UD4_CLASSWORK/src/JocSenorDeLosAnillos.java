import java.util.Scanner;

public class JocSenorDeLosAnillos {

    final static String NOM_GANDALF = "\uD83E\uDDD9"+ "GANDALF";
    final static String NOM_FRODO = "\uD83C\uDFC7"+ "FRODO";
    final static String NOM_SAM = "\uD83E\uDDD4"+ "SAM";
    final static String NOM_HOBBITS = "\uD83E\uDDDD"+ "HOBBITS";
    final static String NOM_MERRY = "\uD83D\uDC71"+"MERRY";
    final static String NOM_PIPPIN = "\uD83E\uDDD1"+"PIPPIN";
    final static String NOM_GOLLUM = "\uD83D\uDC7D"+"GOLLUM";
    final static String NOM_SAURON = "\uD83E\uDD34"+"SAURON";

    final static String ESPAI_EN_BLANC = " ";

    public static void main(String[] args) {

        System.out.print(nivel1());
/**
        if (!inici()){
            fi();
        } else if (!nivel1()){
            perdre();
        } else if (!nivel2()){
            perdre();
        }else if (!nivel3()){
            perdre();
        } else if(!nivel4()){
            perdre();
        } else if (!nivel5()){
            perdre();
        } else {
            guanyar();
        }
**/
    }

    public static boolean inici (){

        Scanner teclado = new Scanner(System.in);

        System.out.print("BIENVENIDOS A LA AVENTURA DEL SEÑOR DEL ANILLOS\n" +
                "================================================\n" +
                "Era un día tranquilo en Hobbiton. Todos los hobbits preparaban la\n" +
                "fiesta aniversario de la destrucción del anillo que liberó a toda la\n" +
                "Tierra Media del reinado negro de Sauron.\n" +
                "Nuestro héroe Frodo, junto a sus amigos, se encargaban de decorar\n" +
                "la cueva del ya anciano Bilbo Bolsón.\n" +
                "De repente, una silueta conocida se dejó ver por la ventana….\n" +
                "¡Oh no! ¡Gandalf! Siempre que aparece ese viejo mago, nunca trae\n" +
                "buenas noticias….\n" +
                "Éste pidió reunirse urgentemente con Frodo y sus compañeros Sam,\n" +
                "Merry y Pippin. Tras su charla, los hobbits confirmaron los peores\n" +
                "augurios… Les contó que el anillo no había sido destruido, que no\n" +
                "Pàgina 3\n" +
                "sabe cómo, pero Gollum lo poseía de nuevo en su cueva y lo\n" +
                "guardaba para que nadie se lo quitase.\n" +
                NOM_GANDALF + ": Por favor hobbits, debéis encargaros de encontrarlo y\n" +
                "destruirlo de nuevo en el Monte del Destino de Mordor pero esta vez\n" +
                "no podéis fallar.\n" +
                "¿Quieres que Frodo y sus compañeros acepten el reto de Gandalf y\n" +
                "vayan a buscar el anillo para destruirlo? (SÍ / NO): ");

        String entra = teclado.next();
        boolean entra1;

        if (entra.equalsIgnoreCase("si")){
            entra1 = true;
        } else {
            entra1 = false;
        }
        return entra1;
    }

    public static void perdre(){
        System.out.println("Desgraciadamente, la aventura ha acabado y el mundo vuelve a" +
                " ser un lugar inseguro. ¡Una lástima!");
    }

    public static void guanyar(){
        System.out.println("¡¡Enhorabuena hobbits!! Habéis conseguido destruir el anillo mágico.\n" +
                "El mundo vuelve a respirar tranquilo. ¡Hasta otra amigos!");
    }

    public static void fi(){
        System.out.println("Desgraciadamente, la aventura ha acabado y el mundo vuelve" +
                " a ser un lugar inseguro. ¡Una lástima!");
    }

    public static boolean nivel1(){

        Scanner teclado = new Scanner(System.in);

        System.out.println(NOM_FRODO + ": ¡Muy bien! Vamos a buscar a ese granuja de Gollum. Le\nrobaremos el anillo" +
                " y esta vez lo destruiremos. No fue fácil entonces,\nni tampoco ahora, pero  lo conseguiremos, " +
                "¿verdad, chicos? \n" +
                NOM_SAM+ ": ¡Sí! ¡Vamos! Pero… debemos preparar todo lo necesario para\n" +
                "afrontar de nuevo los diferentes desafíos que se nos van a proponer.\n" +
                "Botas, guantes, agua para el camino, y p….. ¡No hay pan señor\nFrodo!.\n" +
                NOM_FRODO +": Los sacos de trigo no llegan hasta la semana que viene y nos\nhace" +
                " falta pan para salir mañana de manera urgente.\n" +
                NOM_GANDALF +": Os propongo un juego. Si lo ganáis os diré mi conjuro\npanadero " +
                "con el que podréis crear todos los" +
                " panes que queráis.\n¿Sabríais adivinar cuántas parejas de vocales tiene el " +
                "siguiente\nhechizo élfico?\n");

        StringBuilder cadenaAleatoria = new StringBuilder(cadenaAleatoria());

        int numeroAleatori = (int)(Math.random()*2+1);
        for (int i = 1; i < numeroAleatori + 3 ; i++) {
            int numeroAleatori2 = (int)(Math.random()*20+0);
            cadenaAleatoria.replace(numeroAleatori2, numeroAleatori2, ESPAI_EN_BLANC);
        }

        boolean hasGuanyat = false;

        int contadorParelles = contadorDeVocals(cadenaAleatoria);

        System.out.printf("Di quantes parelles de vocals te \"%s\": ", cadenaAleatoria);
        int numIntroduit = teclado.nextInt();

        if (numIntroduit == contadorParelles){
            hasGuanyat = true;
        }

        return hasGuanyat;
    }

    public static int contadorDeVocals(StringBuilder cadenaAleatoria) {
        int contadorParelles = 0;
        int contador = 0;

        for (int i = 0; i < cadenaAleatoria.length(); i++) {

            String posicio = String.valueOf(cadenaAleatoria.charAt(i));

            if (posicio.equalsIgnoreCase("a") || posicio.equalsIgnoreCase("e") ||
                    posicio.equalsIgnoreCase("i") || posicio.equalsIgnoreCase("o") ||
                    posicio.equalsIgnoreCase("u")) {
                contador++;
            } else {
                contador = 0;
            }

            if (contador >= 2) {
                contadorParelles++;
                contador--;
            }
        }

        return contadorParelles;
    }

    public static StringBuilder cadenaAleatoria(){
        String alfabet = "abcdefghijklmnopqrstuvwxyz";
        StringBuilder cadenaAleatoria = new StringBuilder();

        for (int i=0; i < 20; i++){
            int numeroAleatori = (int)(Math.random()*25+0);
            cadenaAleatoria.append(alfabet.charAt(numeroAleatori));
        }

        return cadenaAleatoria;
    }

    public static boolean nivel2(){

        Scanner teclado = new Scanner(System.in);
        System.out.println(NOM_GANDALF +": Sois unos cracks de las letras. Aquí va el conjuro:\n" +
                "Abracadabra, abracadero, ¡barras de pan ricas de panadero!\nAhora ya " +
                "tenéis todo lo necesario para el viaje. ¡Buena suerte\nhobbits!\n"+
                NOM_HOBBITS+": ¡Sí! ¡Vamos amigos!\n"+"Ya de camino a las Montañas Nubladas " +
                "donde se encuentra la\ncaverna de Gollum, los hobbits debían atravesar " +
                "las minas de Moria,\npero…\n"+NOM_MERRY+": ¡Oh, dios mío! La puerta está cerrada, no podemos pasar.\n"
                +NOM_PIPPIN+": Fijaos, aquí en la puerta pone.. 'Para poder entrar, la mezcla\n" +
                "sagrada de estas dos frases deberas realizar. Si no lo consigues,\nnunca podrás pasar.\n" +
                NOM_SAM+": ¿Y qué demonios es la mezcla sagrada?\n" +
                NOM_FRODO+": ¡Ay Sam…! ¿No te acuerdas? Recuerda aquello que\naprendimos en" +
                " Rivendell. Una mezcla sagrada equivale al primero\ncon el último, el segundo" +
                " con el penúltimo, y así hasta el final.\n" +
                "Indica cuál es la mezcla sagrada de estás dos cadenas de caracteres:\n ");

        boolean hasGuanyat = false;
        StringBuilder cadenaAleatoria1 = new StringBuilder(paraulaDe5LetrasAleatoria());
        StringBuilder cadenaAleatoria2 = new StringBuilder(paraulaDe5LetrasAleatoria());
        StringBuilder cadenaFinal = new StringBuilder();

        for (int i = 0; i < 5; i++){
            cadenaFinal.append(cadenaAleatoria1.charAt(i));
            int posicio = 4 - i;
            cadenaFinal.append(cadenaAleatoria2.charAt(posicio));
        }

        System.out.println(cadenaFinal);

        System.out.printf("La mescla sagrada de les cadenes de caràcters %s i %s correspon a la cadena:" +
                " ", cadenaAleatoria1, cadenaAleatoria2);
        String nomIntroduit = teclado.next();

        if (cadenaFinal.compareTo(new StringBuilder(nomIntroduit)) == 0){
            hasGuanyat = true;
        }
        System.out.println(hasGuanyat);
        return hasGuanyat;
    }

    public static StringBuilder paraulaDe5LetrasAleatoria (){

        StringBuilder cadenAleatoria = new StringBuilder();

        for (int i = 1; i <= 5; i++){
            String alfabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            int numeroAleatori = (int)(Math.random()*65+0);
            cadenAleatoria.append(alfabet.charAt(numeroAleatori));
        }

        return cadenAleatoria;
    }

    public static boolean nivel3(){

        Scanner teclado = new Scanner(System.in);
        System.out.printf(NOM_SAM +": Las puertas se abren señor Frodo. ¡Seguimos con nuestra\nmisión!\n" +
                "Los hobbits atravesaron las minas dejando atrás una manada de\nOrcos malolientes que consiguieron" +
                " esquivar gracias a la capa\nmágica de Frodo. Una vez fuera, los hobbits se dirigieron a la" +
                " caverna\nde Gollum que no tardaron en encontrar.\n" +
                NOM_MERRY +": Por fin te encontramos Gollum! Devuélveme el anillo. Lo\ndebemos destruir por el" +
                " bien de toda Tierra Media.\n" +
                NOM_GOLLUM +": ¡Malditos seáis hobbits!. Es mi tessssoro. Lo he guardado en\neste cofre y para" +
                " poder abrirlo debéis responder resolver el enigma\nque aparece en su display. ¡Nunca lo podréis" +
                " resolver! . Podéis\nintentarlo, pero no lo vais a conseguir… ¡jamás!\n" +
                NOM_FRODO +": Veamos qué pone en este dichoso display. Chicos, aquí\naparecen y desaparecen " +
                "palabras. y luego me lanza una pregunta.\nVaya, qué complicado….\n" +
                "Memoriza los 5 caracteres que correspondan a los índices\nmostrados. Debes escribir todos juntos:\n");

        StringBuilder cadenaAleatoria1 = cadenaAleatoriaAmbSimbols();
        StringBuilder cadenaAleatoria2 = cadenaAleatoriaAmbSimbols();
        StringBuilder cadenaAleatoria3 = cadenaAleatoriaAmbSimbols();
        StringBuilder cadenaAleatoria4 = cadenaAleatoriaAmbSimbols();
        StringBuilder cadenaAleatoria5 = cadenaAleatoriaAmbSimbols();

        int index1 = (int) (Math.random()*4+0);
        int index2 = (int) (Math.random()*4+0);
        int index3 = (int) (Math.random()*4+0);
        int index4 = (int) (Math.random()*4+0);
        int index5 = (int) (Math.random()*4+0);

        System.out.println("Memoriza los 5 caracteres que correspondan a los índices mostrados.");

        salirPorPantallaCada2Segundos(cadenaAleatoria1, cadenaAleatoria2, cadenaAleatoria3, cadenaAleatoria4,
                cadenaAleatoria5, index1, index2, index3, index4, index5);

        String cadenaFinal = String.valueOf(cadenaAleatoria1.charAt(index1)) +
                String.valueOf(cadenaAleatoria2.charAt(index2)) + String.valueOf(cadenaAleatoria3.charAt(index3)) +
                String.valueOf(cadenaAleatoria4.charAt(index4)) +
                String.valueOf(cadenaAleatoria5.charAt(index5));

        System.out.print(cadenaFinal + "\nDebes escribir todos juntos: ");
        String cadenaIntroduida = teclado.next();

        return cadenaIntroduida.equals(cadenaFinal);
    }

    public static void salirPorPantallaCada2Segundos( StringBuilder cadenaAleatoria1, StringBuilder cadenaAleatoria2,
                                                  StringBuilder cadenaAleatoria3,StringBuilder cadenaAleatoria4,
                                                  StringBuilder cadenaAleatoria5, int index1, int index2, int index3,
                                                  int index4, int index5){

        System.out.printf("Cadena 1 --> %s (%d)", cadenaAleatoria1, index1);
        delay(2000);
        System.out.print("\r");
        System.out.printf("Cadena 2 --> %s (%d)", cadenaAleatoria2, index2);
        delay(2000);
        System.out.print("\r");
        System.out.printf("Cadena 3 --> %s (%d)", cadenaAleatoria3, index3);
        delay(2000);
        System.out.print("\r");
        System.out.printf("Cadena 4 --> %s (%d)", cadenaAleatoria4, index4);
        delay(2000);
        System.out.print("\r");
        System.out.printf("Cadena 5 --> %s (%d)", cadenaAleatoria5, index5);
        delay(2000);
        System.out.print("\r");
    }

    public static void delay(long milis){
        try {
            Thread.sleep(milis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static StringBuilder cadenaAleatoriaAmbSimbols() {

        StringBuilder cadena = new StringBuilder("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ$!€&<>¡%");
        StringBuilder cadenaAleatoria = new StringBuilder();

        for (int i = 0; i < 5; i++) {
            cadenaAleatoria.append(cadena.charAt((int) (Math.random() * 59 + 1)));
        }

        return cadenaAleatoria;
    }

    public static boolean nivel4(){
        System.out.printf(NOM_FRODO +" :  ¡¡Yeehaaa!! ¡Hemos abierto el cofre! El anillo ya está en\nnuestro poder." +
                " Ahora debemos llevarlo a la montaña de Sauron para\ndestruirlo y esta vez para siempre.\n" +
                NOM_SAM +" : Démonos prisa. El tiempo se acaba. Vayamos a Mordor a\ndestruirlo.\n" +
                "Los hobbits se presentaron allí raudos y veloces, pero se encontraron\nde nuevo ante las peligrosas" +
                " y enigmáticas puertas de Mordor.\n" +
                NOM_PIPPIN + " : ¡Wow! No las recordaba así.\n" +
                NOM_MERRY + " : Y yo no las recordaba cerradas.\n" +
                NOM_FRODO +" : No os preocupéis. Ya logré atravesarlas una vez, y esta vez\nno será menos. " +
                "Respondamos a esta pregunta que aparece en la\npuerta y la puerta se abrirá de par en par.\n" +
                "¿Cuántas veces se repite la cadena de tamaño 2 en las tres cadenas\ngeneradas?\n");

        StringBuilder cadena1 = cadenaAleatoriaDeVocals5();
        StringBuilder cadena2 = cadenaAleatoriaDeVocals5();
        StringBuilder cadena3 = cadenaAleatoriaDeVocals5();
        StringBuilder cadenaComprovar = cadenaAleatoriaDeVocals2();

        int numVocals1 = contadorDeVocals2(cadena1, cadenaComprovar);
        int numVocals2 = contadorDeVocals2(cadena2, cadenaComprovar);
        int numVocals3 = contadorDeVocals2(cadena3, cadenaComprovar);

        System.out.printf("Cuantas veces coicide la cadena \"%s\" con la cadena \"%s\": ",cadenaComprovar, cadena1);
        int numIntroduirt1 = introduirSolesVocals();
        System.out.printf("Cuantas veces coicide la cadena \"%s\" con la cadena \"%s\": ",cadenaComprovar, cadena2);
        int numIntroduirt2 = introduirSolesVocals();
        System.out.printf("Cuantas veces coicide la cadena \"%s\" con la cadena \"%s\": ",cadenaComprovar, cadena3);
        int numIntroduirt3 = introduirSolesVocals();
        
        StringBuilder cadenaComprovarInvertit = new StringBuilder(cadenaComprovar.substring(1) +
                cadenaComprovar.substring(0,1));

        int numVocalsInvertit1 = contadorDeVocals2(cadena1, cadenaComprovarInvertit);
        int numVocalsInvertit2 = contadorDeVocals2(cadena2, cadenaComprovarInvertit);
        int numVocalsInvertit3 = contadorDeVocals2(cadena3, cadenaComprovarInvertit);

        System.out.printf("\nCuantas veces coicide la cadena \"%s\" con la cadena \"%s\": ",
                cadenaComprovarInvertit, cadena1);
        int numIntroduirtInvertit1 = introduirSolesVocals();
        System.out.printf("Cuantas veces coicide la cadena \"%s\" con la cadena \"%s\": ",
                cadenaComprovarInvertit, cadena2);
        int numIntroduirtInvertit2 = introduirSolesVocals();
        System.out.printf("Cuantas veces coicide la cadena \"%s\" con la cadena \"%s\": ",
                cadenaComprovarInvertit, cadena3);
        int numIntroduirtInvertit3 = introduirSolesVocals();

        if (numVocals1 != numIntroduirt1){
            return false;
        } else if (numVocals2 != numIntroduirt2){
            return false;
        } else if(numVocals3 != numIntroduirt3){
            return false;
        } else if (numVocalsInvertit1 != numIntroduirtInvertit1){
            return false;
        } else if (numVocalsInvertit2 != numIntroduirtInvertit2){
            return false;
        } else if(numVocalsInvertit3 != numIntroduirtInvertit3){
            return false;
        }

        return true;cadenaComrpovar
    }

    public static int contadorDeVocals2(StringBuilder cadena, StringBuilder cadenaComrpovar){
        int contador = 0;

        for (int i = 0; i < cadena.length() - 1; i++){
            String posicio = cadena.substring(i, i+2);

             if(posicio.equalsIgnoreCase(String.valueOf(cadenaComrpovar))){
                 contador++;
             }
        }

        return contador;
    }

    public static StringBuilder cadenaAleatoriaDeVocals5(){

        String cadena = "aeiou";
        StringBuilder cadenaAleatoria = new StringBuilder();

        for (int i=0; i < 5; i++){
            int numeroAleatori = (int)(Math.random()*5+0);
            cadenaAleatoria.append(cadena.charAt(numeroAleatori));
        }

        return cadenaAleatoria;
    }

    public static StringBuilder cadenaAleatoriaDeVocals2(){

        String cadena = "aeiou";
        StringBuilder cadenaAleatoria = new StringBuilder();

        for (int i=0; i < 2; i++){
            int numeroAleatori = (int)(Math.random()*5+0);
            cadenaAleatoria.append(cadena.charAt(numeroAleatori));
        }

        return cadenaAleatoria;
    }

    public static int introduirSolesVocals(){

        Scanner teclado = new Scanner(System.in);

        boolean esCorrecte = false;
        int nom = 0;

        do{
            if (esCorrecte){
                System.out.print("Introdueix sols numeros -->");
            }

            if (!teclado.hasNextInt()){
                esCorrecte = true;
            } else {
                nom = teclado.nextInt();
                esCorrecte =false;
            }

        } while (esCorrecte);

        return nom;
    }

    public static boolean nivel5(){

        Scanner teclado = new Scanner(System.in);

        System.out.printf(NOM_SAM + ": ¡Bravo señor Frodo!. Vayamos al precipicio de Mordor para\ndestruir este " +
                "maldito anillo de una vez.\n" +
                "Nuestros amigos estaban a punto de conseguir su objetivo, cuando\nde repente, vieron que el aura" +
                " con el ojo de Sauron gobernaba el\nacceso al precipicio de lava de Mordor. El ojo empezó" +
                " a\ndeslumbrarles. Casi no podían mirar. Sólo podían oír su voz que les\ndecía:\n" +
                NOM_SAURON +": Malvados hobbits… no pensaba veros de nuevo por aquí.\nVeo que transportais" +
                " el anillo que yo forjé para gobernarlos a todos.\nYa lo logré salvar de este precipicio" +
                " de lava aquella vez pero veo que\nno lo he logrado. Sabía que no podía confiar en ese" +
                " apestoso de\nGollum. Sólo os dejaré pasar por delante de mí si respondéis a esta\npregunta:\n" +
                "Cifra las dos cadenas mostradas a continuación:\n");

        StringBuilder cadenaAleatoria1 = cadenaEntre6I12caracters();
        StringBuilder cadenaAleatoria2 = cadenaEntre6I12caracters();

        StringBuilder cadenaAleatoriaGenerada1 = cambiarCadenaNivel5(new StringBuilder(cadenaAleatoria1));
        StringBuilder cadenaAleatoriaGenerada2 = cambiarCadenaNivel5(new StringBuilder(cadenaAleatoria2));

        System.out.printf("\nCadena 1: %s\nCadena 2: %s\n\n",cadenaAleatoria1, cadenaAleatoria2);

        System.out.print("Cadena 1: ");
        String cadenaintroducida1 = teclado.next();
        System.out.print("Cadena 2: ");
        String cadenaintroducida2 = teclado.next();

        if (cadenaintroducida1.compareTo(String.valueOf(cadenaAleatoriaGenerada1)) != 0){
            return false;
        } else if (cadenaintroducida2.compareTo(String.valueOf(cadenaAleatoriaGenerada2)) != 0){
            return false;
        }
        return true;
    }

    public static StringBuilder cambiarCadenaNivel5(StringBuilder cadena){

        String cadenaAlfabet = "/0123456789:'abcdefghijklmnopqrstuvwxyz{@ABCDEFGHIJKLMNOPQRSTUVWXYZ[";
        StringBuilder cadenaGenerada = new StringBuilder();

        for (int i = 0; i < cadena.length(); i++){
            String posicio = String.valueOf(cadena.charAt(i));
            if (i % 2 != 0){
                cadenaGenerada.append(cadenaAlfabet.charAt(cadenaAlfabet.indexOf(posicio) - 1));
            } else {
                cadenaGenerada.append(cadenaAlfabet.charAt(cadenaAlfabet.indexOf(posicio) + 1));
            }
        }

        return cadenaGenerada;
    }

        public static StringBuilder cadenaEntre6I12caracters(){

        StringBuilder cadena = new StringBuilder();
        int numAleatori = (int) (Math.random()*4+1);

        for (int i = 1; i <= 6 + numAleatori; i++){
            int numAleatori2 = (int) (Math.random()*35+0);
            String cadenaAlfabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            cadena.append(cadenaAlfabet.charAt(numAleatori2));
        }

        return cadena;
    }
}