package activitat9;

import activitat9.types.Gat;
import activitat9.types.Gos;

public class Persona {
    private String nombre;
    private String apellidos;

    public Persona(String nombre, String apellidos){
        this.nombre = nombre;
        this.apellidos = apellidos;
    }

    public void saludar(){
        System.out.printf("Hola, soy %s %s\n", nombre, apellidos);
    }

    private void interacionInicial(Animal animal){
        if(animal instanceof Gos){
            System.out.println("Hola Gos");
        } else if(animal instanceof Gat){
            System.out.println("Hola Gat");
        } else {
            System.out.println("Hola mascotita");
        }
    }
}
