public class Activitat6 {
    public static void main(String[] args) {

        int[] array = crearArray();

        visualitzarArray(array);
        cercarZero(array);
        intercanvia(array);

    }

    public static int[] crearArray(){

        int [] array= new int[10];

        for (int i = 0; i < array.length; i++){
            int numRandom = (int) (Math.random()*50+0);
            array[i] = numRandom;
        }
        return array;
    }

    public static void visualitzarArray(int[] vector){

        for(int i = 0; i < vector.length; i++){
            System.out.printf("Posicio %s: %s\n", i, vector[i]);
        }
    }

    public static int cercarZero(int[] vector){
        for(int i = 0; i < vector.length; i++){

            if(vector[i] == 0){
                return i;
            }
        }
        return -1;
    }

    public static void intercanvia(int[] vector){

        int primeraPosicio = vector[0];
        int ultimaPosicio = vector[vector.length - 1];

        if(vector.length >= 2){
            vector[vector.length - 1] = primeraPosicio;
            vector[0] = ultimaPosicio;
        }

        visualitzarArray(vector);
    }
}