import java.util.Scanner;

public class Activitat28 {

    static final int OPCION_SALUDAR = 1;
    static final int OPCION_COMER = 2;
    static final int OPCION_HABLAR = 3;
    static final int OPCION_SALIR = 4;

    public static void main(String[] args) {

        boolean salir;

        do {
            mostrarOpciones();

            int opcionSeleccionada = pedirOpcion();

            salir = comprobarSalir(opcionSeleccionada);

            opcionSeleccionada(opcionSeleccionada);

        } while (salir);
    }

    public static void opcionSeleccionada(int opcionSeleccionada){
        boolean salir = false;

        switch (opcionSeleccionada) {
            case OPCION_SALUDAR:
                System.out.println("Hola a todos");
                break;
            case OPCION_COMER:
                System.out.println("Comiendo");
                break;
            case OPCION_HABLAR:
                System.out.println("Bla bla bla");
                break;
            case OPCION_SALIR:
                System.out.println("Adiós");
                return;
            default:
                System.out.println("La opción seleccionada no es válida");
        }
    }

    public static boolean comprobarSalir(int opcionSeleccionada){

        boolean salir = true;

        if(opcionSeleccionada == 4){
            salir = false;
        }
        return salir;
    }

    public static void mostrarOpciones(){
        System.out.printf("%d. Saludar %n", OPCION_SALUDAR);
        System.out.printf("%d. Comer %n", OPCION_COMER);
        System.out.printf("%d. Hablar %n", OPCION_HABLAR);
        System.out.printf("%d. Salir %n", OPCION_SALIR);
    }

    public static int pedirOpcion(){

        Scanner teclado = new Scanner(System.in);

        return teclado.nextInt();
    }
}