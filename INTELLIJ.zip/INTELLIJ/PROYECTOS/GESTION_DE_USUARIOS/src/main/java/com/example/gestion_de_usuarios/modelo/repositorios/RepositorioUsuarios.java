package com.example.gestion_de_usuarios.modelo.repositorios;

import com.example.gestion_de_usuarios.modelo.entidades.Usuario;
import java.util.ArrayList;

public class RepositorioUsuarios {
    private ArrayList<Usuario> listaUsuarios;

    public RepositorioUsuarios() {
        listaUsuarios = anyadirUsuariosPorDefecto();
    }

    public void add(Usuario usuario) {
        listaUsuarios.add(usuario);
    }

    public ArrayList<Usuario> getListaUsuarios() {
        return listaUsuarios;
    }

    public Usuario buscarUsuarioPorNombre(String nombre){
        Usuario usuarioEncontrado = new Usuario(nombre);
        for (int i = 0; i < listaUsuarios.size(); i++) {
            if (listaUsuarios.get(i).equals(usuarioEncontrado)) {
                return listaUsuarios.get(i);
            }
        }

        return null;
    }

    public void actualizarUsuario(Usuario usuario) {
        for (int i = 0; i < listaUsuarios.size(); i++) {
            if(usuario.equals(listaUsuarios.get(i))){
                listaUsuarios.set(i, usuario);
            }
        }
    }

    public void eliminarUsuario(Usuario usuario) {
        listaUsuarios.remove(usuario);
    }

    public ArrayList<Usuario> buscarUsuariosPorNombre(String nombre) {
        ArrayList<Usuario> usuariosEncontrados = new ArrayList<>();
        for (Usuario usuario : listaUsuarios) {
            if (usuario.equals(new Usuario(nombre))) {
                usuariosEncontrados.add(usuario);
            }
        }

        return usuariosEncontrados;
    }

    private ArrayList<Usuario> anyadirUsuariosPorDefecto(){
        ArrayList<Usuario> listaUsuarios = new ArrayList<>();
        listaUsuarios.add(new Usuario("Andreu", " Puchades", "21505410L", "andreu@gmail.com", "03804", "658963254","2003-11-21", "123456"));
        listaUsuarios.add(new Usuario("Doha", " Aliat", "21512430L", "doha@gmail.com", "03804", "658914554", "1999-01-21", "123456"));

        return listaUsuarios;
    }

    public void remove(String codigo){
        Usuario usuarioParaBorrar = new Usuario(codigo);
        for (int i = 0; i < listaUsuarios.size(); i++) {
            if(listaUsuarios.get(i).equals(usuarioParaBorrar)){
                listaUsuarios.remove(i);
                return;
            }
        }
    }
}