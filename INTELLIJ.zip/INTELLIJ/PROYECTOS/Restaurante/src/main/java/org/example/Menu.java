package org.example;
import java.util.Scanner;

public class Menu {
    final static String TEXTO_LINEAS_SEPARACION = "==============================================";
    final static String TEXTO_ERROR_OPCION = "¡Error! Elige una opcion correcta";
    final static int NUM_PRIMERA_OPCION = 1;
    final static int NUM_OPCION_SALIR = 5;
    private Camarero camarero;

    public Menu(Camarero camarero){
        this.camarero = camarero;
    }

    public void show(){
        do {
            int numElegido = darOpcion();

            switch (numElegido) {
                case 1 -> camarero.anyadirPedido();
                case 2 -> camarero.mostrarListaPedidos();
                case 3 -> camarero.visualizarOrden();
                case 4 -> camarero.servirUnPedido();
                case 5 -> {
                    System.out.println(GestorIO.TEXTO_SALIR);
                    return;
                }
            }
        } while (true);
    }

    private int darOpcion(){
        Scanner teclado = new Scanner(System.in);

        System.out.println(TEXTO_LINEAS_SEPARACION);
        GestorIO.mostrarTextoEnAzul("=== Bienvenido al bar de los 20 Montaditos ===\n");
        System.out.println(TEXTO_LINEAS_SEPARACION);

        System.out.printf(GestorIO.TEXTO_MENU);

        do{
            GestorIO.mostrarTextoEnAzul(String.format("Elige opcion [1-%d]: ", NUM_OPCION_SALIR));

            if(teclado.hasNextInt()){
                int num = teclado.nextInt();

                if(num >= NUM_PRIMERA_OPCION && num <= NUM_OPCION_SALIR){
                    return num;
                } else {
                    GestorIO.mostrarTextoEnError(TEXTO_ERROR_OPCION);
                }
            } else {
                GestorIO.mostrarTextoEnError(TEXTO_ERROR_OPCION);
                teclado.next();
            }
        } while (true);
    }
}