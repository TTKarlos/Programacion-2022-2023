package utils;

import entities.vehiculos.type.Camion;
import entities.vehiculos.type.Coche;
import entities.vehiculos.type.Furgoneta;
import entities.vehiculos.type.MicroBus;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class GestioIO {
    public final static String COLOR_AZUL = "\u001B[34m";
    public final static String RESET_COLOR = "\u001B[0m";
    public final static String COLOR_VERDE = "\u001B[32m";
    public final static String COLOR_ROJO = "\u001B[31m";

    public static LocalDate pedirFecha(String texto) {
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        LocalDate fecha;
        do {
            System.out.print(texto + ": ");
            String input = scanner.nextLine();
            try {
                fecha = LocalDate.parse(input, formatter);

                if(fecha.isBefore(LocalDate.now())){
                    return fecha;
                }
            } catch (Exception e) {
                System.out.println("Error! Introduce la fecha en formato español.");
            }
        } while (true);
    }

    public static int devolverNumeroEntreXyY(String texto, int index, int ultimo){
        Scanner teclado = new Scanner(System.in);

        do {
            GestioIO.mostrarTextoEnAzul(String.format("%s[%d-%d]: ", texto, index, ultimo));


            if(!teclado.hasNextInt()){
                GestioIO.mostrarTextoEnError("Error! Introduce un numero valido entre " + index + " y " + ultimo);
                teclado.next();
            } else {
                int num = teclado.nextInt();

                if(num >= index && num <= ultimo){
                    return num;
                } else {
                    GestioIO.mostrarTextoEnError("Error! Introduce un numero valido entre " + index + " y " + ultimo);
                }
            }
        } while (true);
    }

    public static boolean eligeSiONo(String texto){
        Scanner teclado = new Scanner(System.in);

        do{
            GestioIO.mostrarTextoEnAzul(String.format("%s[Si-No]: ", texto));
            String eleccion = teclado.next();

            if(eleccion.equalsIgnoreCase("no")){
                return false;
            } else if (eleccion.equalsIgnoreCase("si")) {
                return true;
            } else {
                GestioIO.mostrarTextoEnError("Error! Elige entre 'Si' o 'No'");
            }
        } while (true);
    }

    public static Class devolverTipoVehiculo(){
        do{
            GestioIO.mostrarTextoEnAzul("Elige la opcion de Vehiculo que quieres:\n");
            System.out.println(
                    GestioIO.COLOR_ROJO + "1." + GestioIO.RESET_COLOR + "Coche\n" +
                    GestioIO.COLOR_ROJO + "2." + GestioIO.RESET_COLOR + "MicroBus\n" +
                    GestioIO.COLOR_ROJO + "3." + GestioIO.RESET_COLOR + "Furgoneta\n" +
                    GestioIO.COLOR_ROJO + "4." + GestioIO.RESET_COLOR + "Camion"
            );
            switch (devolverNumeroEntreXyY("Elige una opcion ", 1, 4)){
                case 1 -> {
                    return Coche.class;
                }
                case 2 -> {
                    return MicroBus.class;
                }

                case 3 -> {
                    return Furgoneta.class;
                }

                case 4 -> {
                    return Camion.class;
                }
            }
        } while (true);
    }

    public static void mostrarTextoEnError(String texto){
        System.out.println(COLOR_ROJO + texto + RESET_COLOR);
    }

    public static void mostrarTextoEnVerde(String texto){
        System.out.println(COLOR_VERDE + texto + RESET_COLOR);
    }

    public static void mostrarTextoEnAzul(String texto){
        System.out.print(COLOR_AZUL + texto + RESET_COLOR);
    }
}