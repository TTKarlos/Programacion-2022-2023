package activitat8;

import activitat8.enums.Comida;
import activitat8.enums.Tamany;

public abstract class Animal {
    private boolean vacunado;
    private Comida comida;
    private int hambre;
    private Tamany tamany;
    private String localizacion;

    public Animal(boolean vacunado, Comida comida, int hambre, Tamany tamany, String localizacion){
        this.vacunado = vacunado;
        this.comida = comida;
        this.hambre = hambre;
        this.tamany = tamany;
        this.localizacion = localizacion;
    }
    public void comer() {
        switch (comida.toString()){
            case "herbivoro" -> this.hambre -= 2;
            case "carnivoro" -> this.hambre -= 1;
            case "omnivoro" -> this.hambre -= 3;
        }
    }

    public void vacunar(){
        this.vacunado = true;
    }

    @Override
    public String toString() {
        return "Tamaño = " + tamany + ", Nivel de hambre = "+ hambre + ", vacunado = "+ vacunado + "  vive en = " + localizacion;
    }
}
