import jdk.jshell.SourceCodeAnalysis;

import java.util.Scanner;

public class Activitat12 {
    public static void main(String[] args) {
        int [] llistaNoOrdenat = Activitat10.generararray(10);
        int [] llistaOrdenat = Activitat10.generararray(10);
        Activitat10.ordenararray(llistaOrdenat);
        int numeroBuscar = demanarenter();
        if (numeroBuscar > 0) {
            System.out.println("El elemento se encuentra en la posicio " + numeroBuscar);
        } else {
            System.out.println("El elemento no se encuentra en la posicio " + numeroBuscar);
        }
    }

    public static int cercarEnVectorNoOrdenat(int[] numeros, int numBuscar){

        for (int i = 0; i < numeros.length; i++){
            if (numeros[i] == numBuscar){
                return i;
            }
        }

        return -1;
    }

    public static int cercarEnVectorOrdenat(int[] numeros, int numBuscar){

        for(int i = 0; i < numeros.length; i++){
            if(numeros[i] == numBuscar){
                return i;
            }
        }

        return -1;

    }

    public static int demanarenter(){
        Scanner teclado = new Scanner(System.in);

        do{
            System.out.println("Introdueix un enter: ");
            if(teclado.hasNextInt()){
                return teclado.nextInt();
            } else {
                System.out.println("Error! Has de introduir un numero enter");
            }
            teclado.next();
        } while (true);
    }

}