package es.puchades.productos;

import es.puchades.enums.TamanyoDeBebida;

public class Producto {
    final static int BASE_DE_PORCENTAJE = 100;
    private String codigo;
    private String descripcion;
    private float precioBase;
    private float decuento;
    private float iva;

    public Producto(String codigoProducto) {
        this.codigo = codigoProducto;
    }

    public Producto(String codigo, String descripcion, float precioBase, float decuento, float iva){
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.precioBase = precioBase;
        this.decuento = decuento;
        this.iva = iva;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public float getDecuento() {
        return decuento;
    }

    public float getPrecioBase() {
        return precioBase;
    }

    public boolean getEsRellenable() {
        return false;
    }

    public boolean getAptoParaDiabeticos(){
        return false;
    }

    public TamanyoDeBebida getTamanyoDeBebida() {
        return null;
    }

    public boolean getAptoParaCeliacos(){
        return false;
    }

    public float calcularElPrecioPVP(){
        float precioPVP = precioBase * (1 + (iva / BASE_DE_PORCENTAJE));
        return precioPVP - (precioPVP * (decuento / BASE_DE_PORCENTAJE));
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Producto)) {
            return false;
        }
        Producto producto = (Producto) obj;
        return codigo.equalsIgnoreCase(producto.codigo);
    }
}