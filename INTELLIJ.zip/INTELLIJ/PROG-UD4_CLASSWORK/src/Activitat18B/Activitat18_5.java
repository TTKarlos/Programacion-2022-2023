package Activitat18B;

import java.util.Scanner;

public class Activitat18_5 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduzca una frase: ");
        String frase = teclado.nextLine();

        System.out.printf("Resultado: %s\n", primeraYUltimaPalabraInvertida(frase));
    }

    public static String primeraYUltimaPalabraInvertida(String frase){

        String primeraParaula = frase.substring(0, frase.indexOf(" ") + 1);
        String ultimaParaula = frase.substring(frase.lastIndexOf(" ") + 1);

        frase = ultimaParaula + frase.substring(frase.indexOf(" "), frase.lastIndexOf(" ") + 1) + primeraParaula;

        return frase;
    }
}