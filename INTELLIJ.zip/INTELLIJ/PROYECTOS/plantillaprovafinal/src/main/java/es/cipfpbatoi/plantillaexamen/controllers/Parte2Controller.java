package es.cipfpbatoi.plantillaexamen.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class Parte2Controller {

}