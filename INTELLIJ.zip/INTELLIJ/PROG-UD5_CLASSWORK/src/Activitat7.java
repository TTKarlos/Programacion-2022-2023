public class Activitat7 {
    public static void main(String[] args) {

        String[] diesDeLaSetmana = {"dilluns", "dimarts", "dimecres2", "dijous", "divendres", "dissabte", "diumenge"};
        visualitzarArray(diesDeLaSetmana);
        String[] diesDeLaSetmana3 = diesDeLaSetmana;

        String[] diesDeLaSetmana2 = diesDeLaSetmana;

        diesDeLaSetmana2[0] = "monday";

        String[] array = copiaArray(diesDeLaSetmana, diesDeLaSetmana2);
        visualitzarArray(array);

        visualitzarArray(diesDeLaSetmana3);

    }

    public static String[] copiaArray(String [] cadena, String[] cadenaCopiada){

        for (int i = 0; i < cadena.length; i++){
            cadenaCopiada [i] = cadena[i];
        }

        return cadenaCopiada;
    }

    public static void visualitzarArray(String[] vector){

        for(int i = 0; i < vector.length; i++){
            System.out.println(vector[i]);
        }
    }
}
