package Activitat18B;

import java.util.Scanner;

public class Activitat18_3 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduzca una cadena: ");
        String nom = teclado.next();

        System.out.printf("Resultado: \"%s\"\n", nomInvertida(nom));
    }

    public static String nomInvertida(String nom){

        String nomInvertit = "";

        for (int i = 0; i < nom.length(); i++){
            nomInvertit = nom.charAt(i) + nomInvertit;
        }

        nom = nom.substring(0, nom.length() - 2) + nomInvertit;

        return nom;
    }
}