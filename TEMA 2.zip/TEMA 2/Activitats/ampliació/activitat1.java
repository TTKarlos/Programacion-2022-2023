package ampliació;

import java.util.Scanner;

public class activitat1 {

    final static int HORAS_A_DIAS = 24;
    final static int MINUTOS_A_HORAS = 60;
    final static int SEGUNDOS_A_MINUTOS = 60;

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Introdueix el nombre de segons que han transcorregut? ");
        float segundos = teclado.nextFloat();

        float minutos = segundos / SEGUNDOS_A_MINUTOS;
        float horas = minutos / MINUTOS_A_HORAS;
        float dias = horas / HORAS_A_DIAS;

        System.out.print("dies: " + dias + "\nhores: " + horas + "\nminuts: " + minutos + "\nsegons: " + segundos );

    }
}
