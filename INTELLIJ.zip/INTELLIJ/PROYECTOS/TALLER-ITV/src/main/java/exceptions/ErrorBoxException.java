package exceptions;

public class ErrorBoxException extends RuntimeException{
    public ErrorBoxException(){
        super("Error! El número de box debe ser entre 1 y 6");
    }
}