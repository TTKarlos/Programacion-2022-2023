package activitat16;

public class Ingrediente {

    private String nombre;
    private String descripcion;
    private int precio;

    public Ingrediente(String nombre){
        this.nombre = nombre;
        this.descripcion = "Producto";
        this.precio = 1;
    }

    public int getPrecio() {
        return precio;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
