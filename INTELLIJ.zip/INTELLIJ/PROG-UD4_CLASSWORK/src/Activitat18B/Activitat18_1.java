package Activitat18B;

import java.util.Scanner;

public class Activitat18_1 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduzca palabra secreta: ");
        String palabra = teclado.next();

        boolean esCorrecte = true;
        int contador = 1;
        do{
            System.out.printf("Intenta averiguar la palabra, intento %d: ", contador);
            String palabraAdivinar = teclado.next();

            if (palabraAdivinar.equalsIgnoreCase(palabra)){
                esCorrecte = false;
                System.out.println("Enhorabuena!!");
            }

            contador++;

        } while (esCorrecte || contador < 3);
    }
}