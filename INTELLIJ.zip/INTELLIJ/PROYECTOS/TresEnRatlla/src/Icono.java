import java.util.Scanner;

public class Icono {
    final static String COLOR_ROJO = "\u001B[31m";
    final static String COLOR_AZUL = "\u001B[34m";
    final static String COLOR_CYAN = "\u001B[36m";
    final static String RESET_COLOR = "\u001B[0m";
    final static String TEXTO_OPCION_INVALIDA = COLOR_ROJO + "¡Error! " + RESET_COLOR + "Opción inexistente";
    final static String ESPACIO_VACIO = " \u2B1B ";
    final static int NUMERO_ALEATORIO = 5;
    private String[][] packs ={
            {" \u274C "," \u2B55 "},
            {" \uD83D\uDE97 "," \uD83C\uDFCD\uFE0F "},
            {" \uD83D\uDC36 "," \uD83D\uDC08 "},
            {" \uD83D\uDC69\u200D\uD83E\uDDB0 "," \uD83D\uDC66\uD83C\uDFFC "}
    };
    private int packSeleccionado;

    public Icono(){
        seleccionar();
    }

    public void seleccionar(){
        Scanner teclado = new Scanner(System.in);

        mostarInformacion();

        do{
            System.out.printf(COLOR_AZUL + "Selecciona una opcion [1-%d]: %s", packs.length + 1, RESET_COLOR);

            if(teclado.hasNextInt()){

                int num = teclado.nextInt();

                if(num >= 1 && num <= packs.length && num != NUMERO_ALEATORIO){
                    this.packSeleccionado = num - 1;
                    return;
                } else if (num == NUMERO_ALEATORIO) {
                    this.packSeleccionado = (int) (Math.random()*4);
                    return;
                }
            }

            System.out.println(TEXTO_OPCION_INVALIDA);
        } while(true);
    }

    private void mostarInformacion(){
        System.out.println(COLOR_CYAN + "Vamos a seleccionas los iconos con los que jugar:" + RESET_COLOR);

        for (int i = 0; i < packs.length; i++) {
            System.out.printf("%s%d)%s%s\b%s\n", COLOR_ROJO, i + 1, RESET_COLOR, packs[i][0], packs[i][1]);
        }
        System.out.printf("%s%d)%s Aleatorio\n",COLOR_ROJO, NUMERO_ALEATORIO, RESET_COLOR);
    }

    public String obtenerSimbolo(EstadoCasilla estadoCasilla){
        if(estadoCasilla == EstadoCasilla.FICHA_X){
            return packs[packSeleccionado][0];
        } else if(estadoCasilla == EstadoCasilla.FICHA_O){
            return packs[packSeleccionado][1];
        } else{
            return ESPACIO_VACIO;
        }
    }
}