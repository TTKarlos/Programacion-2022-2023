package entities.menu.opciones;

import es.puchades.Restaurante;

public class MostrarPedidosOpcion extends OpcionesRestaurante {
    protected Restaurante restaurante;

    public MostrarPedidosOpcion(Restaurante restaurante){
        super("Listar Todos los Pedidos", restaurante);
        this.restaurante = restaurante;
    }

    @Override
    public void ejecutar() {
        restaurante.mostrarListaPedidos();
    }
}