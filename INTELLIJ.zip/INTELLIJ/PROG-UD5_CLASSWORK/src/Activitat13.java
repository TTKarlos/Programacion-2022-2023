import java.util.Arrays;

public class Activitat13 {

    final static int NUMERO_BUSCAR = 9;
    final static int NUMERO_1k = 1000;
    final static int NUMERO_10k = 10000;
    final static int NUMERO_100k = 100000;
    final static int NUMERO_1M = 1000000;

    public static void main(String[] args) {

        System.out.println("Delay per Interncanvi: ");
        verDelayIntercanvi(generararray(NUMERO_1k));
        verDelayIntercanvi(generararray(NUMERO_10k));
        verDelayIntercanvi(generararray(NUMERO_100k));
        verDelayIntercanvi(generararray(NUMERO_1M));

        System.out.println("Delay per Ordenació: ");
        verDelaySeleccio(generararray(NUMERO_1k));
        verDelaySeleccio(generararray(NUMERO_10k));
        verDelaySeleccio(generararray(NUMERO_100k));
        verDelaySeleccio(generararray(NUMERO_1M));

        System.out.println("Delay per Lineal: ");
        verDelayLineal(generararray(NUMERO_1k));
        verDelayLineal(generararray(NUMERO_10k));
        verDelayLineal(generararray(NUMERO_100k));
        verDelayLineal(generararray(NUMERO_1M));

        System.out.println("Delay per Binari: ");
        verDelayBinari(generararray(NUMERO_1k));
        verDelayBinari(generararray(NUMERO_10k));
        verDelayBinari(generararray(NUMERO_100k));
        verDelayBinari(generararray(NUMERO_1M));
    }

    public static void verDelayIntercanvi(int[] cadena){
        long tiempoInicio = System.currentTimeMillis();
        ordenacioPerIntercanvi(cadena);
        long tiempoFin = System.currentTimeMillis();
        long tiempoEjecucion = tiempoFin - tiempoInicio;
        System.out.println(tiempoEjecucion);
    }

    public static int compararPerBinari(int[] cadena, int num){

        for (int i = 0; i < cadena.length; i++){
            if(Arrays.binarySearch(cadena,num) > 0){
                return i+1;
            }
        }
        return -1;
    }

    public static void verDelayBinari(int[] cadena){
        long tiempoInicio = System.currentTimeMillis();
        compararPerBinari(ordenacioPerIntercanvi(cadena), NUMERO_BUSCAR);
        long tiempoFin = System.currentTimeMillis();
        long tiempoEjecucion = tiempoFin - tiempoInicio;
        System.out.println(tiempoEjecucion);
    }

    public static void verDelayLineal(int[] cadena){
        long tiempoInicio = System.currentTimeMillis();
        compararPerLineal(ordenacioPerIntercanvi(cadena), NUMERO_BUSCAR);
        long tiempoFin = System.currentTimeMillis();
        long tiempoEjecucion = tiempoFin - tiempoInicio;
        System.out.println(tiempoEjecucion);
    }
    public static int compararPerLineal(int[] cadena, int num){

        for (int i = 0; i < cadena.length; i++){
            if(cadena[i] == num){
                return i+1;
            }
        }

        return -1;
    }

    public static void verDelaySeleccio(int[] cadena){
        long tiempoInicio = System.currentTimeMillis();
        ordenarPerSeleccio(cadena);
        long tiempoFin = System.currentTimeMillis();
        long tiempoEjecucion = tiempoFin - tiempoInicio;
        System.out.println(tiempoEjecucion);
    }

    public static int[] generararray(int tamanyo){
        int[] array = new int[tamanyo];
        for (int i = 0; i <= tamanyo - 1; i++){
            array[i] = (int) (Math.random() * 9 + 0);
        }
        return array;
    }

    public static int[] ordenacioPerIntercanvi(int[] cadena){
        int num;
        for ( int i = 0; i < cadena.length; i++){
            for( int j = i + 1; j < cadena.length; j++){
                if (cadena[j] < cadena[i]){
                    num = cadena[i];
                    cadena[i] = cadena[j];
                    cadena[j] = num;
                }
            }
        }

        return cadena;
    }

    public static void ordenarPerSeleccio(int[] vector){
        for (int i = 0; i < vector.length - 1; i++) {
            int elementMenor = i;
            for (int j = i + 1; j < vector.length; j++) {
                if (vector[j] < vector[elementMenor]){
                    elementMenor = j;
                }
                if(elementMenor != i){
                    String aux = String.valueOf(vector[elementMenor]);
                    vector[elementMenor] = vector[i];
                    vector[i] = Integer.parseInt(aux);
                }
            }
        }
    }
}