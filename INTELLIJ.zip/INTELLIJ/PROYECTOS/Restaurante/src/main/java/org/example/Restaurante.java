package org.example;

public class Restaurante {

    public static void main(String[] args) {
        Camarero camarero = new Camarero();
        Menu menu = new Menu(camarero);
        menu.show();
    }
}