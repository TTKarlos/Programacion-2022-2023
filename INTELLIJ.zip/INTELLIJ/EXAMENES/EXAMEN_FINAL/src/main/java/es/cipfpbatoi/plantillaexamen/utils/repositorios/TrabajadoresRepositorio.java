package es.cipfpbatoi.plantillaexamen.utils.repositorios;

import es.cipfpbatoi.plantillaexamen.model.dao.SQLPersonalDAO;
import es.cipfpbatoi.plantillaexamen.model.dao.interfices.SQLPersonalDAOInterfice;
import es.cipfpbatoi.plantillaexamen.utils.Trabajador;
import es.cipfpbatoi.plantillaexamen.utils.Universidad;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;

@Service
public class TrabajadoresRepositorio {
    @Autowired
    private UniversidadRepositorio universidadRepositorio;
    @Autowired
    private SQLPersonalDAOInterfice sqlPersonalDAOInterfice;

    public TrabajadoresRepositorio(@Autowired SQLPersonalDAO sqlPersonalDAO){
        this.sqlPersonalDAOInterfice = sqlPersonalDAO;
    }

    public void save(Trabajador trabajador){
        sqlPersonalDAOInterfice.save(trabajador);
    }

    public ArrayList<Trabajador> findAllBuscador(String buscador){
        ArrayList<Trabajador> trabajadorsPorDni = sqlPersonalDAOInterfice.findAllBuscador("dni", buscador);
        ArrayList<Trabajador> trabajadorsPorNombre = sqlPersonalDAOInterfice.findAllBuscador("nombre", buscador);
        ArrayList<Universidad> universidadesPorNombre = universidadRepositorio.findAllBuscador(buscador);
        ArrayList<Trabajador> trabajadorsPorUniversidad = getTrabajadoresPorUniversidad(universidadesPorNombre);
        trabajadorsPorUniversidad = unirDoesArrays(trabajadorsPorUniversidad, trabajadorsPorDni);
        trabajadorsPorUniversidad = unirDoesArrays(trabajadorsPorUniversidad, trabajadorsPorNombre);

        trabajadorsPorUniversidad = getTrabajadoresWithUniversidad(trabajadorsPorUniversidad);
        return trabajadorsPorUniversidad;
    }

    public ArrayList<Trabajador> findAllWithuniversities(){
        ArrayList<Trabajador> trabajadorsOld = sqlPersonalDAOInterfice.findAll();
        ArrayList<Trabajador> trabajadorsNew = new ArrayList<>();

        for (int i = 0; i < trabajadorsOld.size(); i++) {
            Trabajador trabajador = trabajadorsOld.get(i);
            trabajador.setUniversdad(universidadRepositorio.findById(trabajador.getIdUniversidad()));
            trabajadorsNew.add(trabajador);
        }

        return trabajadorsNew;
    }

    private ArrayList<Trabajador> getTrabajadoresPorUniversidad(ArrayList<Universidad> universidads){
        ArrayList<Trabajador> trabajadors = new ArrayList<>();
        for (int i = 0; i < universidads.size(); i++) {
            trabajadors = unirDoesArrays(trabajadors, sqlPersonalDAOInterfice.findAllBuscador("universidad_id", String.valueOf(universidads.get(i).getCodigo())));
        }

        return trabajadors;
    }

    private ArrayList<Trabajador> unirDoesArrays(ArrayList<Trabajador> trabajadors1, ArrayList<Trabajador> trabajadors2){
        for (int i = 0; i < trabajadors2.size(); i++) {
            trabajadors1.add(trabajadors2.get(i));
        }

        return trabajadors1;
    }

    private ArrayList<Trabajador> getTrabajadoresWithUniversidad(ArrayList<Trabajador> trabajadors){
        ArrayList<Trabajador> trabajadorsNew = new ArrayList<>();

        for (int i = 0; i < trabajadors.size(); i++) {
            Trabajador trabajador = trabajadors.get(i);
            trabajador.setUniversdad(universidadRepositorio.findById(trabajador.getIdUniversidad()));
            trabajadorsNew.add(trabajador);
        }

        return trabajadorsNew;
    }
}