package RepàsExamen;

public class MetodosDeOrdenacio {

    public static void visualizarArray(String[] matriu){
        for(int i = 0; i < matriu.length; i++){
            System.out.print(matriu[i] + " ");
        }
    }

    public static void ordenarPerSeleccio(String[] vector){
        for (int i = 0; i < vector.length - 1; i++) {
            int elementMenor = i;
            for (int j = i + 1; j < vector.length; j++) {
                if (vector[j].compareTo(vector[elementMenor]) < 0){
                    elementMenor = j;
                }
                if(elementMenor != i){
                    String aux = vector[elementMenor];
                    vector[elementMenor] = vector[i];
                    vector[i] = aux;
                }
            }
        }
    }

    public static void ordenarPerIntecanvi(String[] vector){
        for ( int i = 0; i < vector.length; i++){
            for( int j = i + 1; j < vector.length; j++){
                if (vector[j].compareTo(vector[i]) < 0){
                    String aux = vector[i];
                    vector[i] = vector[j];
                    vector[j] = aux;
                }
            }
        }
    }

    public static void ordenarPerIntecanvi(int[] vector){
        for ( int i = 0; i < vector.length; i++){
            for( int j = i + 1; j < vector.length; j++){
                if (vector[j] < vector[i]){
                    int aux = vector[i];
                    vector[i] = vector[j];
                    vector[j] = aux;
                }
            }
        }
    }

    public static void ordenarPerIntecanviAPartirDeDos (String[] vector) {
        for (int i = 0; i < vector.length - 1; i++){
            for (int j = i + 1; j < vector.length; j++){
                if (vector[j].substring(2, vector[j].length() - 1).compareToIgnoreCase(vector[i].substring(2, vector[i].length() - 1)) < 0) {
                    String aux = vector[i];
                    vector[i] = vector[j];
                    vector[j] = aux;
                }
            }
        }
    }
}
