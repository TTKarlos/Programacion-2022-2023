import java.util.Locale;
import java.util.Scanner;

public class Activitat23 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduce tu nombre: ");
        String nom = teclado.next();

        System.out.print("Introduce 1 apellido: ");
        String primerCognom = teclado.next();

        System.out.print("Introduce 2 apellido: ");
        String segonCognom = teclado.next();

        String cadenaCompleta = nom + " " + primerCognom + " " + segonCognom;

        numComplet(nom, primerCognom, segonCognom, cadenaCompleta);
        numDeVegadesDelUltimCaracter(cadenaCompleta);
        dosPrimersCaracter(cadenaCompleta);
        System.out.println("Camelcase: " + cadenaCompleta);
        System.out.print("Asteriscos:  ");
        cadenaAmbAsterisc(cadenaCompleta);
        System.out.print("Invertido: ");
        cadenaInvertida(cadenaCompleta);

        System.out.println("Show using mutable");
        System.out.printf("Mayúsculas: " + cadenaCompleta);
        System.out.print("\nAsteriscos:  ");
        cadenaAmbAsterisc(cadenaCompleta);
        System.out.print("Invertido (Mutable): ");
        cadenaInvertida(cadenaCompleta);

    }

    public static void numComplet(String nom,String primerCognom, String segonCognom, String cadenaCompleta){

        System.out.println("Minúsculas: " + nom.toLowerCase() + " " + primerCognom.toLowerCase() + " " + segonCognom.toLowerCase());
        System.out.println("Mayúsculas: " + nom.toUpperCase() + " " + primerCognom.toUpperCase() + " " + segonCognom.toUpperCase());

        System.out.printf("Longitud: %d", cadenaCompleta.length());
    }

    public static void dosPrimersCaracter(String cadenaCompleta){

        if (cadenaCompleta.length() > 2){
            System.out.println("\n2 primeros caracteres: " + cadenaCompleta.substring(0,2));
        }
    }

    public static void numDeVegadesDelUltimCaracter(String cadenaCompleta){

        String ultimaLletra = String.valueOf(cadenaCompleta.charAt(cadenaCompleta.length()-1));

        int contador = 0;

        for (int i = 0; i < cadenaCompleta.length(); i++) {
             if(ultimaLletra.equalsIgnoreCase(String.valueOf(cadenaCompleta.charAt(i)))){
                 contador++;
             }
        }
        System.out.println("\nNúmero de ocurrencias de " + ultimaLletra + " es " + contador);
    }

    public static void cadenaAmbAsterisc(String cadenaCompleta){
        System.out.println("***" + cadenaCompleta + "***");
    }

    public static void cadenaInvertida(String cadenaCompleta){

        String cadenaInvertida = "";

        for (int i = 0; i < cadenaCompleta.length(); i++){
            char caracter = cadenaCompleta.charAt(i);
            cadenaInvertida = caracter + cadenaInvertida;
        }
        System.out.println(cadenaInvertida);
    }
}