package actividad14;

import java.util.Scanner;

public class Actividad14 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introdueix un número: ");
        int a = teclado.nextInt();

        boolean resultado = Matematica.esPrimo(a);

        if (resultado == false){
            System.out.printf("El número %d és prim\n", a);
        } else {
            System.out.printf("El número %d no és prim\n", a);
        }

    }
}
