package activitat7;

import activitat6.Administrativo;

public class TestAduana {
    public static void main(String[] args) {
        Aduana espanyola = new Aduana();

        Persona arnau = new Persona("Arnau", "Fernandez Perez", 39);
        PersonaAnglesa paco = new PersonaAnglesa("Andreu", "Pascual Fernandez", 25, "2353252365X");

        espanyola.entrar(arnau);
        espanyola.entrar(paco);
    }
}