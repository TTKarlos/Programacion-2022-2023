package exceptions;

public class EleccionNoValidaExcepion extends RuntimeException{
    public EleccionNoValidaExcepion(String mensaje){
        super(mensaje);
    }
}