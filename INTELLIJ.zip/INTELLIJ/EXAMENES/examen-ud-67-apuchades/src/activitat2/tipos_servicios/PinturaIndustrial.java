package activitat2.tipos_servicios;

import activitat2.Servicio;
import activitat2.enums.TiposPintura;

public class PinturaIndustrial extends Servicio {
    final static int PRECIO_BASE = 210;
    final static int METROS_CUADRADOS_MINIMOS = 5;
    final static int PRECIO_SI_ES_MENOS_DE_5_M2 = 50;
    final static int PRECIO_SI_ES_MAS_DE_5_M2 = 70;
    final static double PORCENTAJE_DE_AUMENTAR_EL_PRECIO_BASE = 1.1;
    private TiposPintura tiposDePintura;

    public PinturaIndustrial(int numIdentifiacion, String direccion, int numMetrosCuadrados, int numDiasParaFinalizar,
                             float precioDeMateriales, TiposPintura tiposDePintura) {
        super(numIdentifiacion, direccion, numMetrosCuadrados, numDiasParaFinalizar, 3,
                precioDeMateriales);
        this.tiposDePintura = tiposDePintura;
    }

    public double calcularCosteTotal(){
        double precioTotal = super.calcularCosteTotal();

        if(getNumMetrosCuadrados() < METROS_CUADRADOS_MINIMOS){
            precioTotal += getNumDiasParaFinalizar() * (getNumDeOperariosAsigandos() * PRECIO_SI_ES_MENOS_DE_5_M2);
        } else {
            precioTotal += getNumDiasParaFinalizar() * (getNumDeOperariosAsigandos() * PRECIO_SI_ES_MAS_DE_5_M2);
        }

        if(tiposDePintura.equals(TiposPintura.EXTERIOR) || tiposDePintura.equals(TiposPintura.INTERIOR)){
            precioTotal += PRECIO_BASE * PORCENTAJE_DE_AUMENTAR_EL_PRECIO_BASE;
        } else {
            precioTotal += PRECIO_BASE;
        }

        return precioTotal;
    }

    @Override
    public String toString() {
        return "Pintado industrial " + super.toString();
    }
}