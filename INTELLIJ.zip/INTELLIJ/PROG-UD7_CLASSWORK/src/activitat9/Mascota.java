package activitat9;

public interface Mascota {
    public abstract void Mascota();
    public abstract void jugar();
}