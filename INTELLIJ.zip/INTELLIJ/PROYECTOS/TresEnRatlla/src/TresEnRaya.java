public class TresEnRaya {
    final static String COLOR_GRIS = "\u001B[37m";
    final static String RESET_COLOR = "\u001B[0m";
    final static String COLOR_CYAN = "\u001B[36m";
    final static String TITULO = COLOR_CYAN + "    Bienvenido al 3 en Raya" + RESET_COLOR +
            COLOR_GRIS + "\n================================" + RESET_COLOR;

    public static void main(String[] args) {
        do {
            System.out.println(TITULO);

            Menu menu = new Menu();

            Jugador[] jugadores = menu.getJugadores();

            if(jugadores[0] == null && jugadores[1] == null){
                return;
            }

            Icono icono = menu.getIcono();

            Partida partida = new Partida();
            partida.jugar(jugadores, icono);

        } while (true);
    }
}