package es.cipfpbatoi.gestorusuariosv2.model.dao;

import es.cipfpbatoi.gestorusuariosv2.model.dao.interfaces.EmpresaDAO;
import es.cipfpbatoi.gestorusuariosv2.model.entities.Empresa;
import es.cipfpbatoi.gestorusuariosv2.model.entities.User;
import es.cipfpbatoi.gestorusuariosv2.utils.database.MySQLConnection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.ArrayList;

@Service
public class SQLEmpresaDAO implements EmpresaDAO {
    private final MySQLConnection mySQLConnection;

    public SQLEmpresaDAO(@Autowired MySQLConnection mySQLConnection) {
        this.mySQLConnection = mySQLConnection;
    }

    @Override
    public ArrayList<Empresa> findAll() {
        ArrayList<Empresa> usersList = new ArrayList<>();

        try (Connection connection = mySQLConnection.getConnection();
             Statement statement = connection.createStatement()){
            String sql = "SELECT * FROM enterprises";
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()){
                usersList.add(mapFromResulset(resultSet));
            }

            return usersList;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Empresa findById(int id) {
        try {
            Connection connection = mySQLConnection.getConnection();
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM enterprises WHERE id = " + id;
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()){
                return mapFromResulset(resultSet);
            }
            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean save(Empresa empresa) {
        if(empresa.getId() > 1){
            return update(empresa);
        }

        return insert(empresa);
    }

    private boolean update(Empresa empresa){
        int afectedRows = 0;

        String sql = "UPDATE users SET name = ?, address = ?, city = ?, province = ?, country = ?" +
                "createdOn = ?, nif = ? WHERE id = ?";
        try (Connection connection = mySQLConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setString(1, empresa.getName());
            ps.setString(2, empresa.getAdress());
            ps.setString(3, empresa.getCity());
            ps.setString(4, empresa.getProvince());
            ps.setString(5, empresa.getCountry());
            ps.setDate(6, Date.valueOf(empresa.getCreatedOn()));
            ps.setString(7, empresa.getNif());
            ps.setInt(8, empresa.getId());
            afectedRows = ps.executeUpdate();
            return afectedRows > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private boolean insert(Empresa empresa){
        String sql = "INSERT INTO Empresas (id, name, address, city, province, country, createdOn, nif) " +
                "VALUES (?,?,?,?,?,?,?)";
        try (Connection connection = mySQLConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)){

            preparedStatement.setNull(1, Types.INTEGER);
            preparedStatement.setString(2, empresa.getName());
            preparedStatement.setString(3, empresa.getAdress());
            preparedStatement.setString(4, empresa.getCity());
            preparedStatement.setString(5, empresa.getProvince());
            preparedStatement.setString(6, empresa.getCountry());
            preparedStatement.setDate(7, Date.valueOf(empresa.getCreatedOn()));
            preparedStatement.setString(8, empresa.getNif());
            return preparedStatement.executeUpdate() > 0;

        } catch (SQLException e){
            throw new RuntimeException(e);
        }
    }

    public boolean remove(Empresa empresa) {
        int afectedRows = 0;
        String sql = "DELETE FROM enterprises WHERE id = ?";
        try (Connection connection = mySQLConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(sql)){
            preparedStatement.setInt(1, empresa.getId());
            afectedRows = preparedStatement.executeUpdate();
            return afectedRows > 0;
        } catch (SQLException e){
            throw new RuntimeException(e);
        }
    }

    private Empresa mapFromResulset(ResultSet resultSet) throws SQLException {
        return new Empresa(resultSet.getInt("id"), resultSet.getString("name"),
                resultSet.getString("address"), resultSet.getString("city"),
                resultSet.getString("province"), resultSet.getString("country"),
                resultSet.getDate("createdOn").toLocalDate(), resultSet.getString("nif"));
    }
}