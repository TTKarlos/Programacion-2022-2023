import java.util.Scanner;

/**
 * @Error: Al no tener "public static void main(String[] args) {" no tiene "main" y no pot cridar al programa per a
 * poder executar-lo.
 * @Tipus: Temps de compilació.
 **/

public class Actividad16_10 {
        public static void main(String[] args) {


                Scanner teclat = new Scanner(System.in);
                System.out.println("Introdueix el operand 1");
                int operand1 = teclat.nextInt();

                System.out.println("Introdueix el operand 2");
                int operand2 = teclat.nextInt();

                System.out.printf("El resultat de %d + %d = %d", operand1, operand2, (operand1 + operand2));

}
}