import java.util.Scanner;

/**
 * @Error: Tenim que possar una operacio entre parentesis en un System.out.print()
 * @Tipus: Temps de compilació.
 **/

public class Actividad16_1 {

    public static void main(String[] args) {
        Scanner scannerKey = new Scanner(System.in);

        System.out.println("Introduce el número 1");
        int num1 = scannerKey.nextInt();

        System.out.println("Introduce el número 2");
        int num2 = scannerKey.nextInt();

        int aux = num1;
        num1 = num2;
        num2 = aux;

        System.out.println("Tras realizar el cambio");
        System.out.println("El número 1 es: " + (num1 - 2));
        System.out.println("El número 2 es: " + num2);
    }

}