package activitat9;

import activitat9.types.Lleo;
import activitat9.types.Tigre;

public class Veterinario {

    public static void vacunar(Animal animal) {
        if (animal instanceof Tigre || animal instanceof Lleo) {
            animal.comer();
            animal.vacunar();
        } else {
            animal.vacunar();
        }
    }
}