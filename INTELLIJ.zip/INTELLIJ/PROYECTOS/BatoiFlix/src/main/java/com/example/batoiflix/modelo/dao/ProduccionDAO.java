package com.example.batoiflix.modelo.dao;

import com.example.batoiflix.modelo.dao.interfaces.ProduccionDAOInterface;
import com.example.batoiflix.modelo.entities.Actores;
import com.example.batoiflix.modelo.entities.Director;
import com.example.batoiflix.modelo.entities.Produccion;
import com.example.batoiflix.modelo.entities.Productor;
import com.example.batoiflix.modelo.enums.Calificacion;
import com.example.batoiflix.modelo.enums.Genero;
import com.example.batoiflix.utils.database.MySQLConnection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.ArrayList;

@Service
public class ProduccionDAO implements ProduccionDAOInterface {
    @Autowired
    MySQLConnection mySQLConnection;

    public ProduccionDAO(@Autowired MySQLConnection mySQLConnection){
        this.mySQLConnection = mySQLConnection;
    }

    public Actores getByIdActor(int id){
        Actores actor = findByIdActor(id);

        if(actor == null){
            throw new RuntimeException();
        }

        return actor;
    }

    public Actores findByIdActor(int id){
        try {
            Connection connection = mySQLConnection.getConnection();
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM actores WHERE id = " + id;
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()){
                return mapFromResulsetActor(resultSet);
            }

            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Actores findByNombreActor(String nombre){

        try {
            Connection connection = mySQLConnection.getConnection();
            Statement statement = connection.createStatement();
            String sql = String.format("SELECT * FROM actores WHERE nombre LIKE '%s%%'", nombre);
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()){
                return mapFromResulsetActor(resultSet);
            }

            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Director findByNombreDirector(String nombre){
        try {
            Connection connection = mySQLConnection.getConnection();
            Statement statement = connection.createStatement();
            String sql = String.format("SELECT * FROM directores WHERE nombre LIKE '%s%%'", nombre);
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()){
                return mapFromResulsetDirector(resultSet);
            }

            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Productor findByNombreProductor(String nombre){
        try {
            Connection connection = mySQLConnection.getConnection();
            Statement statement = connection.createStatement();
            String sql = String.format("SELECT * FROM productores WHERE nombre LIKE '%s%%'", nombre);
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()){
                return mapFromResulsetProductor(resultSet);
            }

            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Director getByIdDirector(int id){
        Director director = findByIdDirector(id);

        if(director == null){
            throw new RuntimeException();
        }

        return director;
    }

    public Director findByIdDirector(int id){
        try {
            Connection connection = mySQLConnection.getConnection();
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM directores WHERE id = " + id;
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()){
                return mapFromResulsetDirector(resultSet);
            }

            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Productor getByIdProductor(int id){
        Productor productor = findByIdProductor(id);

        if(productor == null){
            throw new RuntimeException();
        }

        return productor;
    }

    public Productor findByIdProductor(int id){
        try {
            Connection connection = mySQLConnection.getConnection();
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM productores WHERE id = " + id;
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()){
                return mapFromResulsetProductor(resultSet);
            }

            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public ArrayList<Produccion> findAll() {
        ArrayList<Produccion> usersList = new ArrayList<>();

        try {
            Connection connection = mySQLConnection.getConnection();
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM producciones";
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()){
                usersList.add(mapFromResulsetProduccion(resultSet));
            }

            return usersList;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean save(Produccion produccion) {
        if(produccion.getId() == -1){
            produccion = getProduccionFinal(produccion);
            return insert(produccion);
        }

        return update(produccion);
    }

    private boolean update(Produccion produccion){
        return false;
    }

    private boolean insert(Produccion produccion){
        String sql = "INSERT INTO producciones (id, titulo, calificacion, fecha_lanzamiento, duracion, genero, " +
                "director, id_actores, guion, portada, tipo, id_productora, web, disponible) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection connection = mySQLConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setNull(1, Types.INTEGER);
            ps.setString(2, produccion.getTitulo());
            ps.setString(3, produccion.getCalificacion().toString());
            ps.setDate(4, Date.valueOf(produccion.getFechaLanzamiento()));
            ps.setInt(5, produccion.getDuracion());
            ps.setString(6, getCadenaGeneros(produccion.getGenero()));
            ps.setInt(7, produccion.getDirector().getId());
            ps.setString(8, produccion.getActor());
            ps.setString(9, produccion.getGuion());
            ps.setString(10, produccion.getPortada());
            ps.setString(11, produccion.getClass().getSimpleName());
            ps.setInt(12, produccion.getProductor().getId());
            ps.setString(13, produccion.getWeb());
            ps.setBoolean(14, true);

            int afectedRows = ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int autoincremental = rs.getInt(1);
                produccion.setId(autoincremental);
            }

            return afectedRows > 0;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private boolean insert(Actores actores){
        String sql = "INSERT INTO actores (id, nombre) VALUES (?,?)";
        try (Connection connection = mySQLConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setNull(1, Types.INTEGER);
            ps.setString(2, actores.getNombre());

            int afectedRows = ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int autoincremental = rs.getInt(1);
                actores.setCodigo(autoincremental);
            }

            return afectedRows > 0;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private boolean insertProductor(Productor productor){
        String sql = "INSERT INTO productores (id, nombre) VALUES (?,?)";
        try (Connection connection = mySQLConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setNull(1, Types.INTEGER);
            ps.setString(2, productor.getNombre());

            int afectedRows = ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int autoincremental = rs.getInt(1);
                productor.setId(autoincremental);
            }

            return afectedRows > 0;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private boolean insertDirector(Director director){
        String sql = "INSERT INTO directores (id, nombre) VALUES (?,?)";
        try (Connection connection = mySQLConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setNull(1, Types.INTEGER);
            ps.setString(2, director.getNombre());

            int afectedRows = ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int autoincremental = rs.getInt(1);
                director.setId(autoincremental);
            }

            return afectedRows > 0;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private boolean insertActores(Actores actores){
        String sql = "INSERT INTO actores (id, nombre) VALUES (?,?)";
        try (Connection connection = mySQLConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setNull(1, Types.INTEGER);
            ps.setString(2, actores.getNombre());

            int afectedRows = ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int autoincremental = rs.getInt(1);
                actores.setCodigo(autoincremental);
            }

            return afectedRows > 0;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private Produccion mapFromResulsetProduccion(ResultSet resultSet){
        try{
            return new Produccion(resultSet.getInt("id"), resultSet.getString("titulo"),
                    getCalificacion(resultSet.getString("calificacion")),
                    resultSet.getDate("fecha_lanzamiento").toLocalDate(), resultSet.getInt("duracion"),
                    getGeneros(resultSet.getString("genero")), getByIdDirector(resultSet.getInt("director")),
                    getActores(resultSet.getString("id_actores")), resultSet.getString("guion"),
                    resultSet.getString("portada"), getByIdProductor(resultSet.getInt("id_productora")),
                    resultSet.getString("web"));
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private Actores mapFromResulsetActor(ResultSet resultSet){
        try{
            return new Actores(resultSet.getInt("id"), resultSet.getString("nombre"));
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private Director mapFromResulsetDirector(ResultSet resultSet){
        try{
            return new Director(resultSet.getInt("id"), resultSet.getString("nombre"));
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private Productor mapFromResulsetProductor(ResultSet resultSet){
        try{
            return new Productor(resultSet.getInt("id"), resultSet.getString("nombre"));
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private Calificacion getCalificacion(String cadena){
        if(cadena.equalsIgnoreCase("G")){
            return Calificacion.G;
        } else if (cadena.equalsIgnoreCase("GP")) {
            return Calificacion.PG;
        } else if (cadena.equalsIgnoreCase("GP_13")) {
            return Calificacion.PG_13;
        } else if (cadena.equalsIgnoreCase("R")) {
            return Calificacion.R;
        } else {
            return Calificacion.X;
        }
    }

    private ArrayList<Actores> getActores(String cadenaIds){
        ArrayList<Actores> actores = new ArrayList<>();
        String[] actoresIds = cadenaIds.split(",");

        for (int i = 0; i < actoresIds.length; i++) {
            actores.add(getByIdActor(Integer.parseInt(actoresIds[i])));
        }

        return actores;
    }

    private ArrayList<Genero> getGeneros(String cadenaGeneros){
        Genero[] allGeneros = {
                Genero.ADVENTURE, Genero.ACTION, Genero.ANIMATION, Genero.BIOGRAPHY, Genero.FANTASY,
                Genero.DRAMA, Genero.CRIME, Genero.FAMILY, Genero.HORROR, Genero.HISTORY, Genero.MUSICAL, Genero.SPORT,
                Genero.COMEDY, Genero.SCI_FI, Genero.MISTERY, Genero.WESTERN, Genero.ROMANCE, Genero.THRILLER,
        };

        ArrayList<Genero> generos = new ArrayList<>();
        String[] generosCadena = cadenaGeneros.split(",");

        for (int i = 0; i < generosCadena.length; i++) {
            for (int j = 0; j < allGeneros.length; j++) {
                if(allGeneros[j].toString().equalsIgnoreCase(generosCadena[i])){
                    generos.add(allGeneros[j]);
                }
            }
        }

        return generos;
    }

    private String getCadenaActores(ArrayList<Actores> actores){
        StringBuilder cadena = new StringBuilder();

        for (int i = 0; i < actores.size(); i++) {
            Actores actores1 = findByNombreActor(actores.get(i).getNombre());
            if(actores1 == null){
                insertActores(actores.get(i));
            }
        }

        ArrayList<Actores> actoresNews = new ArrayList<>();

        for (int i = 0; i < actores.size(); i++) {
            actoresNews.add(findByNombreActor(actores.get(i).getNombre()));
        }

        for (int i = 0; i < actoresNews.size(); i++) {
            cadena.append(actoresNews.get(i).getCodigo());
            cadena.append(",");
        }

        return String.valueOf(cadena).substring(0, cadena.length() - 2) ;
    }

    private String getCadenaGeneros(ArrayList<Genero> generos){
        StringBuilder cadena = new StringBuilder();

        for (int i = 0; i < generos.size(); i++) {
            cadena.append(generos.get(i).toString());
            cadena.append(",");
        }

        return String.valueOf(cadena) ;
    }

    private Produccion getProduccionFinal(Produccion produccion){

        Productor productor = findByNombreProductor(produccion.getProductor().getNombre());

        if(productor == null){
            insertProductor(produccion.getProductor());
            Productor productorNew = findByNombreProductor(produccion.getProductor().getNombre());
            produccion.setProductor(productorNew);
        } else {
            produccion.setProductor(productor);
        }

        Director director = findByNombreDirector(produccion.getDirector().getNombre());

        if(director == null){
            insertDirector(produccion.getDirector());
            Director directorNew = findByNombreDirector(produccion.getDirector().getNombre());
            produccion.setDirector(directorNew);
        } else {
            produccion.setDirector(director);
        }

        produccion.setActor(getCadenaActores(produccion.getActores()));
        return produccion;
    }
}