import java.util.Objects;

public class Partido {
    private int codigo;
    private String nombre;

    public Partido(int codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    public Partido(int codigo) {
        this.codigo = codigo;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Partido partido)) return false;
        return getCodigo() == partido.getCodigo();
    }
}