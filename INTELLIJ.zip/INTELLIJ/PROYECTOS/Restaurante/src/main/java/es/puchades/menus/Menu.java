package es.puchades.menus;

import es.puchades.GestorIO;
import es.puchades.menus.opciones.Opcion;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
    private ArrayList<Opcion> opciones;
    private String tituloMenu;

    public Menu(String tituloMenu) {
        this.opciones = new ArrayList<>();
        this.tituloMenu = tituloMenu;
    }

    public void ejecutar(){
        Opcion opcion;
        do {
            mostrar();
            opcion = getOpcion();
            opcion.ejecutar();
        } while (!opcion.finalizar());
    }

    public void anyadir(Opcion opcion) {
        this.opciones.add(opcion);
    }

    private void mostrar() {
        System.out.println(tituloMenu);
        for (int i = 0; i < opciones.size() ; i++) {
            opciones.get(i).mostrar(i + 1);
        }
    }

    private Opcion getOpcion() {
        return this.opciones.get(GestorIO.elegirUnNumero(1, opciones.size(),
                "Error! La opcion seleccionada no existe",
                "Seleccione una opcion [1-" + opciones.size()+ "]: ") - 1);
    }
}