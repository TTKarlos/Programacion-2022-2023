package es.cipfpbatoi.plantillaexamen.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Trabajador {
    private String dni;
    private String nombre;
    private int idUniversidad;
    private Universidad universidad;
    private LocalDateTime fechaContratado;

    public Trabajador(String dni, String nombre, int idUniversidad, LocalDateTime fechaContratado) {
        this.dni = dni;
        this.nombre = nombre;
        this.idUniversidad = idUniversidad;
        this.fechaContratado = fechaContratado;
    }

    public String getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public int getIdUniversidad() {
        return idUniversidad;
    }

    public Universidad getUniversdad() {
        return universidad;
    }

    public LocalDateTime getFechaContratado() {
        return fechaContratado;
    }

    public String getFechaContratadoForm() {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return fechaContratado.format(dateTimeFormatter);
    }

    public void setUniversdad(Universidad universidad) {
        this.universidad = universidad;
    }
}