package es.puchades.exceptions;

public class ColaVaciaExeption extends RuntimeException{
    public ColaVaciaExeption(){
        super("No hay ningun pedido pendiente");
    }
}