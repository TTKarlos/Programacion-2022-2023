package exception;

public class ViajeNoCancelableException extends RuntimeException{
    public ViajeNoCancelableException(int  horasSalida){
        super("Viaje no cancelable. Motivo: quedan " + horasSalida + " para la salida");
    }
}