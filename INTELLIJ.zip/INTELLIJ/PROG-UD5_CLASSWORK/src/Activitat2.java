import java.util.Scanner;

public class Activitat2 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        String[] nombre = new String[11];

        for (int i = 0; i <= nombre.length; i++){

            if(i % 2 == 0){
                System.out.printf("Introdueix el numero %d: ", i);

                nombre[i] = teclado.next();
            }
        }

        for(int i = 0; i <= nombre.length; i++){
            System.out.printf("Numero %d: %s\n", i, nombre[i]);

        }
    }
}