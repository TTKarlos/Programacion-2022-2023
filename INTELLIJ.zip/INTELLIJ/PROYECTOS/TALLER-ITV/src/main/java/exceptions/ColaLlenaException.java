package exceptions;

public class ColaLlenaException extends RuntimeException{
    public ColaLlenaException(String texto){
        super("Error! La cola de " + texto + " esta llena");
    }
}