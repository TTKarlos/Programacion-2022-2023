package examen;

public class Activitat2 {
    final static String[] MUNICIPIOS = {"Alcoy", "Alicante", "Benidorm", "Javea", "Cocentaina"};
    public static void main(String[] args) {
        int[][] temperaturas = {
                {23, 8, 35, 34, 40, 12, -5},
                {12, 34, 24, 8, 15, 14, -1},
                {67, 45, 10, 12, 12, 20, 0},
                {-40, -23, 20, 30, 8, 15, -5},
                {10, 14, 34, 50, 45, 20, -5}};
        int[] temperaturaMedia = {34, 20, 15, 8, -10};
        float[] temperaturaMediaMunicipios = temperaturaMediaMunicipios(temperaturas);

        System.out.printf("Municipio Alcoy: T. Media %.2f C\n", temperaturaMediaMunicipios[0]);
        System.out.printf("Municipio Alicante: T. Media %.2f C\n", temperaturaMediaMunicipios[1]);
        System.out.printf("Municipio Benidorm: T. Media %.2f C\n", temperaturaMediaMunicipios[2]);
        System.out.printf("Municipio Javea: T. Media %.2f C\n", temperaturaMediaMunicipios[3]);
        System.out.printf("Municipio Cocentaina: T. Media %.2f C\n", temperaturaMediaMunicipios[4]);

        float[] temperaturaMediaDia = temperaturaMediaDia(temperaturas);
        mostrarMediaPorDia(temperaturaMediaDia);

        int[] municipiosPorAbajo = municiposPorAbajoDeLaMedia(temperaturaMedia, temperaturaMediaMunicipios);
        int[] municipiosPorArriba = municiposPorEncimaDeLaMedia(temperaturaMedia, temperaturaMediaMunicipios);

        mostrarMunicipiosPorArribaYAbajo(municipiosPorAbajo, municipiosPorArriba);
    }
    public static void mostrarMediaPorDia(float[] temperaturaMediaDia){
        for (int i = 0; i < temperaturaMediaDia.length; i++) {
            System.out.printf("Dia %d: Temperatura Media %.2f\n", i + 1, temperaturaMediaDia[i]);
        }
    }
    public static void mostrarMediaPorMunicipio(float[] temperaturaMediaDia){
        for (int i = 0; i < temperaturaMediaDia.length; i++) {
            System.out.printf("Municipio %s: T. Media %.2f C\n", MUNICIPIOS[i], temperaturaMediaDia[i]);
        }
    }
    public static void mostrarMunicipiosPorArribaYAbajo(int[] municipiosPorAbajo, int[] municipiosPorArriba){
        System.out.printf("Municipio por arriba: ");
        for (int i = 0; i < municipiosPorArriba.length; i++) {
            if(municipiosPorArriba[i] != -1){
                System.out.printf(MUNICIPIOS[municipiosPorArriba[i]] + ", ");
            }
        }
        System.out.printf("\nMunicipio por abajo: ");
        for (int i = 0; i < municipiosPorAbajo.length; i++) {
            if(municipiosPorAbajo[i] != -1){
                System.out.printf(MUNICIPIOS[municipiosPorAbajo[i]] + ", ");
            }
            System.out.printf(MUNICIPIOS[municipiosPorAbajo[i]] + ", ");
        }
    }
    public static int temperaturaMediaSemanal(int i, int[][] temperaturas ){
        int contador = 0;
        for (int j = 0; j < temperaturas[i].length; j++) {
            contador += temperaturas[i][j];
        }
        return contador / 7;
    }
    public static float[] temperaturaMediaMunicipios(int[][] temperaturas){
        float contador = 0;
        float [] mediaMunicipio = new float[5];
        for (int i = 0; i < temperaturas.length; i++) {
            for (int j = 0; j < temperaturas[i].length; j++) {
                contador += temperaturas[i][j];
            }
            mediaMunicipio[i] = contador / 7;
            contador = 0;
        }
        return mediaMunicipio;
    }
    public static float[] temperaturaMediaDia(int[][] temperaturas){
        float contador = 0;
        float [] temperaturaMediaDia = new float[7];
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 5; j++) {
                contador += temperaturas[j][i];
            }
            temperaturaMediaDia[i] = contador / 5;
            contador = 0;
        }
        return temperaturaMediaDia;
    }
    public static int[] municiposPorEncimaDeLaMedia(int[] mediaPorZonas, float[] mediaMunicipios){
        int[] municipiosPorEncima = new int[5];
        int contador = 0;
        for (int i = 0; i < mediaPorZonas.length; i++) {
            if(mediaMunicipios[i] > mediaPorZonas[i]){
                municipiosPorEncima[contador] = i;
                contador += 1;
            } else {
                municipiosPorEncima[contador] = -1;
            }
        }
        return municipiosPorEncima;
    }
    public static int[] municiposPorAbajoDeLaMedia(int[] mediaPorZonas, float[] mediaMunicipios){
        int[] municipiosPorAbajo = new int[5];
        int contador = 0;
        for (int i = 0; i < mediaPorZonas.length; i++) {
            if(mediaMunicipios[i] < mediaPorZonas[i]){
                municipiosPorAbajo[contador] = i;
                contador += 1;
            } else {
                municipiosPorAbajo[contador] = -1;
            }
        }
        return municipiosPorAbajo;
    }
    public static int[] temperaturaMinimaDelMunicipio(int[][] temperaturas){
        int[] temperaturaMinimaDelMunicipio = new int[5];
        for (int i = 0; i < temperaturas.length; i++) {
            int contador = temperaturas[i][0];
            for (int j = 1; j < temperaturas[i].length; j++) {
                if(temperaturas[i][j] < contador){
                    contador = temperaturas[i][j];
                }
            }
            temperaturaMinimaDelMunicipio[i] = contador;
        }
        return temperaturaMinimaDelMunicipio;
    }
    public static int[] temperaturaMaximaDelMunicipio(int[][] temperaturas){
        int[] temperaturaMaximaDelMunicipio = new int[5];
        for (int i = 0; i < temperaturas.length; i++) {
            int contador = temperaturas[i][0];
            for (int j = 1; j < temperaturas[i].length; j++) {
                if(temperaturas[i][j] > contador){
                    contador = temperaturas[i][j];
                }
            }
            temperaturaMaximaDelMunicipio[i] = contador;
        }
        return temperaturaMaximaDelMunicipio;
    }

}
