import java.util.Scanner;

public class Activitat20 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Escriu un enter: ");
        int numero = teclado.nextInt();
        System.out.println("--------------");

        for (int i = 1; i <= 10; i++){
            System.out.println(numero + " x " + i + " = " + (i * numero));
        }
    }
}
