package activitat3;

public class Test {
    public static void main(String[] args) {

        Rectangle r1 = new Rectangle(100, 200);
        System.out.println("El area de r1 es: " + r1.obtenerArea());
        Rectangle r2 = new Rectangle(40, 100);
        System.out.println("El area de r2 es: " + r2.obtenerArea());
        Rectangle r3 = new Rectangle(80, 43);
        System.out.println("El area de r3 es: " + r3.obtenerArea());
        Rectangle r4 = new Rectangle(56, 90);
        System.out.println("El area de r4 es: " + r4.obtenerArea());
        Rectangle r5 = new Rectangle(100, 150);
        System.out.println("El area de r5 es: " + r5.obtenerArea());
        Rectangle r6 = new Rectangle(200, 120);
        System.out.println("El area de r6 es: " + r6.obtenerArea());
    }
}