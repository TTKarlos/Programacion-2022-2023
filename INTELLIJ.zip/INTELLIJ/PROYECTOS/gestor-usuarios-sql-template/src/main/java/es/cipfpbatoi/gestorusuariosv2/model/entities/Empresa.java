package es.cipfpbatoi.gestorusuariosv2.model.entities;

import java.time.LocalDate;

public class Empresa {
    private int id;
    private String name;
    private String adress;
    private String city;
    private String province;
    private String country;
    private LocalDate createdOn;
    private String nif;

    public Empresa(int id, String name, String adress, String city, String province, String country, LocalDate createdOn, String nif) {
        this.id = id;
        this.name = name;
        this.adress = adress;
        this.city = city;
        this.province = province;
        this.country = country;
        this.createdOn = createdOn;
        this.nif = nif;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAdress() {
        return adress;
    }

    public String getCity() {
        return city;
    }

    public String getProvince() {
        return province;
    }

    public String getCountry() {
        return country;
    }

    public LocalDate getCreatedOn() {
        return createdOn;
    }

    public String getNif() {
        return nif;
    }
}