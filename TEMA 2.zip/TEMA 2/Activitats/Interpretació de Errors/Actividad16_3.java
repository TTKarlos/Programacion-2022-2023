public class Actividad16_3 {

    /**
     * @Error: Hemd e possar un ";" cada vegada que acabes una linea.
     * @Tipus: Temps de compilació.
     **/

    public static void main(String[] args) {
        int term = 6;
        int initialAmount = 2000;
        float annualInterest = 0.0275f;
        float withHolding = 0.18f;

        float totalProfit = initialAmount*((annualInterest/12)*term);
        float totalWithHolding = totalProfit*withHolding;

        System.out.println("El dinero inicial es: " + initialAmount);
        System.out.println("Los beneficios generados son: " + totalProfit);
        System.out.println("Las retenciones aplicadas son: " + totalWithHolding);
        System.out.println("Total a Percibir: " + initialAmount + (totalProfit-totalWithHolding));
    }

}
