package activitat16;

public class Massa {

    private int precio;
    private String descripcion;
    private boolean rellenoDeQueso;

    public Massa(int precio, String descripcion, boolean rellenoDeQueso){
        this.precio = precio;
        this.descripcion = descripcion;
        this.rellenoDeQueso = rellenoDeQueso;
    }

    public Massa(){
        this.precio = 5;
        this.descripcion = "La masa más fina y deliciosa del mundo";
        this.rellenoDeQueso = false;
    }

    public void setRellenoDeQueso(boolean rellenoDeQueso) {
        this.rellenoDeQueso = rellenoDeQueso;
    }

    public int getPrecio() {
        if(rellenoDeQueso){
            this.precio = precio + 1;
            return precio;
        } else {
            return precio;
        }
    }


}
