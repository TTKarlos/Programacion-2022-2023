package activitat14;

public class TestPunto {
    public static void main(String[] args) {

        Punto punto1 = new Punto(0, 0);
        Punto punto2 = new Punto(5, 3);
        Punto punto3 = new Punto(2, -1);
        Punto punto4 = new Punto(3, 0);
        Punto punto5 = new Punto(4, 3);

        double distancia = punto1.getDistancia(punto5);
        System.out.printf("La distacia es de %.2f\n", distancia);
        System.out.println(punto1);
        System.out.println(punto2);
        System.out.println(punto3);
        System.out.println(punto4);
        System.out.println(punto5);
    }
}