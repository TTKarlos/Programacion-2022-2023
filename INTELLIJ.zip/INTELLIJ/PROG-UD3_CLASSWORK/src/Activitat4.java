import java.util.Scanner;

public class Activitat4 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Escriu una qualificació numerica: ");
        int qualificacio = teclado.nextInt();

        if (0 < qualificacio || qualificacio > 10){
            System.out.println("ERROR!");
        } else {
            switch (qualificacio) {
                case 0, 1, 2, 3:
                    System.out.println("MOLT DEFICIENT");
                case 4:
                    System.out.println("INSUFICIENT");
                    break;
                case 5:
                    System.out.println("SUFICIENT");
                    break;
                case 6:
                    System.out.println("BIEN");
                    break;
                case 7, 8:
                    System.out.println("NOTABLE");
                    break;
                case 9, 10:
                    System.out.println("EXELENT");
                    break;
        }




        }
    }
}
