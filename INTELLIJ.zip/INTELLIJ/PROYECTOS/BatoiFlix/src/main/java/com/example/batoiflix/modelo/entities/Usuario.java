package com.example.batoiflix.modelo.entities;

import com.example.batoiflix.modelo.enums.TipoUsuario;

public class Usuario {
    private int codigo;
    private String nombre;
    private String apellidos;
    private String email;
    private String contrasenya;
    private TipoUsuario tipoUsuario;

    public Usuario(int codigo, String nombre, String apellidos, String email, String contrasenya, TipoUsuario tipoUsuario) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.email = email;
        this.contrasenya = contrasenya;
        this.tipoUsuario = tipoUsuario;
    }

    public Usuario(String nombre, String apellidos, String email, String contrasenya, TipoUsuario tipoUsuario) {
        this.codigo = -1;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.email = email;
        this.contrasenya = contrasenya;
        this.tipoUsuario = tipoUsuario;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getEmail() {
        return email;
    }

    public String getContrasenya() {
        return contrasenya;
    }

    public TipoUsuario getTipoUsuario() {
        return tipoUsuario;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setContrasenya(String contrasenya) {
        this.contrasenya = contrasenya;
    }

    public void setTipoUsuario(TipoUsuario tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }
}