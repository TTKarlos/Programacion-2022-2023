package activitat13;

public abstract class MaterialPrestamo {
    private int codigoIdentificativo;
    private String titulo;
    private String autor;

    public MaterialPrestamo (int codigoIdentificativo, String titulo, String autor){
        this.codigoIdentificativo = codigoIdentificativo;
        this.titulo = titulo;
        this.autor = autor;
    }

    public String getAutor() {
        return autor;
    }

    public String getTitulo() {
        return titulo;
    }
}