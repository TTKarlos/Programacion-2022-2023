import java.util.Scanner;

public class Activitat3 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        int[] numero = new int[11];

        for (int numinteracio: numero){

            System.out.printf("Introdueix el numero %d: ", numinteracio);

            numero[numinteracio] = teclado.nextInt();
        }

        for(int numinteracio: numero){
            System.out.printf("Numero %d: %d\n", numinteracio, numero[numinteracio]);

        }
    }
}
