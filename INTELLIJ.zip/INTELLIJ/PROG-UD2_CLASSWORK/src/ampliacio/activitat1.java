package ampliacio;

import java.util.Scanner;

public class activitat1 {

    final static int SEGUNDOS_A_DIAS = 86400;
    final static int SEGUNDOS_A_HORAS = 3600;
    final static int SEGUNDOS_A_MINUTOS = 60;

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Introdueix el nombre de segons que han transcorregut? ");
        float segundos = teclado.nextFloat();

        double dias = segundos / SEGUNDOS_A_DIAS;
        double horas = (segundos % SEGUNDOS_A_DIAS) / SEGUNDOS_A_HORAS;
        double minutos = (segundos % SEGUNDOS_A_HORAS) / SEGUNDOS_A_MINUTOS;
        segundos = (segundos % SEGUNDOS_A_MINUTOS);

        System.out.printf(" dies: %.0f \n hores: %.0f \n minuts: %.0f \n segons: %.0f", dias, horas, minutos, segundos );

    }
}