package org.example.productos;

import org.example.Producto;

public class Entrante extends Producto {
    private int raciones;

    public Entrante(String nombre, String descripcion, float precioBase, float decuento, int raciones, float iva){
        super(nombre, descripcion, precioBase, decuento, iva);
        this.raciones = raciones;
    }
}