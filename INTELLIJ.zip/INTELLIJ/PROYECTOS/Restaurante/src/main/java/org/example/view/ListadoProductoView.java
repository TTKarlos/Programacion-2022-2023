package org.example.view;

import de.vandermeer.asciitable.AT_Row;
import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;
import org.example.GestorIO;
import org.example.Producto;
import org.example.productos.Bebida;
import org.example.productos.Entrante;
import org.example.productos.Montadito;
import java.util.ArrayList;

public class ListadoProductoView {
    private ArrayList<Producto> listaProductos;

    public ListadoProductoView(ArrayList<Producto> listaProductos){
        this.listaProductos = listaProductos;
        mostrarProductos();
    }

    public void mostrarProductos(){
        if(listaProductos.get(0) instanceof Bebida){
            mostrarTodosLasBebidas();
        } else if (listaProductos.get(0) instanceof Entrante){
            mostrarTodosLosEntrantes();
        } else if (listaProductos.get(0) instanceof Montadito){
            mostrarTodosLosMontaditos();
        } else {
            mostrarTodosLosPostres();
        }
    }

    private void mostrarTodosLosPostres(){
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow("Codigo", "Nombre", "Precio Base", "Precio PVP", "Caracteristicas");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < listaProductos.size(); i++) {
            table.addRule();
            row = table.addRow(listaProductos.get(i).getNombre(), listaProductos.get(i).getDescripcion(),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).getPrecioBase()),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).calcularElPrecioPVP()),
                    listaProductos.get(i).getCaracteristicas());
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.RIGHT);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.RIGHT);
            row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        }


        table.addRule();
        System.out.println(table.render(100));
    }

    private void mostrarTodosLosMontaditos(){
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow("Codigo", "Nombre", "Precio Base", "Precio PVP");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < listaProductos.size(); i++) {
            table.addRule();
            row = table.addRow(listaProductos.get(i).getNombre(), listaProductos.get(i).getDescripcion(),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).getPrecioBase()),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).calcularElPrecioPVP()));
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.RIGHT);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.RIGHT);
        }

        table.addRule();
        System.out.println(table.render(100));
    }

    private void mostrarTodosLasBebidas(){
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow("Codigo", "Nombre", "Precio Base", "Rellenable", "Precio PVP");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < listaProductos.size(); i++) {
            table.addRule();
            row = table.addRow(listaProductos.get(i).getNombre(), listaProductos.get(i).getDescripcion(),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).getPrecioBase()),
                    listaProductos.get(i).getEsRellenableEnFormato(),
                    GestorIO.tornarPreuEnFormato(listaProductos.get(i).calcularElPrecioPVP()));
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.RIGHT);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.RIGHT);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.RIGHT);
        }

        table.addRule();
        System.out.println(table.render(100));
    }

    private void mostrarTodosLosEntrantes(){
        AsciiTable table = new AsciiTable();
        AT_Row row;
        table.addRule();
        row = table.addRow("Codigo", "Nombre", "Precio Base", "Precio PVP");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < listaProductos.size(); i++) {
            table.addRule();
            row = table.addRow(listaProductos.get(i).getNombre(), listaProductos.get(i).getDescripcion(),
                    listaProductos.get(i).getPrecioBase() + "€", listaProductos.get(i).calcularElPrecioPVP());
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.RIGHT);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.RIGHT);
        }

        table.addRule();
        System.out.println(table.render(100));
    }
}