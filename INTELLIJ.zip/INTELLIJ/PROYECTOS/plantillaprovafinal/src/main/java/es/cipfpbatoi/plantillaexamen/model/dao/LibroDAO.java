package es.cipfpbatoi.plantillaexamen.model.dao;

import es.cipfpbatoi.plantillaexamen.model.dao.interfaces.LibroDAOInterface;
import es.cipfpbatoi.plantillaexamen.model.utils.database.MySQLConnection;
import es.cipfpbatoi.plantillaexamen.model.utils.enums.NivelEducativo;
import es.cipfpbatoi.plantillaexamen.model.utils.libro.Libro;
import es.cipfpbatoi.plantillaexamen.model.utils.libro.LibroAcademico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.sql.*;
import java.util.ArrayList;

@Service
public class LibroDAO implements LibroDAOInterface {
    @Autowired
    private final MySQLConnection mySQLConnection;

    public LibroDAO(@Autowired MySQLConnection mySQLConnection) {
        this.mySQLConnection = mySQLConnection;
    }

    @Override
    public boolean save(Libro libro) {
        return insert(libro);
    }

    @Override
    public boolean remove(Libro libro) {
        int afectedRows = 0;
        String sql = "DELETE FROM pedidos WHERE titulo = ?";
        try (Connection connection = mySQLConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(sql)){
            preparedStatement.setString(1, libro.getTitulo());
            afectedRows = preparedStatement.executeUpdate();
            return afectedRows > 0;
        } catch (SQLException e){
            throw new RuntimeException(e);
        }
    }

    @Override
    public ArrayList<Libro> findAllBuscador(String cadena) {
        ArrayList<Libro> libros = new ArrayList<>();

        try (
                Connection connection = mySQLConnection.getConnection();
                Statement statement = connection.createStatement();
        ){
            String sql = String.format("SELECT * FROM libros WHERE titulo LIKE = %s%%", cadena);
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()){
                libros.add(mapToResultset(resultSet));
            }

            return libros;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private boolean update(Libro libro){
        String sql = "UPDATE libros SET autor = ?, fechaPublicacion = ?, editorial_id = ?, type = ?, nivelEducativo = ? WHERE titulo = ?";

        try(
                Connection connection = mySQLConnection.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql)){

            preparedStatement.setString(6, libro.getTitulo());
            preparedStatement.setString(1, libro.getAutor());
            preparedStatement.setDate(2, Date.valueOf(libro.getFechaPublicacion()));
            preparedStatement.setInt(3, libro.getIdEditorial());
            preparedStatement.setString(4, getTypeFormat(libro));

            if(getTypeFormat(libro).equalsIgnoreCase("libro")){
                preparedStatement.setString(5, libro.getTitulo());
            } else {
                preparedStatement.setString(5, ((LibroAcademico) libro).getNivelEducativo().toString());
            }

            int comprobador = preparedStatement.executeUpdate();

            return comprobador > 0;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private boolean insert(Libro libro){
        String sql = "INSERT INTO libros (titulo, autor, fechaPublicacion, editorial_id, type, nivelEducativo) VALUE (?,?,?,?,?,?)";

        try(
                Connection connection = mySQLConnection.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql)){

            preparedStatement.setString(1, libro.getTitulo());
            preparedStatement.setString(2, libro.getAutor());
            preparedStatement.setDate(3, Date.valueOf(libro.getFechaPublicacion()));
            preparedStatement.setInt(4, libro.getIdEditorial());
            preparedStatement.setString(5, getTypeFormat(libro));

            if(getTypeFormat(libro).equalsIgnoreCase("libro")){
                preparedStatement.setString(6, libro.getTitulo());
            } else {
                preparedStatement.setString(6, ((LibroAcademico) libro).getNivelEducativo().toString());
            }

            int comprobador = preparedStatement.executeUpdate();

            return comprobador > 0;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }


    @Override
    public ArrayList<Libro> findAll() {
        ArrayList<Libro> libros = new ArrayList<>();

        try (
                Connection connection = mySQLConnection.getConnection();
                Statement statement = connection.createStatement();
        ){
            String sql = "SELECT * FROM libros";
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()){
                libros.add(mapToResultset(resultSet));
            }

            return libros;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    public Libro findByTitulo(String titulo) {
        try (
                Connection connection = mySQLConnection.getConnection();
                Statement statement = connection.createStatement();
        ){
            String sql = String.format("SELECT * FROM libros WHERE titulo LIKE = %s%%", titulo);
            ResultSet resultSet = statement.executeQuery(sql);

            if(resultSet.next()){
                return mapToResultset(resultSet);
            }

            return null;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private Libro mapToResultset(ResultSet resultSet) throws SQLException {
        String type = resultSet.getString("type");

        if(type.equalsIgnoreCase("libro")){
            return new Libro(resultSet.getString("titulo"), resultSet.getString("autor"),
                    resultSet.getDate("fechaPublicacion").toLocalDate(), resultSet.getInt("editorial_id"));
        } else {
            return new LibroAcademico(resultSet.getString("titulo"), resultSet.getString("autor"),
                    resultSet.getDate("fechaPublicacion").toLocalDate(), resultSet.getInt("editorial_id"),
                    getNivelEducativoFormat(resultSet.getString("nivelEducativo")));
        }
    }

    private NivelEducativo getNivelEducativoFormat(String texto){
        if(texto.equalsIgnoreCase("ESO")){
            return NivelEducativo.ESO;
        } else if (texto.equalsIgnoreCase("BACHILLERATO")) {
            return NivelEducativo.BACHILLERATO;
        } else {
            return NivelEducativo.FP;
        }
    }

    private String getTypeFormat(Libro libro){
        if(libro.getClass().getSimpleName().equalsIgnoreCase("libro")){
            return "LIBRO";
        } else {
            return "LIBRO_ACADEMICO";
        }
    }
}