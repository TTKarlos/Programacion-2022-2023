package prueba;

class B {
    public B() {
        System.out.println("constructor B");
    }
}