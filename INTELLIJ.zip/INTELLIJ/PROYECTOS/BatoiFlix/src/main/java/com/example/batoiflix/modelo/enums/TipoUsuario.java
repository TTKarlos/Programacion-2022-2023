package com.example.batoiflix.modelo.enums;

public enum TipoUsuario {
    USUARIO,ADMIN
}