public class Tablero {
    final static int INDICE_INICIAL = 0;
    public static int DIMENSIONES_DEL_TABLERO = 3;
    private EstadoCasilla[][] tablero;
    private Icono icono;

    public Tablero(Icono icono){
        this.icono = icono;
        tablero = new EstadoCasilla[DIMENSIONES_DEL_TABLERO][DIMENSIONES_DEL_TABLERO];
    }

    public EstadoCasilla[][] getTablero() {
        return tablero;
    }

    public void vaciar(){
        for(int i = INDICE_INICIAL; i < tablero.length; i++){
            for (int j = INDICE_INICIAL; j < tablero.length; j++) {
                tablero[i][j] = EstadoCasilla.FICHA_VACIA;
            }
        }
    }

    public void mostrar(){
        for(int i = INDICE_INICIAL; i <= tablero.length; i++){
            for(int j = INDICE_INICIAL; j < tablero[INDICE_INICIAL].length; j++){
                System.out.print("+----");
            }
            System.out.println("+");

            if(i != tablero.length){
                for (int j = INDICE_INICIAL; j < tablero[INDICE_INICIAL].length; j++){
                    System.out.print("|" + icono.obtenerSimbolo(tablero[i][j]));
                }

                System.out.println("|");
            }
        }
    }

    public boolean isOcupada(Coordenada coordenada){
        return tablero[coordenada.getFila()][coordenada.getColumna()].equals(EstadoCasilla.FICHA_VACIA);
    }

    public boolean isOcupada(Coordenada coordenada, EstadoCasilla estadoCasilla){
        return tablero[coordenada.getFila()][coordenada.getColumna()].equals(estadoCasilla);
    }

    public void ponerFicha(Coordenada casilla, EstadoCasilla estadoCasilla){
        this.tablero[casilla.getFila()][casilla.getColumna()] = estadoCasilla;
    }

    public boolean estaLleno(){
        for(int i = INDICE_INICIAL; i < tablero.length; i++){
            for (int j = INDICE_INICIAL; j < tablero[i].length; j++) {
                if(tablero[i][j].equals(EstadoCasilla.FICHA_VACIA)){
                    return false;
                }
            }
        }

        return true;
    }

    public boolean hayTresEnRaya(Jugador jugador){
        return (hayTresEnRayaEnJugador(jugador.getEstadoCasilla())) ||
                hayTresEnRayaEnJugador(jugador.getEstadoCasilla());
    }

    private boolean hayTresEnRayaEnJugador(EstadoCasilla estadoCasilla){
        return hayTresEnRayaEnUnaFila(estadoCasilla) || hayTresEnRayaEnUnaColumna(estadoCasilla) ||
                hayTresEnRayaEnLaDiagonal(estadoCasilla) || hayTresEnRayaEnLaSubdiagonal(estadoCasilla);
    }

    private boolean hayTresEnRayaEnUnaFila(EstadoCasilla estadoCasilla){
        int contador = INDICE_INICIAL;
        for (int i = INDICE_INICIAL; i < tablero.length; i++){
            for (int j = INDICE_INICIAL; j < tablero[i].length; j++) {
                if(tablero[i][j].equals(estadoCasilla)){
                    contador++;
                }
            }
            if(contador == DIMENSIONES_DEL_TABLERO){
                return true;
            }

            contador = INDICE_INICIAL;
        }

        return false;
    }

    private boolean hayTresEnRayaEnUnaColumna(EstadoCasilla estadoCasilla){
        int contador = INDICE_INICIAL;
        for (int i = INDICE_INICIAL; i < tablero.length; i++){
            for (int j = INDICE_INICIAL; j < tablero[i].length; j++) {
                if(tablero[j][i].equals(estadoCasilla)){
                    contador++;
                }
            }

            if(contador == DIMENSIONES_DEL_TABLERO){
                return true;
            }

            contador = INDICE_INICIAL;
        }

        return false;
    }

    private boolean hayTresEnRayaEnLaDiagonal(EstadoCasilla estadoCasilla){
        int indice = INDICE_INICIAL;
        int contador = INDICE_INICIAL;
        for(int i = INDICE_INICIAL; i < tablero.length; i++){
            if(tablero[i][indice].equals(estadoCasilla)){
                contador++;
            }

            indice++;

            if(contador == DIMENSIONES_DEL_TABLERO){
                return true;
            }
        }

        return false;
    }

    private boolean hayTresEnRayaEnLaSubdiagonal(EstadoCasilla estadoCasilla){
        int indice = tablero.length - 1;
        int contador = INDICE_INICIAL;
        for(int i = INDICE_INICIAL; i < tablero.length; i++){
            if(tablero[i][indice].equals(estadoCasilla)){
                contador++;
            }

            indice--;

            if(contador == DIMENSIONES_DEL_TABLERO){
                return true;
            }
        }

        return false;
    }
}