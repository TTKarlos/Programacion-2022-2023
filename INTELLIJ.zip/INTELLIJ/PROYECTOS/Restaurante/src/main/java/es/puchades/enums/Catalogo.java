package es.puchades.enums;

import es.puchades.productos.tipos.Entrante;
import es.puchades.productos.tipos.Montadito;
import es.puchades.productos.tipos.Postre;
import es.puchades.productos.Producto;
import es.puchades.productos.tipos.Bebida;
import java.util.ArrayList;

public class Catalogo {
    private ArrayList<Producto> listaProductos;

    public Catalogo(){
        inicializar();
    }

    public Producto getProducto(String codProducto, Class tipo){
        Producto productoBuscado = new Producto(codProducto);
        ArrayList<Producto> listaDeProductoSeleccionado = getListaProductos(tipo);
        int posicionProducto = listaDeProductoSeleccionado.indexOf(productoBuscado);

        if (posicionProducto >= 0) {
            return listaDeProductoSeleccionado.get(posicionProducto);
        } else {
            return null;
        }
    }

    public ArrayList<Producto> getListaProductos(Class tipo){
        ArrayList<Producto> listaProductosSeleccionados = new ArrayList<>();

        for (int i = 0; i < listaProductos.size(); i++) {
            if(listaProductos.get(i).getClass() == tipo){
                listaProductosSeleccionados.add(listaProductos.get(i));
            }
        }

        return listaProductosSeleccionados;
    }

    private void inicializar() {
        this.listaProductos =new ArrayList<>();
        this.listaProductos.add(new Entrante("e1", "Patatas 4 quesos", 1.38f,0, 2, 21));
        this.listaProductos.add(new Entrante("e2", "Bolas de pollo", 1.38f,0, 1, 21));
        this.listaProductos.add(new Entrante("e3", "Aceitunas", 1.38f,0, 1, 21));
        this.listaProductos.add(new Entrante("e4", "Nachos", 1.38f,0, 1, 21));
        this.listaProductos.add(new Entrante("e5", "Ensalada de la casa", 1.38f,0, 1, 21));
        this.listaProductos.add(new Entrante("e6", "Bolas de Queso", 1.38f,0, 1, 21));
        this.listaProductos.add(new Entrante("e7", "Alitas de pollo (mini)", 1.38f,0, 2, 21));
        this.listaProductos.add(new Entrante("e8", "Alitas de pollo – (super)", 1.38f,0, 4, 21));
        this.listaProductos.add(new Entrante("e9", "Patatas Fritas", 1.38f,0, 2, 21));
        this.listaProductos.add(new Entrante("e10", "Patatas Fritas (Tamaño Maxi)", 1.38f,0, 4, 21));
        this.listaProductos.add(new Bebida("b1", "Coca-Cola 33cl", 1.38f, 0, 21, TamanyoDeBebida.PEQUENYA, false));
        this.listaProductos.add(new Bebida("b2", "Coca-Cola 1l", 2, 25, 21, TamanyoDeBebida.GRANDE, false));
        this.listaProductos.add(new Bebida("b3", "Agua", 1.38f, 0, 21, TamanyoDeBebida.PEQUENYA, false));
        this.listaProductos.add(new Bebida("b4", "Fanta Limón", 1.38f, 0, 21, TamanyoDeBebida.PEQUENYA, false));
        this.listaProductos.add(new Bebida("b5", "Fanta Naranja", 1.38f, 0, 21, TamanyoDeBebida.PEQUENYA, false));
        this.listaProductos.add(new Bebida("b6", "Cerveza bote 33cl", 1.38f, 0, 21, TamanyoDeBebida.PEQUENYA, false));
        this.listaProductos.add(new Bebida("b7", "Cerveza caña", 1.38f, 0, 21, TamanyoDeBebida.MEDIANA, false));
        this.listaProductos.add(new Bebida("b8", "Cerveza Jarra", 6, 10, 21, TamanyoDeBebida.GRANDE, false));
        this.listaProductos.add(new Bebida("b9", "Cerveza Jarra infinita (Promoción)", 10, 5, 21, TamanyoDeBebida.GRANDE, true));
        this.listaProductos.add(new Montadito("m1", "lechuga, tomate y mayonesa", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m2", "HUEVO DURO lechuga, tomate y mayonesa", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m3", "VEGETAL CON QUESO lechuga, tomate y queso", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m4", "Burger, bacon ahumado, cebolla crujiente y alioli", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m5", "Pollo, bacon ahumado y salsa brava", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m6", "CUATRO QUESOS: Queso ibérico, queso brie, queso de cabra y crema de queso", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m7", "CAPRESE: Jamón gran reserva, queso mozzarella, tomate y pesto", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m8", "Pulled pork y guacamole", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m9", "PULLED PORK y queso brie", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m10", "PULLED PORK y queso brie", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m11", "FILETE RUSO, cebolla caramelizada y salsa de queso cheddar", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m12", "SALMÓN AHUMADO y crema de queso", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m13", "CARNE MECHADA DESHILACHADA y cebolla crujiente", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m14", "Pollo kebab, cebolla, pimiento verde y mayonesa", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m15", "CARRILLERA AL VINO TINTO y queso ibérico", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m16", "QUESO IBÉRICO, tortilla de patatas y mayonesa", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m17", "ALBÓNDIGAS y salsa BBQ", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m18", "Pollo, cebolla caramelizada y mayonesa trufada", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m19", "CHISTORRA, bacon ahumado y salsa brava", 1.38f, 0, 21));
        this.listaProductos.add(new Montadito("m20", "Tortilla de patatas", 1.38f, 0, 21));
        this.listaProductos.add(new Postre("p1", "Pastel de Queso", 1, 0, 21, false, true));
        this.listaProductos.add(new Postre("p2", "Pastel de Chocolate", 1,0, 21, false, false));
        this.listaProductos.add(new Postre("p3", "Helado de Chocolate", 1,0, 21, true, false));
        this.listaProductos.add(new Postre("p4", "Helado Vainilla", 1, 0, 21, true, false));
        this.listaProductos.add(new Postre("p5", "Helado Limón", 1,0, 21, true, true));
        this.listaProductos.add(new Postre("p6", "Helado Fresa", 1,0, 21, true, true));
    }
}