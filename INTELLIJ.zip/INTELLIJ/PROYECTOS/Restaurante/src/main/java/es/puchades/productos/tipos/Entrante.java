package es.puchades.productos.tipos;

import es.puchades.productos.Producto;

public class Entrante extends Producto {
    private int raciones;

    public Entrante(String nombre, String descripcion, float precioBase, float decuento, int raciones, float iva){
        super(nombre, descripcion, precioBase, decuento, iva);
        this.raciones = raciones;
    }
}