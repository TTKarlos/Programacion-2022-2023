package ActivitatsDeRepas;

import java.util.Scanner;

public class HaciendoInventario {
    public static void main(String[] args) {

        String producto1 = comprovarParaula();
        String producto2 = comprovarParaula();
        String producto3 = comprovarParaula();
        String producto4 = comprovarParaula();

        contadorDeProuctos(producto1, producto2, producto3, producto4);

    }

    public static String comprovarParaula(){

        Scanner teclado = new Scanner(System.in);

        do{
            String paraula = teclado.next();

            if (paraula.length() < 20){
                return paraula;
            } else {
                System.out.print("Máximo 20 letras: ");
            }

        } while(true);

        return ;
    }

    public static int contadorDeProuctos(String producto1, String producto2, String producto3, String producto4){

        if(producto1.equals(producto2)){

        }
    }
}
