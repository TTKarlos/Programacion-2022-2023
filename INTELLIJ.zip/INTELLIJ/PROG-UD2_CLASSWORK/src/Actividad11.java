import java.util.Scanner;

public class Actividad11 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("Quantes monedes de 2 céntims tens:");
        int num1= teclado.nextInt();

        System.out.println("Quantes monedes de 5 céntims tens:");
        int num2= teclado.nextInt();

        System.out.println("Quantes monedes de 10 céntims tens:");
        int num3= teclado.nextInt();

        System.out.println("Quantes monedes de 20 céntims tens:");
        int num4= teclado.nextInt();

        System.out.println("Quantes monedes de 50 céntims tens:");
        int num5= teclado.nextInt();

        System.out.println("Quantes monedes de 1 euros tens:");
        int num6= teclado.nextInt();

        System.out.println("Quantes monedes de 2 euros tens:");
        int num7= teclado.nextInt();

        int centims = (num1*2+num2*5+num3*10+num4*20+num5*50);
        int euros = (num6+num7*2);

        float eurosTotal = (centims/100);

        float eurosTotal1 = eurosTotal + euros;
        float centimsTotal = (centims-(eurosTotal*100));

        System.out.println("Tens " + eurosTotal1 + " euros y " + centimsTotal + " centims " );

    }
}