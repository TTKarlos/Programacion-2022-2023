package entities.menu.opciones;

import entities.Taller;

public class OpciónRecepcionarVehículo extends OpcionesTaller {
    protected Taller taller;

    public OpciónRecepcionarVehículo(Taller taller) {
        super("Recepcionar Vehículo", taller);
        this.taller = taller;
    }

    @Override
    public void ejecutar() {
        taller.recepcionarVehiculo();
    }
}