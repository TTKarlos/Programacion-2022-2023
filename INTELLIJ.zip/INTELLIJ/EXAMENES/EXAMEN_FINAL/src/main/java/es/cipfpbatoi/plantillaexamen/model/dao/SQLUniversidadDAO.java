package es.cipfpbatoi.plantillaexamen.model.dao;

import es.cipfpbatoi.plantillaexamen.exceptions.NotFoundException;
import es.cipfpbatoi.plantillaexamen.model.dao.interfices.SQLUniversidadDAOInterfice;
import es.cipfpbatoi.plantillaexamen.utils.Universidad;
import es.cipfpbatoi.plantillaexamen.utils.database.MySQLConnection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

@Service
public class SQLUniversidadDAO implements SQLUniversidadDAOInterfice {
    @Autowired
    MySQLConnection mySQLConnection;
    public SQLUniversidadDAO(@Autowired MySQLConnection mySQLConnection){
        this.mySQLConnection = mySQLConnection;
    }

    @Override
    public Universidad findById(int id) throws NotFoundException{
        Universidad universidad = getById(id);

        if(universidad == null){
            throw new NotFoundException("La universidad con el id " + id + " no existe.");
        }

        return universidad;
    }

    private Universidad getById(int id){
        try(
                Connection connection = mySQLConnection.getConnection();
                Statement statement = connection.createStatement()){
            String sql = "SELECT * FROM universidades WHERE cod = " + id;
            ResultSet resultSet = statement.executeQuery(sql);

            if(resultSet.next()){
                return mapToResultset(resultSet);
            }

            return null;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    public ArrayList<Universidad> findAll(){
        ArrayList<Universidad> universidads = new ArrayList<>();

        try(
                Connection connection = mySQLConnection.getConnection();
                Statement statement = connection.createStatement()
        ) {
            String sql = "SELECT * FROM universidades";
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()){
                universidads.add(mapToResultset(resultSet));

            }
            return universidads;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public ArrayList<Universidad> findAllBuscador(String searchField) {
        ArrayList<Universidad> universidads = new ArrayList<>();

        try(
                Connection connection = mySQLConnection.getConnection();
                Statement statement = connection.createStatement()
        ) {
            String sql = String.format("SELECT * FROM universidades WHERE nombre LIKE '%s%%' ", searchField);
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()){
                universidads.add(mapToResultset(resultSet));

            }
            return universidads;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private Universidad mapToResultset(ResultSet resultSet){
        try {
            return new Universidad(resultSet.getInt("cod"), resultSet.getString("nombre"));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}