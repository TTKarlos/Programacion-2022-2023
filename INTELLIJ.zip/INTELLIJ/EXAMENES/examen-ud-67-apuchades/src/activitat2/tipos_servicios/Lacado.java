package activitat2.tipos_servicios;

import activitat2.Servicio;
import activitat2.enums.TiposPintura;

public class Lacado extends Servicio {
    final static int PRECIO_BASE = 120;
    final static int METROS_CUADRADOS_MINIMOS = 5;
    final static int PRECIO_SI_ES_MENOS_DE_5_M2 = 50;
    final static int PRECIO_SI_ES_MAS_DE_5_M2 = 70;
    private int numPuertas;
    private int numVentanas;

    public Lacado(int numIdentifiacion, String direccion, int numMetrosCuadrados, int numDiasParaFinalizar,
                  float precioDeMateriales, int numPuertas, int numVentanas) {
        super(numIdentifiacion, direccion, numMetrosCuadrados, numDiasParaFinalizar, 1,
                precioDeMateriales);
        this.numPuertas = numPuertas;
        this.numVentanas = numVentanas;
    }

    public double calcularCosteTotal(){
        double precioTotal = super.calcularCosteTotal();

        if(getNumMetrosCuadrados() < METROS_CUADRADOS_MINIMOS){
            precioTotal += getNumDiasParaFinalizar() * (getNumDeOperariosAsigandos() * PRECIO_SI_ES_MENOS_DE_5_M2);
        } else {
            precioTotal += getNumDiasParaFinalizar() * (getNumDeOperariosAsigandos() * PRECIO_SI_ES_MAS_DE_5_M2);
        }

        precioTotal += numPuertas * 90;
        precioTotal += numVentanas * 60;
        precioTotal += PRECIO_BASE;

        return precioTotal;
    }

    @Override
    public String toString() {
        return "Lacado de " + numPuertas + " puertas y " + numVentanas + " ventanas con un total " + super.toString();
    }
}
