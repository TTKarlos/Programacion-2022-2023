package es.puchades;

import es.puchades.enums.Catalogo;
import es.puchades.menus.Menu;
import es.puchades.menus.opciones.opcionesRestaurante.*;

public class App20Montaditos {
    final static String TITULO_MENU = "==============================================\n" + GestorIO.COLOR_AZUL +
            "=== Bienvenido al bar de los 20 Montaditos ===" + GestorIO.RESET_COLOR +
            "\n==============================================";
    public static void main(String[] args) {
        Catalogo catalogo = new Catalogo();
        Cambrer cambrer = new Cambrer(catalogo);
        Restaurante restaurante = new Restaurante(cambrer);

        Menu menuRestaurante = new Menu(TITULO_MENU);
        menuRestaurante.anyadir(new NuevoPedido(restaurante));
        menuRestaurante.anyadir(new MostrarPedidosOpcion(restaurante));
        menuRestaurante.anyadir(new VisualizarOrdenOpcion(restaurante));
        menuRestaurante.anyadir(new PrepararPedidoOpcion(restaurante));
        menuRestaurante.anyadir(new CancelarPedidoOpcion(restaurante));
        menuRestaurante.anyadir(new OpcionSalir());
        menuRestaurante.ejecutar();
    }
}