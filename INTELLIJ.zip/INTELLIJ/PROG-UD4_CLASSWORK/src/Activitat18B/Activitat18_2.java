package Activitat18B;

import java.util.Scanner;

public class Activitat18_2 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduzca una palabra o frase: ");
        String frase = teclado.nextLine();

        numVocales(frase);
    }

    public static void numVocales (String frase){
        int contador = 0;

        for (int i = 0; i <= frase.length() - 1; i++){

            String lletra = String.valueOf(frase.charAt(i));

            if (lletra.equalsIgnoreCase("a") || lletra.equalsIgnoreCase("e") ||
                    lletra.equalsIgnoreCase("i") || lletra.equalsIgnoreCase("o") ||
                    lletra.equalsIgnoreCase("u")){
                contador++;
            }
        }
        System.out.printf("La palabra o frase contiene %d vocales.\n", contador);
    }
}