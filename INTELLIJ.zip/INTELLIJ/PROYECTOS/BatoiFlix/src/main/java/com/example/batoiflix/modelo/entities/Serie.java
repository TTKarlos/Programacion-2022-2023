package com.example.batoiflix.modelo.entities;

import com.example.batoiflix.modelo.enums.Calificacion;
import com.example.batoiflix.modelo.enums.Genero;
import java.time.LocalDate;
import java.util.ArrayList;

public class Serie extends Produccion {
    private ArrayList<Temporada> temporadas;

    public Serie(int id, String titulo, Calificacion calificacion, LocalDate fechaLanzamiento, int duracion,
                 ArrayList<Genero> genero, Director director, ArrayList<Actores> actores, String guion, String portada,
                 Productor productor, String web, ArrayList<Temporada> temporadas) {
        super(id, titulo, calificacion, fechaLanzamiento, duracion, genero, director, actores, guion, portada, productor, web);
        this.temporadas = temporadas;
    }
    public Serie(int id, String titulo, Calificacion calificacion, LocalDate fechaLanzamiento, int duracion,
                 ArrayList<Genero> genero, Director director, ArrayList<Actores> actores, String guion, String portada,
                 Productor productor, String web) {
        super(id, titulo, calificacion, fechaLanzamiento, duracion, genero, director, actores, guion, portada, productor, web);
    }
}