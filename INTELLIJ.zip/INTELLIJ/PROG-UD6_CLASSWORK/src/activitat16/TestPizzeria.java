package activitat16;

public class TestPizzeria {
    public static void main(String[] args) {
//Ingredientes
        Ingrediente tomate = new Ingrediente("tomate");
        Ingrediente baseQueso = new Ingrediente("base cheese");
        Ingrediente jamonYork = new Ingrediente("york Ham");
        Ingrediente bacon = new Ingrediente("york Ham");
        Ingrediente queso = new Ingrediente("york Ham");
        Ingrediente pinya = new Ingrediente("york Ham");

//Fabricación pizza prosciutto
        Pizza prosciutto = new Pizza("prosciutto", tomate, baseQueso);
        prosciutto.anyadirIngrediente(jamonYork);
        System.out.println("El precio de una pizza prosciutto es de " +
                prosciutto.getPrecio());

//Creación de un pedido
        Pizza[] pedido1 = {
                prosciutto,
                new Pizza("prosciutto con jamon", tomate, jamonYork),
                new Pizza("margarita", tomate, baseQueso),
        };
        precioTotalPedido(pedido1);

//Creación de un pedido
        Pizza[] pedido2 = {
                new Pizza("Hawaiana", tomate, jamonYork),
                new Pizza("barbacoa", tomate, bacon),
        };
        pedido2[0].anyadirIngrediente(pinya);
        precioTotalPedido(pedido2);

//Creación de un pedido
        Pizza[] pedido3 = {
                new Pizza("queso", baseQueso, queso),
                new Pizza("barbacoa", tomate, bacon),
        };
        pedido3[0].setBordeRelleno(true);
        precioTotalPedido(pedido3);
    }

    public static void precioTotalPedido(Pizza[] pedido){

        int precioTotal = 0;

        for(int i = 0; i < pedido.length; i++){
            precioTotal += pedido[i].getPrecio();
        }

        System.out.printf("El precio total del pedido es de %d€\n", precioTotal);
    }
}