import org.w3c.dom.css.CSS2Properties;

public class Activitat16 {

    public static void main(String[] args) {

        int comtador = 1;
        int acomulador = 0;

        while (comtador < 1000){
            System.out.print(comtador + " + ");
            acomulador += comtador;
            comtador++;
        }
        System.out.print("1000 = " + (acomulador + 1000));
    }
}
