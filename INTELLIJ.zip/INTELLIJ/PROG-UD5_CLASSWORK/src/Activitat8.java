public class Activitat8 {
    public static void main(String[] args) {

        int[] arrayA ={10, 20, 30, 40, 50, 0};
        int[] arrayB ={60, 70, 80, 90, 100};
        int[] arrayC =new int[5];

        char[] pepe = new char[10];

        int sumaArrayAB = arrayA[3] + arrayB[4];
        int a = sumaArrayAB;
        int b = arrayA[1];
        arrayC[1] = a + b;
        //Todo for
        arrayC[0] = 1;
        arrayC[0] = arrayA[0] * arrayA[1] * arrayA[2] * arrayA[3] * arrayA[4];

        //TODO for
        arrayC[0] = 0;
        arrayC[2] = arrayA[0] + arrayA[1] + arrayA[2] + arrayA[3] + arrayA[4];
        int c = arrayB[0];
        int d = arrayA[arrayA.length - 1];
        arrayC[4] = Math.max(c, d);

        int entero = 20;

        visualizarArrayFor(arrayA);
        visualizarArrayForEach(arrayA);
        visualizarExtremos(arrayA);
        visualizarMultiplos(arrayA, entero);
        visualizarMaximo(arrayA);
        visualizarMinimo(arrayA);
    }

    public static void visualizarArrayFor(int[] array){

        System.out.println("Visualizar array con For: ");
        for(int i = 0; i < array.length; i++){
            System.out.println(array[i]);
        }
    }

    public static void visualizarArrayForEach(int[] array){

        System.out.println("Visualizar array con ForEach: ");
        for(int valorNum: array){
            System.out.println(valorNum);
        }
    }

    public static void visualizarExtremos(int [] array){

        System.out.printf("Primer elemento: %d\n", array[0]);
        System.out.printf("Primer elemento: %d\n", array[array.length - 1]);
    }

    public static int[] obtenerCopia(int[] cadena){
        int[] cadenaCopiada = new int[cadena.length];
        for (int i = 0; i < cadena.length; i++){
            cadenaCopiada[i] = cadena[i];
        }
        return cadenaCopiada;
    }

    public static void visualizarMultiplos (int [] array, int entero){

        System.out.printf("Visualizar multiplos de %d: ", entero);

        for(int i = 0; i < array.length; i++){
            if(array[i] % entero == 0) {
                System.out.print(array[i] + " ");
            }
        }
    }

    public static void  visualizarMaximo(int[] array){

        System.out.print("\nVisualizar máximo: ");

        int numeroMaximo = array[0];

        for (int i = 1; i < array.length; i++){

            if(numeroMaximo < array[i]){
                numeroMaximo = array[i];
            }
        }

        System.out.println(numeroMaximo);
    }

    public static void  visualizarMinimo(int[] array){

        System.out.print("Visualizar mínimo:  ");

        int numeroMinimo = array[0];

        for (int i = 1; i < array.length; i++){

            if(numeroMinimo > array[i]){
                numeroMinimo = array[i];
            }
        }

        System.out.println(numeroMinimo);
    }
}