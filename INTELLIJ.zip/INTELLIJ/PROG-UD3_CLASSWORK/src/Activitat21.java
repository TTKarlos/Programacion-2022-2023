public class Activitat21 {

    public static void main(String[] args) {


        int multiplesDe5 = 0;
        int multiplesDe2 = 0;

        for (int i = 1; i <=100; i++){
            if (i % 2 == 0){
                multiplesDe2 = multiplesDe2 + 1;
            }
            if (i % 5 == 0){
                multiplesDe5 = multiplesDe5 + 1;
            }
        }

        System.out.println("Multiples de 2: " + multiplesDe2 + "\nMultiples de 5: " + multiplesDe5);
    }
}
