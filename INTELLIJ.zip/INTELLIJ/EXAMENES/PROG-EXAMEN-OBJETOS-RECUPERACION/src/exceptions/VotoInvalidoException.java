package exceptions;

public class VotoInvalidoException extends RuntimeException{
    public VotoInvalidoException(String mensaje){
        super(mensaje);
    }
}