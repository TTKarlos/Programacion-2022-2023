package es.cipfpbatoi.plantillaexamen.controllers;

import es.cipfpbatoi.plantillaexamen.utils.Trabajador;
import es.cipfpbatoi.plantillaexamen.utils.repositorios.TrabajadoresRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

@Controller
public class Parte3Controller {
    @Autowired
    private TrabajadoresRepositorio trabajadoresRepositorio;

    private static String RUTA_DELARCHIVO = "/databases/trabajadores.txt";
    private File file = new File(getClass().getResource(RUTA_DELARCHIVO).getFile());

    @GetMapping("/buscador")
    @ResponseBody
    public String buscador(@RequestParam String buscador){
        add(buscador, trabajadoresRepositorio.findAllBuscador(buscador));

        return "<strong>A sido guardado correctamente.</strong)>";
    }

    public void add(String cadena, ArrayList<Trabajador> trabajadores){
        try (BufferedWriter bufferedWriter = getWriter(true)){
            bufferedWriter.newLine();
            String register = mapToRegister(cadena, trabajadores);
            bufferedWriter.write(register);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    private BufferedWriter getWriter(boolean append) throws IOException{
        FileWriter fileWriter = new FileWriter(this.file, append);
        return new BufferedWriter(fileWriter);
    }

    private String mapToRegister(String cadenaBusqueda, ArrayList<Trabajador> trabajadores){
        StringBuilder cadena = new StringBuilder();
        cadena.append("Busqueda de la cadena \"" + cadenaBusqueda + "\"\n");

        if(!trabajadores.isEmpty()){
            for (int i = 0; i < trabajadores.size(); i++) {
                cadena.append(String.format("   - Trabajador %s de la universidad %s\n", trabajadores.get(i).getNombre(),
                        trabajadores.get(i).getUniversdad().getNombre()));
            }
        }

        cadena.append("Busqueda realizada en ");
        DateTimeFormatter dateTimeFormatterFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter dateTimeFormatterHora = DateTimeFormatter.ofPattern("HH:mm");
        cadena.append(LocalDateTime.now().format(dateTimeFormatterFecha));
        cadena.append(" a las ");
        cadena.append(LocalDateTime.now().format(dateTimeFormatterHora) + "\n");

        return String.valueOf(cadena);
    }
}