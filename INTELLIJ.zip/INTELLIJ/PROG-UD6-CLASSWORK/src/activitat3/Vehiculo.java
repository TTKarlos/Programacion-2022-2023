package activitat3;

public class Vehiculo {

    private int velocitat;
    private int rodes;

    public Vehiculo(int velocitat){
        this.velocitat = velocitat;
        this.rodes = 4;
    }

    protected void acelerar(){
        this.velocitat += 10;
    }

    public void frenar(){
        this.velocitat = 0;
    }
}
