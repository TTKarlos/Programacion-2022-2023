package tienda_de_electrodomesticos;

import activitat11.Empleado;

public class Electrodomesticos implements Conectable {
    final static String[] colorDisponibles = {"blanco", "negro", "rojo", "azul", "gris"};
    final static String[] tiposDeConsumoEnergetico = {"A", "B", "C", "D", "E", "F"};

    private String marca;
    private String modelo;
    private String consumoEnergetico;
    private String color;
    private int peso;
    private String codigo;
    private float precioBase;
    private int numeroDeUnidades;
    private boolean estaEncendido;

    public Electrodomesticos(String marca, String modelo, String codigo){
        this.marca = marca;
        this.modelo = modelo;
        this.consumoEnergetico = "F";
        this.color = "blanco";
        this.peso = 5;
        this.codigo = codigo;
        this.precioBase = 100;
        this.numeroDeUnidades = 0;
        this.estaEncendido = false;
    }

    public boolean getEstaEncendido() {
        return estaEncendido;
    }

    public int getNumeroDeUnidades() {
        return numeroDeUnidades;
    }

    public void setNumeroDeUnidades(int numeroDeUnidades) {
        this.numeroDeUnidades = numeroDeUnidades;
    }

    public float obtenerPrecioVenta(){
        float precioVenta = precioBase;

        switch (consumoEnergetico){
            case "A" -> precioVenta += 100;
            case "B" -> precioVenta += 80;
            case "C" -> precioVenta += 60;
            case "D" -> precioVenta += 50;
            case "E" -> precioVenta += 30;
            case "F" -> precioVenta += 10;
        }

        return precioVenta;
    }

    @Override
    public String toString() {
        return "Marca: " + marca + ", Modelo: " + modelo + ", Tipo Consumo: " + consumoEnergetico + ", Color: " +
                color + ", Precio: " + precioBase;
    }

    @Override
    public void encender() {
        this.estaEncendido = true;
    }

    @Override
    public void apagar() {
        this.estaEncendido = false;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Electrodomesticos)){
            return false;
        }

        Electrodomesticos electrodomesticos = (Electrodomesticos) obj;
        return codigo.equalsIgnoreCase(electrodomesticos.codigo);
    }
}