package Activitat18B;

import java.util.Scanner;

public class Activitat18_4 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduzca una frase: ");
        String frase = teclado.nextLine();

        System.out.printf("Resultado: %s", senseEspais(frase));

    }

    public static String senseEspais(String frase){

        for (int i = 0; i <= frase.length() - 1; i++){

            String posicio = String.valueOf(frase.charAt(i));

            if (posicio.equalsIgnoreCase(" ")){
                frase = frase.replace(" ","");
            }
        }
        return frase;
    }
}