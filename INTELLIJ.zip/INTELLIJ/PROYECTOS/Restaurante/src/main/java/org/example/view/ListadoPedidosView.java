package org.example.view;

import de.vandermeer.asciitable.AT_Row;
import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;
import org.example.Pedido;
import java.util.ArrayList;

public class ListadoPedidosView {
    private ArrayList<Pedido> listaPedidos;
    private boolean conPedidosServidos;

    public ListadoPedidosView(ArrayList<Pedido> listaPedidos, boolean conPedidosServidos){
        this.listaPedidos = listaPedidos;
        this.conPedidosServidos = conPedidosServidos;
    }

    @Override
    public String toString() {
        if (conPedidosServidos){
            return getTablaDePedidos();
        } else {
            return getTablaPedidosNoServidos();
        }
    }

    private String getTablaDePedidos() {
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow(null, null, null, "=== Restaurante 20 Montaditos ===");
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow("Codigo", "Cliente", "Fecha", "Servido");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < listaPedidos.size(); i++) {
            table.addRule();
            row = table.addRow(listaPedidos.get(i).getIdentificador(), listaPedidos.get(i).getNombreDelCliente(),
                    listaPedidos.get(i).getFechaDelPedido(),listaPedidos.get(i).getHaSidoServidoEnFormato());
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        }

        table.addRule();
        row = table.addRow("*", "*", "*", "*");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        table.addRule();

        return table.render();
    }

    private String getTablaPedidosNoServidos() {
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow(null, null, null, "=== Restaurante 20 Montaditos ===");
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow("Codigo", "Cliente", "Fecha", "Servido");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < listaPedidos.size(); i++) {
            if(!listaPedidos.get(i).getHaSidoServidoEnMesa()){
                table.addRule();
                row = table.addRow(listaPedidos.get(i).getIdentificador(), listaPedidos.get(i).getNombreDelCliente(),
                        listaPedidos.get(i).getFechaDelPedido(),listaPedidos.get(i).getHaSidoServidoEnFormato());
                row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
                row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
                row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
                row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
            }
        }

        table.addRule();
        row = table.addRow("*", "*", "*", "*");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        table.addRule();

        return table.render();
    }
}