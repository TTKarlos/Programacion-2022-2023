import java.util.Scanner;

public class Activitat4 {
    public static void main(String[] args) {

        int majorDe3 = donamMajor3();
        System.out.println(majorDe3);
    }

    public static int donamMajor3() {

        Scanner teclado = new Scanner(System.in);

        System.out.println("Introdueix un número: ");
        int mayor = teclado.nextInt();

        for(int i = 1; i < 3; i++){
            System.out.println("Introdueix un número: ");
            int numeroLlegit = teclado.nextInt();
            if (i == 0){
                mayor = numeroLlegit;
            } else {
                if ( numeroLlegit < mayor){
                    mayor = numeroLlegit;
                }
            }
        }
        return mayor;
    }
}
