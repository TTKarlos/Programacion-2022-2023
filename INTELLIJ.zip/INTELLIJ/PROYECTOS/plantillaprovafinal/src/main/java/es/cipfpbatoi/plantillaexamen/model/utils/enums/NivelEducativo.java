package es.cipfpbatoi.plantillaexamen.model.utils.enums;

public enum NivelEducativo {
    ESO{
        public String toString(){
            return "ESO";
        }
    },
    BACHILLERATO{
        public String toString(){
            return "BACHILLERATO";
        }
    },
    FP{
        public String toString(){
            return "FP";
        }
    },
}