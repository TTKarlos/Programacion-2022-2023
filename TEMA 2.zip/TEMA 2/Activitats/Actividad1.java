public class Actividad1 {

    public static void main(String[] args) {
        //literal entero
        System.out.println(12);
        //literal cadena
        System.out.println(21.2);
        //literal caracter
        System.out.println('w');
        //literal caracter
        System.out.println(false);
        //literal caracter
        System.out.println("juan");

}

}
