package exception;

public class ViajeDuplicadoException extends RuntimeException{
    public ViajeDuplicadoException(String codViaje){
        super("Viaje " + codViaje + " no registrado. Motivo: Viaje ya registrado");
    }
}
