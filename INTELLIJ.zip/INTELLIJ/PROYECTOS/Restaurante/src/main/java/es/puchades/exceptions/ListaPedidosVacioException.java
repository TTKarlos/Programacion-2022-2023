package es.puchades.exceptions;

public class ListaPedidosVacioException extends RuntimeException{
    public ListaPedidosVacioException(String texto){
        super(texto);
    }
}
