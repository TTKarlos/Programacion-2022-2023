package view;

import de.vandermeer.asciitable.AT_Row;
import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;
import entities.vehiculos.Vehiculo;
import java.util.ArrayList;

public class ViewVehiculos {
    private ArrayList<Vehiculo> vehiculos;

    public ViewVehiculos(ArrayList<Vehiculo> vehiculos){
        this.vehiculos = vehiculos;
    }

    private String getTablaVehiculos(){
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow(null, null, null, null, null, "Listado de Vehiculos");
        row.getCells().get(5).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow("Matricula", "Marca", "Modelo", "Cilindros", "Numero de Plazas", "Potencia en CC");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(5).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < vehiculos.size(); i++) {
            table.addRule();
            row = table.addRow(vehiculos.get(i).getMatricula(), vehiculos.get(i).getMarca(),
                    vehiculos.get(i).getModelo(), vehiculos.get(i).getCilindros(), vehiculos.get(i).getNumeroPlazas(),
                    vehiculos.get(i).getPotenciaDeCC());
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(5).getContext().setTextAlignment(TextAlignment.CENTER);
        }

        table.addRule();
        row = table.addRow("*", "*", "*", "*", "*", "*");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(5).getContext().setTextAlignment(TextAlignment.CENTER);
        table.addRule();

        return table.render();
    }

    @Override
    public String toString() {
        return getTablaVehiculos();
    }
}