package utils;

import entities.vehiculos.Vehiculo;
import entities.vehiculos.type.Camion;
import entities.vehiculos.type.Coche;
import entities.vehiculos.type.Furgoneta;
import entities.vehiculos.type.MicroBus;
import java.time.LocalDate;

public class GestorVehiculosPermitidos {
    private static final Vehiculo[] vehiculosAdmitidos = {
            new Coche("3735DSR", "Seat", "Pescado",
                    LocalDate.of(2022, 12, 12), 3, 5, 1500),
            new Coche("5764FSD", "Volkswagen", "Boniato",
                    LocalDate.of(2022, 12, 12), 2, 6, 1000),
            new Coche("2575AVD", "Kia", "Alcachofa",
                    LocalDate.of(2022, 12, 12), 4, 4, 900),
            new MicroBus("3571ADD", "Mercedes", "Pimiento",
                    LocalDate.of(2022, 12, 12), 6, 18, 1200),
            new MicroBus("5875ASD", "Audi", "Calabaza",
                    LocalDate.of(2022, 12, 12), 3, 19, 1000),
            new MicroBus("1856ASD", "Porsche", "Lenteja",
                    LocalDate.of(2022, 12, 12), 4, 16, 2000),
            new Furgoneta("4698AVD", "Skoda", "Cebolla",
                    LocalDate.of(2022, 12, 12), 8, 3, 2500, 1.5f),
            new Furgoneta("1235SD", "Volkswagen", "Alubia",
                    LocalDate.of(2022, 12, 12), 7, 3, 2000, 2),
            new Furgoneta("9632AWD", "Seat", "Arroz",
                    LocalDate.of(2022, 12, 12), 10, 3, 1800, 2.5f),
            new Camion("1458VSD", "Kia", "Judía",
                    LocalDate.of(2022, 12, 12), 9, 3, 3000, 3.5f),
            new Camion("8756ASD", "Ferrari", "Patata",
                    LocalDate.of(2022, 12, 12), 8, 3, 2000, 4),
            new Camion("5476WSD", "Peugeot", "Tomate",
                    LocalDate.of(2022, 12, 12), 15, 3, 2800, 5.5f),
    };

    public static boolean estaPermitidoElVehiculo(Vehiculo vehiculo){
        for (int i = 0; i < vehiculosAdmitidos.length; i++) {
            if(vehiculosAdmitidos[i].equals(vehiculo)){
                return true;
            }
        }

        return false;
    }
}