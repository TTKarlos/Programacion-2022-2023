package es.puchades.view;

import de.vandermeer.asciitable.AT_Row;
import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;
import es.puchades.pedido.Pedido;
import java.util.ArrayList;

public class ListadoPedidosView {
    private ArrayList<Pedido> listaPedidos;

    public ListadoPedidosView(ArrayList<Pedido> listaPedidos){
        this.listaPedidos = listaPedidos;
    }

    @Override
    public String toString() {
        return getTablaDePedidos();
    }

    private String getTablaDePedidos() {
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow(null, null, null, "=== Restaurante 20 Montaditos ===");
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow("Codigo", "Cliente", "Fecha", "Servido");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < listaPedidos.size(); i++) {
            table.addRule();
            row = table.addRow(listaPedidos.get(i).getIdentificador(), listaPedidos.get(i).getNombreDelCliente(),
                    listaPedidos.get(i).getFechaDelPedido(),getHaSidoServidoEnFormato(listaPedidos.get(i).getHaSidoServidoEnMesa()));
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        }

        table.addRule();
        row = table.addRow("*", "*", "*", "*");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        table.addRule();

        return table.render();
    }

    private String getHaSidoServidoEnFormato(boolean haSidoServidoEnMesa){
        if(haSidoServidoEnMesa){
            return "SI";
        } else {
            return "NO";
        }
    }
}