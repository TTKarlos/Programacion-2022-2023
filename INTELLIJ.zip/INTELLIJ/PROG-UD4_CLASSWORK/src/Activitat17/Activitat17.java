package Activitat17;

import java.util.Scanner;

public class Activitat17 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("Bienvenido al conversor octal-decimal\n-----------------------------");


        int opcion = 0;

        do {
            System.out.println("1.- Octal a decimal\n2.- Decimal a octal\n3.- Salir");

            boolean esCorrecte;
            do {
                System.out.print("Selecciona una opción [1-3]: ");
                if (!teclado.hasNextInt()) {
                    System.out.println("Error! La opción seleccionada no es correcta");
                    esCorrecte = true;
                } else {
                    opcion = teclado.nextInt();
                    if (opcion == 1 || opcion == 2 || opcion == 3) {
                        esCorrecte = false;
                    } else {
                        System.out.println("Error! La opción seleccionada no es correcta");
                        esCorrecte = true;
                    }
                }

            } while (esCorrecte);

            long num = 0;

            if (opcion == 1) {

                esCorrecte = false;
                do {
                    System.out.print("¿Qué número quieres convertir?: ");

                    if (!teclado.hasNextLong()) {
                        System.out.println("Error! La opción seleccionada no es correcta");
                        esCorrecte = true;
                    } else {
                        esCorrecte = false;
                        num = teclado.nextLong();

                        esCorrecte = Matematicas1.esNumeroOctal(num);

                        if (esCorrecte){
                            System.out.println("El numero no es Octal");
                        }
                    }
                } while (esCorrecte);

                System.out.printf("El número %d en decimal es %d\n", num, Matematicas1.obtenerEnBaseDecimal(num));
            } else if (opcion == 2){
                System.out.print("¿Qué número quieres convertir?: ");

                if (!teclado.hasNextLong()) {
                    System.out.println("Error! La opción seleccionada no es correcta");
                    esCorrecte = true;
                } else {
                    num = teclado.nextLong();
                }
                while (esCorrecte) ;

                System.out.printf("El número %d en octal es %d\n", num, Matematicas1.obtenerEnBaseOctal(num));
            } else {
                return;
            }
        } while (opcion != 3);
    }
}