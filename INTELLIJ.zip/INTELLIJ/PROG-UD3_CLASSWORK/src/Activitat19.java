public class Activitat19 {

    public static void main(String[] args) {

        for (int i = 10; i > 0;i--){
            System.out.print(i + ", ");

        }
        System.out.print("0\nPreparant partida...");
    }
}
