package activitat8.types;

import activitat8.Animal;
import activitat8.enums.Comida;
import activitat8.enums.Tamany;

public class Llop extends Animal {
    public  Llop(boolean vacunado, Comida comida, int hambre, Tamany tamanio, String localizacion){
        super(vacunado, comida, hambre, tamanio, localizacion);
    }

    public void emitirSonido(){
        System.out.println("AUUUUUUUHHHH!!!!!!!!!");
    }

    @Override
    public void vacunar(){
        System.out.println("Vacunando a un Lobo...");
        super.vacunar();
        emitirSonido();
    }

    @Override
    public String toString() {
        return "Lobo: " + super.toString();
    }
}