package exceptions;

public class FaseOcupadaException extends Exception {
    public FaseOcupadaException(){
        super("Error! La fase esta ocupada");
    }
}