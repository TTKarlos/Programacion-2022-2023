package activitat8.types;

import activitat8.Animal;
import activitat8.enums.Comida;
import activitat8.enums.Tamany;

public class Gat extends Animal {
    public  Gat(boolean vacunado, Comida comida, int hambre, Tamany tamanio, String localizacion){
        super(vacunado, comida, hambre, tamanio, localizacion);
    }

    public void emitirSonido(){
        System.out.println("Miauuuu!!!!!!!!!");
    }

    @Override
    public void vacunar(){
        System.out.println("Vacunando a un Gato...");
        super.vacunar();
        emitirSonido();
    }

    @Override
    public String toString() {
        return "Gato: " + super.toString();
    }
}