package activitat17;

public class Cotxe {

    private String marca;

    private Cambio tipoCambio;

    private Tipo tipo;

    public Cotxe(String marca, Cambio tipoCambio, Tipo tipo) {
        this.marca = marca;
        this.tipoCambio = tipoCambio;
        this.tipo = tipo;
    }


    public Cotxe(Tipo tipo, String marca) {
        this.tipo = tipo;
        this.marca = marca;
        if (tipo == Tipo.DEPORTIVO) {
            this.tipoCambio = Cambio.AUTOMATIC;
        } else {
            this.tipoCambio = Cambio.MANUAL;
        }
    }

    /**
     * Constructor amb la marca. S’establirà per defecte el tipus deportiu
     * i canvi manual.
     * @param marca
     */
    public Cotxe(String marca) {
        this.marca = marca;
        this.tipo = Tipo.DEPORTIVO;
        this.tipoCambio = Cambio.MANUAL;
    }

    @Override
    public String toString() {
        return "\n marca: " + marca +
                "\n tipo: " + tipo +
                "\n cambio: " + tipoCambio;
    }
}
