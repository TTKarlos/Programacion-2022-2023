import java.util.Scanner;

public class Activitat22 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Introdueix un numero: ");
        String num = teclado.nextLine();

        System.out.println("La suma es " + suma(num));
        System.out.println("La multiplicació es " + multiplicacio(num));
    }

    public static int multiplicacio(String num){

        String num1 = num.substring(0, num.indexOf(" "));
        String num2 = num.substring(num.indexOf(" ") + 1, num.length());

        return Integer.parseInt(num1) * Integer.parseInt(num2);
    }

    public static int suma(String num){

        String num1 = num.substring(0, num.indexOf(" "));
        String num2 = num.substring(num.indexOf(" ") + 1, num.length());

        return Integer.parseInt(num1) + Integer.parseInt(num2);
    }
}
