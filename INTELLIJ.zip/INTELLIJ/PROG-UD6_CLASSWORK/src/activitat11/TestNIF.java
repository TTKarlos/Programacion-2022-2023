package activitat11;

class TestNIF {
    public static void main(String[] args) {

        NIF nif1 = new NIF(21679882);
        System.out.println("----- TEST Clase NIF -----");
        nif1.mostrarInformacion();
    }
}