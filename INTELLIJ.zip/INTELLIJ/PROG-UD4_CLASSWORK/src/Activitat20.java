public class Activitat20 {
    public static void main(String[] args) {

        System.out.println(meitatFrase("Hola que tal"));
        System.out.println(meitatFrase("Adéu"));
    }

    public static String meitatFrase(String frase){

        return frase.substring(0,  frase.length() / 2);

    }
}