package activitat14;

public class Punto {

    final static int EXPONENTE_FORMULA = 2;
    private double puntoX;
    private double puntoY;

    public Punto(double puntoX, double puntoY){
        this.puntoX = puntoX;
        this.puntoY = puntoY;
    }

    public double getPuntoX() {
        return puntoX;
    }

    public double getPuntoY() {
        return puntoY;
    }

    public double getDistancia(Punto punto2){
        double puntosX = Math.pow(punto2.getPuntoX() - puntoX, EXPONENTE_FORMULA);
        double puntosY = Math.pow(punto2.getPuntoY() - puntoY, EXPONENTE_FORMULA);
        return Math.sqrt(puntosX + puntosY);
    }

    public String toString(){
        return "(" + puntoX + ", " +  puntoY + ")";
    }
}