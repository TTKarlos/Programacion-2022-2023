package activitat2.enums;

public enum TiposPintura {
    EXTERIOR,
    INTERIOR,
    COMPLETO,
}