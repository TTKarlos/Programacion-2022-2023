package es.cipfpbatoi.gestorusuariosv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestorUsuariosApplication {

    public static void main(String[] args) {
        SpringApplication.run(GestorUsuariosApplication.class, args);
    }

}
