package activitat9.types;

import activitat9.Mascota;

public class RoboDog implements Mascota {
    @Override
    public void Mascota() {

    }

    @Override
    public void jugar() {

    }
}
