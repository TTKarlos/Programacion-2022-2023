public class Juego {

    static float DINERO = 0;
    static int VIDAS = 3;
    static int CONTADOR_DE_JUGADAS = 0;
    final static int PUNTO_X = 0;
    final static int PUNTO_Y = 1;
    final static int INICIAL_INDICE = 0;
    final static int PERDER_VIDAS = 0;
    static int NUMERO_DE_JUGADAS_PARA_UNA_TIENDA = 5;
    final static int VELOCIDAD_DEL_TEXTO = 100;
    final static int DINERO_POR_JOYERIA = 1;
    final static float DINERO_POR_TIENDA = 0.25f;
    final static String GEMA_MAGICA = "\u2764\uFE0F";
    final static String COCHE_DEL_LADRON = "\uD83D\uDE97";
    final static String COCHE_DE_POLICIA = "\uD83D\uDE93";
    final static String SIMBOLO_DEL_DOLAR = "\uD83D\uDCB2";
    final static String COLOR_AMARILLO = "\033[33m";
    final static String COLOR_ROJO = "\033[31m";
    final static String COLOR_CYAN = "\033[36m";
    final static String RESET_COLOR = "\u001B[0m";
    final static String TEXTO_GANAR = COLOR_AMARILLO + COCHE_DEL_LADRON + "\uD835\uDE43\uD835\uDE56\uD835\uDE68 " +
            "\uD835\uDE5C\uD835\uDE56\uD835\uDE63\uD835\uDE56\uD835\uDE59\uD835\uDE64. ¡\uD835\uDE40\uD835\uDE63" +
            "\uD835\uDE5D\uD835\uDE64\uD835\uDE67\uD835\uDE56\uD835\uDE57\uD835\uDE6A\uD835\uDE5A\uD835\uDE63\uD835" +
            "\uDE56❗" + COCHE_DE_POLICIA + RESET_COLOR;
    final static String TEXTO_PERDER = COLOR_ROJO + COCHE_DEL_LADRON + "\uD835\uDE43\uD835\uDE56\uD835\uDE68 \uD835\uDE65\uD835" +
            "\uDE5A\uD835\uDE67\uD835\uDE59\uD835\uDE5E\uD835\uDE59\uD835\uDE64. \uD835\uDE41\uD835\uDE5E\uD835\uDE63 " +
            "\uD835\uDE59\uD835\uDE5A\uD835\uDE61 \uD835\uDE45\uD835\uDE6A\uD835\uDE5A\uD835\uDE5C\uD835\uDE64" +
            COCHE_DE_POLICIA + RESET_COLOR;

    public static void imprimirEscenario(String[][] escenario,int[] posicionIndianaJones, int[][] posicionSerpientes){
        for (int i = INICIAL_INDICE; i < escenario.length; i++) {
            for (int j = INICIAL_INDICE; j < escenario[i].length; j++){
                int[] puntoAImprimir = new int[] {i, j};
                if (Punto.sonIguales(puntoAImprimir, posicionIndianaJones)) {
                    System.out.print(COCHE_DEL_LADRON);
                } else if (Punto.hayAlgunPuntoIgual(puntoAImprimir, posicionSerpientes)) {
                    System.out.print(COCHE_DE_POLICIA);
                } else {
                    System.out.print(escenario[i][j]);
                }
            }
            System.out.println();
        }
    }

    public static void moverATodos(String[][] escenario, int[] posicionIndianaJones, int[][] posicionSerpientes){

        CONTADOR_DE_JUGADAS++;
        int direccion = Movimiento.pedirDireccion();
        IndianaJones.moverEnDireccion(escenario, direccion, posicionIndianaJones);
        Serpientes.mover(escenario, posicionSerpientes);

        if(CONTADOR_DE_JUGADAS == NUMERO_DE_JUGADAS_PARA_UNA_TIENDA){
            int[] gemaMagicaGenerada = Tiendas.generarTiendas(escenario);
            escenario[gemaMagicaGenerada[PUNTO_X]][gemaMagicaGenerada[PUNTO_Y]] = Tiendas.TIENDA;
            CONTADOR_DE_JUGADAS = INICIAL_INDICE;
        }
    }

    public static void actualizarDatos(String[][]escenario, int[] posicionIndianaJones, int[][]posicionSerpientes){

        if(Escenario.hayGema(escenario, posicionIndianaJones[PUNTO_X], posicionIndianaJones[PUNTO_Y])){
            DINERO += DINERO_POR_JOYERIA;
            Escenario.vaciarCelda(escenario, posicionIndianaJones[PUNTO_X], posicionIndianaJones[PUNTO_Y]);
        }

        if(tocaSerpiente(posicionIndianaJones, posicionSerpientes)){
            VIDAS--;
            IndianaJones.obtenerPosicionInicio();
            Serpientes.obtenerPosicionesInicio();
        }

        if(Tiendas.hayTiendas(escenario, posicionIndianaJones[PUNTO_X], posicionIndianaJones[PUNTO_Y])){
            DINERO += DINERO_POR_TIENDA;
            Escenario.vaciarCelda(escenario, posicionIndianaJones[PUNTO_X], posicionIndianaJones[PUNTO_Y]);
        }

        System.out.printf(
                COLOR_CYAN + "Te quedan %d intentos para entrar a la carcel.\n" +
                "Llevas ya %.2fM de euros.%s%s\n", VIDAS, DINERO, RESET_COLOR, SIMBOLO_DEL_DOLAR);

    }


    public static void imprimirMensajeFinDeJuego(String[][] escenario) throws InterruptedException {

        if(VIDAS == PERDER_VIDAS){
            mostrarTexto(TEXTO_PERDER, VELOCIDAD_DEL_TEXTO);
        }

        if(!Escenario.quedanGemas(escenario)){
            mostrarTexto(TEXTO_GANAR, VELOCIDAD_DEL_TEXTO);
        }
    }

    public static boolean seHaTerminado(String[][]escenario){
        if(VIDAS == PERDER_VIDAS || !Escenario.quedanGemas(escenario)){
            return true;
        } else {
            return false;
        }
    }

    public static boolean tocaSerpiente(int[]posicionIndianaJones, int[][] posicionSerpientes){
        for (int i = INICIAL_INDICE; i < posicionSerpientes.length; i++){
            if(Punto.sonIguales(posicionIndianaJones, posicionSerpientes[i])){
                return true;
            }
        }

        return false;
    }

    public static void mostrarTexto(String cadenaTexto, int velocidad) throws InterruptedException {
        for(int i = INICIAL_INDICE; i < cadenaTexto.length(); i++){
            System.out.print(cadenaTexto.charAt(i));
            Thread.sleep(velocidad);
        }
    }
}