public class Actividad20 {
    public static void main(String[] args) {
        System.out.println(" El resultado es " + (3+3));
    }
}
