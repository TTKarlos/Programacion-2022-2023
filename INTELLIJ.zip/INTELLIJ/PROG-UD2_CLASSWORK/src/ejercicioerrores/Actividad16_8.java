import java.util.Scanner;

/**
 * @Error: No podem fer una comparacio entre un int y un string, ja que el ordinador no sap si son iguals. Deuriem de
 * cambiar el "String" de la linea 17 y possar un "int"", per a que la comparació es puga fer. Tambe añadir el "Int" entre
 * el ".teclat" y "()" --> int numeroEntratUsuari = teclat.nextInt();
 * Ademés cambiar el text del print de la linea 16 per a que no tindre confusions --> System.out.println("Introdueix un número");
 * @Tipus: Temps de compilació.
 **/

public class Actividad16_8 {

    public static void main(String[] args) {
        int numeroAEndevinar = (int) (Math.random() * 10);
        Scanner teclat = new Scanner(System.in);
        System.out.println("Introdueix un número");
        int numeroEntratUsuari = teclat.nextInt();
        System.out.println("Ha endevinat el número " + (numeroAEndevinar == numeroEntratUsuari));
    }

}
