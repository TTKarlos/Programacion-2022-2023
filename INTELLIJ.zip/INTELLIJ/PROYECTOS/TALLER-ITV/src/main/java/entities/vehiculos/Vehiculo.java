package entities.vehiculos;

import java.time.LocalDate;
import java.util.Objects;

public class Vehiculo {
    protected String matricula;
    protected String marca;
    protected String modelo;
    protected LocalDate fechaUltimaRevision;
    protected int cilindros;
    protected int numeroPlazas;
    protected int potenciaDeCC;

    public Vehiculo(String matricula, String marca, String modelo, LocalDate fechaUltimaRevision,
                    int cilindros, int numeroPlazas, int potenciaDeCC) {
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.fechaUltimaRevision = fechaUltimaRevision;
        this.cilindros = cilindros;
        this.numeroPlazas = numeroPlazas;
        this.potenciaDeCC = potenciaDeCC;
    }

    public String getMatricula() {
        return matricula;
    }

    public LocalDate getFechaUltimaRevision() {
        return fechaUltimaRevision;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public int getCilindros() {
        return cilindros;
    }

    public int getNumeroPlazas() {
        return numeroPlazas;
    }

    public int getPotenciaDeCC() {
        return potenciaDeCC;
    }

    public void setFechaUltimaRevision(LocalDate fechaUltimaRevision) {
        this.fechaUltimaRevision = fechaUltimaRevision;
    }

    public boolean laFechaEsCorrecta() {
        return fechaUltimaRevision.plusYears(1).isBefore(LocalDate.now());
    }

    public double calcularPrecioRevision(){
        return 15 * cilindros;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Vehiculo vehiculo)) return false;
        return cilindros == vehiculo.cilindros && numeroPlazas == vehiculo.numeroPlazas &&
                potenciaDeCC == vehiculo.potenciaDeCC && getMarca().equalsIgnoreCase(vehiculo.getMarca()) &&
                getModelo().equalsIgnoreCase(vehiculo.getModelo());
    }
}