public class Activitat14 {
    final static double POBLACIO_TOTAL = 312032486;
    final static double CUANTOS_DIAS_TIENE_UN_AÑO = 365;
    final static double DIAS_A_HORAS = 24;
    final static double HORAS_A_MINUTOS = 60;
    final static double MINUTOS_A_SEGUNDOS = 60;
    final static double UN_NACIMIENTO_CADA_X_SEGUNDOS = 7;
    final static double UNA_MUERTE_CADA_X_SEGUNDOS = 13;
    final static short UN_IMIGRANTE_CADA_X_SEGUNDOS = 45;

    public static void main(String[] args) {

        double segundoEnUnAño = CUANTOS_DIAS_TIENE_UN_AÑO*DIAS_A_HORAS*HORAS_A_MINUTOS*MINUTOS_A_SEGUNDOS;

        double nacimientosPorAño = segundoEnUnAño / UN_NACIMIENTO_CADA_X_SEGUNDOS;

        double muerteSPorAño = segundoEnUnAño / UNA_MUERTE_CADA_X_SEGUNDOS;

        double imigrantesPorAño = segundoEnUnAño / UN_IMIGRANTE_CADA_X_SEGUNDOS;

        double personasPorAño = (nacimientosPorAño+imigrantesPorAño)-muerteSPorAño;

        System.out.println("PROJECCIÓ DE LA POBLACIÓ EN ELS EEUU\n------------------------------------");
        System.out.printf("Any actual: %.0f persones\n", POBLACIO_TOTAL);
        System.out.printf("Any 2023: %.0f persones \n",(POBLACIO_TOTAL + personasPorAño));
        System.out.printf("Any 2024: %.0f persones \n",(POBLACIO_TOTAL + (personasPorAño*2)));
        System.out.printf("Any 2025: %.0f persones \n",(POBLACIO_TOTAL + (personasPorAño*3)));
        System.out.printf("Any 2026: %.0f persones \n",(POBLACIO_TOTAL + (personasPorAño*4)));
        System.out.printf("Any 2027: %.0f persones \n",(POBLACIO_TOTAL + (personasPorAño*5)));
        System.out.println("…………");

    }
}