public class Actividad4 {
    public static void main(String[] args) {
        int num = (int) 34;
        System.out.println(num);
        float num2 = (float) 34.5;
        System.out.println(num2);

    }
}
