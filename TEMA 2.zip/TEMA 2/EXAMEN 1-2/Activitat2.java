import java.util.Scanner;

public class Actividad2 {
    final static int NEUTRAL = 0;
    final static int PRIMER_VALOR = 15;
    final static int SEGUNDO_VALOR = 47;
    final static int TERCER_VALOR = 5;
    final static int CUARTO_VALOR = 85;
    final static int QUINTO_VALOR = 10;

    public static void main(String[] args) {
        Scanner usuario = new Scanner(System.in);

        int edad;

        do{
            System.out.print("Introduce una edad: ");
            edad = usuario.nextInt();

        } while(edad < NEUTRAL);

        if(edad / PRIMER_VALOR >= NEUTRAL){
            if(edad % SEGUNDO_VALOR == NEUTRAL){
                if(edad % QUINTO_VALOR == NEUTRAL){
                    System.out.println("Tu edad no es biológicamente retrasada");

                } else{
                    System.out.println("Tu edad es biológicamente retrasada");
                }

            } else if(edad > TERCER_VALOR && edad < CUARTO_VALOR){
                System.out.println("Tu edad es biológicamente retrasada");

            } else{
                System.out.println("Tu edad no es biológicamente retrasada");
            }

        } else if(edad > TERCER_VALOR && edad < CUARTO_VALOR){
            System.out.println("Tu edad es biológicamente retrasada");

        } else{
            System.out.println("Tu edad no es biológicamente retrasada");
        }
    }
}
