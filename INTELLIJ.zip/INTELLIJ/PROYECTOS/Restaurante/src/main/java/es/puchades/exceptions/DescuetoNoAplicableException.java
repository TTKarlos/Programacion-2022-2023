package es.puchades.exceptions;

public class DescuetoNoAplicableException extends RuntimeException{
    public DescuetoNoAplicableException(){
        super("No se puede aplicar el descuento a este producto");
    }
}