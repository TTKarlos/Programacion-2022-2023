import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class activitat8 {

    final static String ALFIL = "\u265D  ";
    final static String HUECO = "\u2B1C ";
    final static String[] ARRAY_LETRAS_DEL_TABLERO = {"a", "b", "c", "d", "e", "f", "g", "h"};

    public static void main(String[] args) {
        String[] posicioAlfil = posicionAlfil();

        mostrarTablero(posicioAlfil);
    }

    public static void mostrarMovimientosDelAlfil(String[] posicionAlfil) {
        while (true){

        }
    }

    public static String[] posicionAlfil(){
        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduzca la posición del Alfil: ");
        String posicion = teclado.next();

        return new String[] {posicion.substring(0,1), posicion.substring(1)};
    }

    public static int[] posicioAlfil(String[] posicioAlfil){
        int[] posicioAlfi = new int[2];

        for(int i = 0; i < ARRAY_LETRAS_DEL_TABLERO.length; i++){
            if(ARRAY_LETRAS_DEL_TABLERO[i].equalsIgnoreCase(posicioAlfil[0])){
                posicioAlfi[0] = i;
            }
        }

        posicioAlfi[1] = Integer.parseInt(posicioAlfil[1]) - 1;

        return posicioAlfi;
    }

    public static void mostrarTablero(String[] posicioAlfil){
        int[] posicioAlfi = posicioAlfil(posicioAlfil);

        for (int i = 0; i < ARRAY_LETRAS_DEL_TABLERO.length; i++) {
            System.out.print("  " + ARRAY_LETRAS_DEL_TABLERO[i]);
        }

        System.out.println();

        for (int i = 0; i < 8; i++){
            System.out.print(i + " ");

            for (int j = 0; j < 8; j++) {
                if(posicioAlfi[0] == j && posicioAlfi[1] == i){
                    System.out.print(ALFIL);
                } else {
                    System.out.print(HUECO);
                }
            }

            System.out.println();
        }
    }
}