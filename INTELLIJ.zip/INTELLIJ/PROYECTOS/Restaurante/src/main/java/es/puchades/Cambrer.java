package es.puchades;

import es.puchades.enums.Catalogo;
import es.puchades.exceptions.NoEncontradoException;
import es.puchades.pedido.Pedido;
import es.puchades.productos.Producto;
import es.puchades.productos.tipos.Bebida;
import es.puchades.productos.tipos.Entrante;
import es.puchades.productos.tipos.Montadito;
import es.puchades.productos.tipos.Postre;
import es.puchades.view.ListadoProductoView;
import java.util.ArrayList;
import java.util.Scanner;

public class Cambrer {
    final static String TEXTO_CODIGO_ERRONEO = "El codigo del producto es erróneo";
    final static String TEXTO_INTRODUCE_PRODUCTO = "Introduzca el código del producto que desea añadir (0 - Finalizar)";
    final static String TEXTO_INTRODUCIR_NOMBRE = "Introduzca su nombre: ";
    private Catalogo catalogo;
    private ArrayList<Producto> listaProductos;

    public Cambrer(Catalogo  catalogo) {
        this.catalogo = catalogo;
    }

    public Pedido atenderMesa(int numPedido) {
        this.listaProductos = new ArrayList<>();

        String fecha = GestorIO.getFechaYHora();
        String nombre = GestorIO.pedirTexto(TEXTO_INTRODUCIR_NOMBRE);

        pedirProductoElegido(Bebida.class);
        pedirProductoElegido(Entrante.class);
        pedirProductoElegido(Montadito.class);
        pedirProductoElegido(Postre.class);

        return new Pedido(numPedido, fecha, nombre, listaProductos);
    }

    private void pedirProductoElegido(Class tipo) {
        Scanner teclado = new Scanner(System.in);

        System.out.println(new ListadoProductoView(catalogo.getListaProductos(tipo)));

        do {
            GestorIO.mostrarTextoEnAzul(TEXTO_INTRODUCE_PRODUCTO);
            String producto = teclado.next();

            if (producto.length() == 1 && Integer.parseInt(producto) == 0) {
                return;
            }

            try{
                if (catalogo.getProducto(producto, tipo) != null){
                    Producto productoElegido = catalogo.getProducto(producto, tipo);
                    listaProductos.add(productoElegido);
                    mostrarProductoAnyadidoEnFormato(productoElegido);
                    continue;
                }

                throw new NoEncontradoException(TEXTO_CODIGO_ERRONEO);
            } catch (NoEncontradoException e){
                GestorIO.mostrarTextoEnError(e.getMessage());
            }
        } while (true);
    }

    private void mostrarProductoAnyadidoEnFormato(Producto producto){
        System.out.print(GestorIO.COLOR_VERDE + producto.getCodigo() + GestorIO.RESET_COLOR +
                " - " + producto.getDescripcion());
        GestorIO.mostrarTextoEnVerde(" [Añadido]");
    }
}