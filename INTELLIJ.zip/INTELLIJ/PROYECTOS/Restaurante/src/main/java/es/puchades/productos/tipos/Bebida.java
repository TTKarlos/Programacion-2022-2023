package es.puchades.productos.tipos;

import es.puchades.enums.TamanyoDeBebida;
import es.puchades.productos.Producto;

public class Bebida extends Producto {
    private TamanyoDeBebida tamanyoDeBebida;
    private boolean esRellenable;

    public Bebida(String nombre, String descripcion, float precioBase, float decuento, float iva,
                  TamanyoDeBebida tamanyoDeBebida, boolean esRellenable) {
        super(nombre, descripcion, precioBase, decuento, iva);
        this.tamanyoDeBebida = tamanyoDeBebida;
        this.esRellenable = esRellenable;
    }
    @Override
    public TamanyoDeBebida getTamanyoDeBebida() {
        return tamanyoDeBebida;
    }

    @Override
    public boolean getEsRellenable(){
        return esRellenable;
    }
}