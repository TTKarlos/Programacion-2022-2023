import exception.ViajeDuplicadoException;
import exception.ViajeNoCancelableException;
import exception.ViajeNoValidoException;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Agencia {
    private String codigo;
    private String nombreComercial;
    private String nombrePersona;
    private String ciudadesAutorizadas;
    private ArrayList<Viaje> listadosDeViajes;

    public Agencia(String codigo, String nombreComercial, String nombrePersona, String ciudadesAutorizadas) {
        this.codigo = codigo;
        this.nombreComercial = nombreComercial;
        this.nombrePersona = nombrePersona;
        this.ciudadesAutorizadas = ciudadesAutorizadas;
        this.listadosDeViajes = new ArrayList<>();
    }

    public void anyadirViaje(Viaje viaje) throws ViajeNoValidoException{
        try {
            hayUnViajeDuplicado(viaje);
            estaPermitidoElViaje(viaje);
            listadosDeViajes.add(viaje);
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public ArrayList<Viaje> getViajesPendientes(){
        ArrayList<Viaje> viajesPendientes = new ArrayList<>();

        for (int i = 0; i < listadosDeViajes.size(); i++) {
            if(listadosDeViajes.get(i).getFechayHoraDeEmpezar().isAfter(LocalDateTime.now())){
                viajesPendientes.add(listadosDeViajes.get(i));
            }
        }

        return viajesPendientes;
    }

    public Viaje getViaje(String codViaje){
        int indexViaje = getIndexViaje(codViaje);
        return listadosDeViajes.get(getIndexViaje(codViaje));
    }

    public void cancelarPedido(String codViaje){
        int indexViaje = getIndexViaje(codViaje);

        if(indexViaje == -1){
            System.out.printf("Este viaje no existe");
            return;
        }

        listadosDeViajes.get(indexViaje).setEstaCancelado(true);
    }

    private int getIndexViaje(String codViaje){
        Viaje viaje = new Viaje(codViaje);

        for (int i = 0; i < listadosDeViajes.size(); i++) {
            if(listadosDeViajes.get(i).equals(viaje)){
                return i;
            }
        }

        return -1;
    }

    private boolean viajeTieneCiudadesAutorizadas(Viaje viaje){
        String[] ciudadesViaje = ciudadesDisponibles(viaje.getRuta());
        String[] ciudadesAgencia = ciudadesDisponibles(ciudadesAutorizadas);
        int contador = 0;

        for (int i = 0; i < ciudadesAgencia.length; i++) {
            for (int j = 0; j < ciudadesViaje.length; j++) {
                if(!(ciudadesAgencia[i].equals(ciudadesViaje[j]))){
                    contador++;
                }
            }

            if(contador == ciudadesAgencia.length){
                return false;
            }

            contador = 0;
        }

        return true;
    }

    public int horasRestantesParaElLimite(Viaje viaje){
        LocalDateTime tiempoInicio = viaje.getFechayHoraDeEmpezar();
        LocalDateTime tiempoLimite = tiempoInicio.plusHours(-24);
        int tiempoRestante = LocalDateTime.now().compareTo(tiempoLimite);

        return LocalDateTime.now().getHour() - tiempoLimite.getHour();
    }

    private boolean elViajePasaDeSuTiempoLimite(Viaje viaje){
        LocalDateTime tiempoInicio = viaje.getFechayHoraDeEmpezar();
        LocalDateTime tiempoLimite = tiempoInicio.plusHours(-24);

        return tiempoLimite.isAfter(LocalDateTime.now());
    }

    private boolean hayUnViajeIgual(Viaje viaje){
        for (int i = 0; i < listadosDeViajes.size(); i++) {
            if(listadosDeViajes.get(i).equals(viaje)){
                return true;
            }
        }

        return false;
    }

    private String[] ciudadesDisponibles(String cadena){
        return cadena.split("-");
    }

    private void estaPermitidoElViaje(Viaje viaje) throws ViajeNoValidoException{
        if(!viajeTieneCiudadesAutorizadas(viaje)){
            throw new ViajeNoValidoException(viaje.getCodigo());
        }
    }

    private void hayUnViajeDuplicado(Viaje viaje){
        if(hayUnViajeIgual(viaje)){
            throw new ViajeDuplicadoException(viaje.getCodigo());
        }
    }

    private void estaPermitidoCancelar(Viaje viaje){
        if(elViajePasaDeSuTiempoLimite(viaje)){
            throw new ViajeNoCancelableException(horasRestantesParaElLimite(viaje));
        }
    }
}