import java.util.Random;

public class JugadorPC extends Jugador{
    final static int DELAY = 800;
    private EstadoCasilla estadoCasilla;

    public JugadorPC(EstadoCasilla estadoCasilla, Icono icono){
        super(estadoCasilla, icono);
        this.estadoCasilla = estadoCasilla;
    }

    @Override
    public void ponerFicha(Tablero tablero){
        do {
            Coordenada coordenada = generarCoordenadaInteligente(tablero);

            if(tablero.isOcupada(coordenada)){
                tablero.ponerFicha(coordenada, estadoCasilla);
                delay();
                return;
            }
        } while (true);
    }

    public Coordenada generarUnaCoordenadaAleatoria(Tablero tablero){
        Random numRandom = new Random();

        return new Coordenada((numRandom.nextInt(tablero.getTablero().length)),
                numRandom.nextInt(tablero.getTablero().length));
    }

    public Coordenada generarCoordenadaInteligente(Tablero tablero){
        Coordenada generar2EnRaya = cordenadaAutomaticaDeEnRaya(tablero, 1, estadoCasilla);
        Coordenada generar3EnRaya = cordenadaAutomaticaDeEnRaya(tablero, 2, estadoCasilla);
        Coordenada generar3EnRayaContrincante = cordenadaAutomaticaDeEnRaya(tablero, 2,
                darElJugadorContrario(estadoCasilla));

        if(generar3EnRaya != null){
            return generar3EnRaya;
        } else if(generar3EnRayaContrincante != null){
            return generar3EnRayaContrincante;
        } else if(generar2EnRaya != null){
            return generar2EnRaya;
        } else {
            return generarUnaCoordenadaAleatoria(tablero);
        }
    }

    private Coordenada cordenadaAutomaticaDeEnRaya(Tablero tablero, int numParaEnRaya, EstadoCasilla estadoCasilla){
        Coordenada coordenadaFila = comprobarElEnRayaEnFilasQueDeUnNumero(tablero, numParaEnRaya, estadoCasilla);
        Coordenada coordenadaColumna = comprobarElEnRayaEnColumnasQueDeUnNumero(tablero, numParaEnRaya, estadoCasilla);
        Coordenada coordenadaDiagonal = comprobarElEnRayaEnDiagonalQueDeUnNumero(tablero, numParaEnRaya, estadoCasilla);
        Coordenada coordenadaSubdiagonal = comprobarElEnRayaEnSubiagonalQueDeUnNumero(tablero, numParaEnRaya, estadoCasilla);

        if(coordenadaFila != null){
            return coordenadaFila;
        } else if(coordenadaColumna != null){
            return coordenadaColumna;
        } else if(coordenadaDiagonal != null){
            return coordenadaDiagonal;
        } else if(coordenadaSubdiagonal != null){
            return coordenadaSubdiagonal;
        } else {
            return null;
        }
    }

    private Coordenada comprobarElEnRayaEnFilasQueDeUnNumero(Tablero tablero, int paraHacerEnRaya, EstadoCasilla estadoCasilla){
        Coordenada coordenadaVacia = null;

        int contador = 0;
        for (int i = 0; i < tablero.getTablero().length; i++){
            for (int j = 0; j < tablero.getTablero()[i].length; j++) {
                if(estadoCasilla != getEstadoCasilla()){
                    if (tablero.isOcupada(new Coordenada(i , j), estadoCasilla)){
                        contador++;
                    } else if (tablero.isOcupada(new Coordenada(i, j))){
                        coordenadaVacia = new Coordenada(i ,j);
                    } else if(tablero.isOcupada(new Coordenada(i, j), darElJugadorContrario(estadoCasilla))){
                        contador = 0;
                    }
                } else {
                    if (tablero.isOcupada(new Coordenada(i , j), estadoCasilla)){
                        contador++;
                    } else if (tablero.isOcupada(new Coordenada(i, j))){
                        coordenadaVacia = new Coordenada(i ,j);
                    } else if(tablero.isOcupada(new Coordenada(i, j), darElJugadorContrario(estadoCasilla))){
                        contador--;
                    }
                }
            }

            if(contador == paraHacerEnRaya){
                return coordenadaVacia;
            }

            contador = 0;
        }

        return null;
    }

    private Coordenada comprobarElEnRayaEnColumnasQueDeUnNumero(Tablero tablero, int paraHacerEnRaya, EstadoCasilla estadoCasilla){
        Coordenada coordenadaVacia = null;

        int contador = 0;
        for (int i = 0; i < tablero.getTablero().length; i++){
            for (int j = 0; j < tablero.getTablero()[i].length; j++) {
                if(estadoCasilla != getEstadoCasilla()){
                    if (tablero.isOcupada(new Coordenada(j , i), estadoCasilla)){
                        contador++;
                    } else if (tablero.isOcupada(new Coordenada(j , i))){
                        coordenadaVacia = new Coordenada(j , i);
                    } else if(tablero.isOcupada(new Coordenada(j, i), darElJugadorContrario(estadoCasilla))){
                        contador = 0;
                    }
                } else {
                    if (tablero.isOcupada(new Coordenada(j , i), estadoCasilla)){
                        contador++;
                    } else if (tablero.isOcupada(new Coordenada(j , i))){
                        coordenadaVacia = new Coordenada(j , i);
                    } else if(tablero.isOcupada(new Coordenada(j, i), darElJugadorContrario(estadoCasilla))){
                        contador--;
                    }
                }
            }

            if(contador == paraHacerEnRaya){
                return coordenadaVacia;
            }

            contador = 0;
        }

        return null;
    }

    private Coordenada comprobarElEnRayaEnDiagonalQueDeUnNumero(Tablero tablero, int paraHacerEnRaya, EstadoCasilla estadoCasilla){
        Coordenada coordenadaVacia = null;
        int contador = 0;

        for(int i = 0; i < tablero.getTablero().length; i++){
            if(estadoCasilla != getEstadoCasilla()){
                if (tablero.isOcupada(new Coordenada(i , i), estadoCasilla)){
                    contador++;
                } else if (tablero.isOcupada(new Coordenada(i , i))){
                    coordenadaVacia = new Coordenada(i , i);
                } else if(tablero.isOcupada(new Coordenada(i, i), darElJugadorContrario(estadoCasilla))){
                    return null;
                }
            } else {
                if (tablero.isOcupada(new Coordenada(i , i), estadoCasilla)){
                    contador++;
                } else if (tablero.isOcupada(new Coordenada(i , i))){
                    coordenadaVacia = new Coordenada(i , i);
                } else if(tablero.isOcupada(new Coordenada(i, i), darElJugadorContrario(estadoCasilla))){
                    contador--;
                }
            }
        }

        if(contador == paraHacerEnRaya){
            return coordenadaVacia;
        }

        return null;
    }

    private Coordenada comprobarElEnRayaEnSubiagonalQueDeUnNumero(Tablero tablero, int paraHacerEnRaya, EstadoCasilla estadoCasilla){
        Coordenada coordenadaVacia = null;
        int indice = tablero.getTablero().length - 1;
        int contador = 0;

        for(int i = 0; i < tablero.getTablero().length; i++){
            if(estadoCasilla != getEstadoCasilla()){
                if (tablero.isOcupada(new Coordenada(i , indice), estadoCasilla)){
                    contador++;
                } else if (tablero.isOcupada(new Coordenada(i , indice))){
                    coordenadaVacia = new Coordenada(i , indice);
                } else if(tablero.isOcupada(new Coordenada(i, indice), darElJugadorContrario(estadoCasilla))){
                    return null;
                }
            } else {
                if (tablero.isOcupada(new Coordenada(i , indice), estadoCasilla)){
                    contador++;
                } else if (tablero.isOcupada(new Coordenada(i , indice))){
                    coordenadaVacia = new Coordenada(i , indice);
                } else if(tablero.isOcupada(new Coordenada(i, indice), darElJugadorContrario(estadoCasilla))){
                    contador--;
                }
            }

            indice--;
        }

        if(contador == paraHacerEnRaya){
            return coordenadaVacia;
        }

        return null;
    }

    private void delay(){
        try {
            Thread.sleep(DELAY);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private EstadoCasilla darElJugadorContrario(EstadoCasilla estadoCasilla){
        if(estadoCasilla == EstadoCasilla.FICHA_X){
            return EstadoCasilla.FICHA_O;
        } else {
            return EstadoCasilla.FICHA_X;
        }
    }
}