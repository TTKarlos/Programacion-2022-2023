public class Actividad16_2 {
    /**
     * @Error: Tenim que posar un "f" després del 015, per a que no el agafe com a double y si com a float.
     * @Tipus: Temps de compilació.
     **/

    public static void main(String[] args) {

        float prize = 85f;
        float totalDiscount = prize * 0.15f;
        System.out.println("Precio rebajado :" + ( prize - totalDiscount ));

    }
}
