package es.puchades.exceptions;

public class PedidoNoCancelableException extends RuntimeException{
    public PedidoNoCancelableException(){
        super("No se puede cancelar este pedido");
    }
}