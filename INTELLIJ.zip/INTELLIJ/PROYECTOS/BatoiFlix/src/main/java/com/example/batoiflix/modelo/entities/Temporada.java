package com.example.batoiflix.modelo.entities;

public class Temporada {
    private int id_temporada;
    private Serie serie;
    private int anyo_lanzamiento;
    private String guion;
    private int capitulos;

    public Temporada(Serie serie, int anyo_lanzamiento, String guion, int capitulos) {
        this.serie = serie;
        this.anyo_lanzamiento = anyo_lanzamiento;
        this.guion = guion;
        this.capitulos = capitulos;
    }

    public Temporada(int id_temporada, int anyo_lanzamiento, String guion, int capitulos) {
        this.id_temporada = id_temporada;
        this.anyo_lanzamiento = anyo_lanzamiento;
        this.guion = guion;
        this.capitulos = capitulos;
    }
}