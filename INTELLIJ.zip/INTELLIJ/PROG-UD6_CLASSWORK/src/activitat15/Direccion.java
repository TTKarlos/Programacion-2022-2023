package activitat15;

public class Direccion {

    private String pais;
    private String provincia;
    private String ciudad;
    private String direccion;

    public Direccion(String pais, String provincia, String ciudad, String direccion){
        this.pais = pais;
        this.provincia = provincia;
        this.ciudad = ciudad;
        this.direccion = direccion;
    }
}
