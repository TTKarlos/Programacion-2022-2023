public class Activitat3 {

    final static String[] ARRAY_1 = {"a", "h", "j", "k", "r"};
    final static String[] ARRAY_2 = {"a", "b", "h", "r", "t"};

    public static void main(String[] args) {

        visualitzarArray(generarArrayComunesEntreDosArrays(ARRAY_1, ARRAY_2));
        mostrarInformacion(ARRAY_1, ARRAY_2);
    }

    public static void mostrarInformacion(String [] cadena1, String [] cadena2){

        visualitzarArrayAmbIndex(cadena1, 1);
        visualitzarArrayAmbIndex(cadena2, 2);

        if (esIgualLasArrays(cadena1, cadena2)){
            mostrarInformacionSiEsIgualLaArray();
        } else {
            mostrarInformacionSiNoEsIgualLaArray();
        }
    }

    public static void mostrarInformacionSiEsIgualLaArray(){
        System.out.println("Los 2 arrays son iguales.\nElementos iguales: Todos\nElementos distintos: No existen");
    }

    public static void mostrarInformacionSiNoEsIgualLaArray(){
        System.out.println("2");
    }

    public static void visualitzarArray(String[] array){
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
        }
    }


        public static void visualitzarArrayAmbIndex(String[] array, int index){

        System.out.printf("a%d: [", index);

        for (int i = 0; i < array.length; i++) {
            if (i != array.length - 1) {
                System.out.print(array[i] + ", ");
            } else {
                System.out.print(array[i]);
            }
        }
        System.out.print("]\n");
    }

    public static boolean esIgualLasArrays(String[] cadena1, String[] cadena2){

        boolean esCorrecte = false;

        for (int i = 0; i < cadena1.length; i++){
            for (int j = 0; j < cadena2.length; j++){
                if(cadena1[i].equalsIgnoreCase(cadena2[j])){
                    esCorrecte = true;
                    break;
                }
            }

            if(!esCorrecte){
                return false;
            }
        }

        return true;
    }

    public static String[] generarArrayComunesEntreDosArrays(String[] llista1, String[] llista2){

        String[] llistaJunta = new String[llista1.length + llista2.length];
        int posicio = 0;

        for (int i = 0; i < llista1.length; i++){
            for (int j = 0; j < llista2.length; j++){
                if(llista1[i].compareTo(llista2[j]) < 0){
                    llistaJunta[posicio] = llista2[j];
                    posicio++;
                }
            }
        }

        return llistaJunta;
    }
}