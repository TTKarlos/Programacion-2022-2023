import exceptions.VotoInvalidoException;

import java.time.LocalDate;
import java.util.ArrayList;

public class EleccionFlexible extends Eleccion{
    private int numDiasDuracion;
    public EleccionFlexible(ArrayList<Partido> partidos, LocalDate diaVotacion, int numDiasDuracion) {
        super(partidos, diaVotacion);
        this.numDiasDuracion = numDiasDuracion;
    }

    @Override
    public void generarMesaElectoral(){
        super.generarMesaElectoral();
        ArrayList<String> dni = generar15Votantes();
        MesaElectoral mesaElectoral = new MesaElectoral("EF-" + mesasElectorales.size() + 1, dni);
        comprobarMesasElectorales();
        mesasElectorales.add(mesaElectoral);
    }

    @Override
    public void votar(String dni, Partido partido){
        for (int i = 0; i < mesasElectorales.size(); i++) {
            for (int j = 0; j < mesasElectorales.get(i).getCiudadanosConvocados().size(); j++) {
                if(mesasElectorales.get(i).getCiudadanosConvocados().get(i).equalsIgnoreCase(dni)){
                    if(diaVotacion.isAfter(LocalDate.now()) && diaVotacion.plusDays(numDiasDuracion).isBefore(LocalDate.now())){
                        Voto voto = new Voto(dni, partido);
                        mesasElectorales.get(i).depositarVoto(voto);
                        return;
                    } else {
                        throw new VotoInvalidoException("Error! el plazo ha concluido");
                    }
                }
            }
        }
        throw new VotoInvalidoException("Error el dni " + dni + " no esta convocado en ninguna mesa");

    }
}