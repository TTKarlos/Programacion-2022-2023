package Activitat17;

public class Matematicas1 {

    public static long obtenerEnBaseOctal(long decimal){
        long resultado = 0;
        long residuo;
        long i;
        for (i = 0; decimal >= 8; i++){
            residuo = (int) (decimal % 8);
            resultado += (int) (residuo * Math.pow(10,i));
            decimal = decimal / 8;
        }
        resultado += (decimal * Math.pow(10,i));

        return resultado;
    }

    public static long obtenerEnBaseDecimal(long octal){
        long resultado = 0;
        for (long i = 0; octal >= 1; i++){
            resultado += (octal % 10) * (Math.pow(8, i));
            octal = octal / 10;
        }
        return resultado;
    }

    public static boolean esNumeroOctal(long num){
        boolean esCorrecte = false;
        while (num >= 8) {
            int residu = (int) (num % 10);
            if (residu == 9 || residu == 8) {
                esCorrecte = true;
            }
            num /= 10;
        }
        return esCorrecte;
    }
}