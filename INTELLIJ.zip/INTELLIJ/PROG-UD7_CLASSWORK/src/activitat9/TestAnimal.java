package activitat9;

import activitat9.enums.Comida;
import activitat9.enums.Tamany;
import activitat9.types.*;

public class TestAnimal {
    public static void main(String[] args) {
        Animal lleo = new Lleo(false, Comida.CARNIVORO, 8, Tamany.GRANDE, "La Sabana");
        Animal llop = new Llop(false, Comida.CARNIVORO, 8, Tamany.GRANDE, "La Sabana");
        Animal llop2 = new Llop(false, Comida.CARNIVORO, 8, Tamany.MEDIANO, "La Serreta");
        Animal gos = new Gos(false, Comida.OMNIVORO, 8, Tamany.PEQUEÑO, "Alcoy");
        Animal gat = new Gat(false, Comida.OMNIVORO, 8, Tamany.PEQUEÑO, "España");
        Animal gat2 = new Gat(false, Comida.OMNIVORO, 8, Tamany.PEQUEÑO, "España");
        Animal cavall = new Cavall(false, Comida.CARNIVORO, 8, Tamany.GRANDE, "España");
        Animal hipopotam = new Hipopotam(false, Comida.HERBIVORO, 8, Tamany.GRANDE, "La Sabana");
        Animal tigre = new Tigre(false, Comida.CARNIVORO, 8, Tamany.GRANDE, "África");
        Animal tigre2 = new Tigre(false, Comida.CARNIVORO, 8, Tamany.GRANDE, "África");

        System.out.println("---- Antes de vacunarlos y alimentarlos ------");
        mostrarInformacion((Lleo) lleo, (Llop) llop, (Llop) llop2, (Gos) gos, (Gat) gat, (Gat) gat2, (Cavall) cavall,
                (Hipopotam) hipopotam, (Tigre) tigre, (Tigre) tigre2);
        System.out.println();

        donarDeMenjarATots((Lleo) lleo, (Llop) llop, (Llop) llop2, (Gos) gos, (Gat) gat, (Gat) gat2, (Cavall) cavall,
                (Hipopotam) hipopotam, (Tigre) tigre, (Tigre) tigre2);

        vacunarATots((Lleo) lleo, (Llop) llop, (Llop) llop2, (Gos) gos, (Gat) gat, (Gat) gat2, (Cavall) cavall,
                (Hipopotam) hipopotam, (Tigre) tigre, (Tigre) tigre2);

        System.out.println("\n---- Después de vacunarlos y alimentarlos ------\n");
        mostrarInformacion((Lleo) lleo, (Llop) llop, (Llop) llop2, (Gos) gos, (Gat) gat, (Gat) gat2, (Cavall) cavall,
                (Hipopotam) hipopotam, (Tigre) tigre, (Tigre) tigre2);
    }

    public static void mostrarInformacion(Lleo lleo, Llop llop, Llop llop2, Gos gos, Gat gat, Gat gat2, Cavall cavall,
                                          Hipopotam hipopotam, Tigre tigre, Tigre tigre2){
        System.out.println(lleo);
        System.out.println(llop);
        System.out.println(llop2);
        System.out.println(gos);
        System.out.println(gat);
        System.out.println(gat2);
        System.out.println(cavall);
        System.out.println(hipopotam);
        System.out.println(tigre);
        System.out.println(tigre2);
    }

    public static void donarDeMenjarATots(Lleo lleo, Llop llop, Llop llop2, Gos gos, Gat gat, Gat gat2, Cavall cavall,
                                          Hipopotam hipopotam, Tigre tigre, Tigre tigre2){
        lleo.comer();
        llop.comer();
        llop2.comer();
        gos.comer();
        gat.comer();
        gat2.comer();
        cavall.comer();
        hipopotam.comer();
        tigre.comer();
        tigre2.comer();
    }

    public static void vacunarATots(Lleo lleo, Llop llop, Llop llop2, Gos gos, Gat gat, Gat gat2, Cavall cavall,
                                    Hipopotam hipopotam, Tigre tigre, Tigre tigre2){
        lleo.vacunar();
        llop.vacunar();
        llop2.vacunar();
        gos.vacunar();
        gat.vacunar();
        gat2.vacunar();
        cavall.vacunar();
        hipopotam.vacunar();
        tigre.vacunar();
        tigre2.vacunar();
    }
}