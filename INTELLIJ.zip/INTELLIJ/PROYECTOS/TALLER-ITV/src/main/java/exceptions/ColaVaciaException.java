package exceptions;

public class ColaVaciaException extends RuntimeException{
    public ColaVaciaException(String texto){
        super("Error! No hay " + texto + " en la cola");
    }
}