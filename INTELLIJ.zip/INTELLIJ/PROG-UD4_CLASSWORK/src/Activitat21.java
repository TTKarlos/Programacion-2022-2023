public class Activitat21 {
    public static void main(String[] args) {

        System.out.println(cambiarLesVocals("Hola que tal"));

    }

    public static String cambiarLesVocals(String frase){

        frase = frase.replace("e", "a")
                .replace("i", "a")
                .replace("o", "a")
                .replace("u", "a");

        return frase;
    }
}