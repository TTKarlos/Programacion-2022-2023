package es.cipfpbatoi.controllers;

import es.cipfpbatoi.excepciones.NotFoundException;
import es.cipfpbatoi.modelo.entidades.Tarea;
import es.cipfpbatoi.modelo.repositorios.TareaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Controller
public class TareaController {

    @Autowired
    private TareaRepository tareaRepository;

    @GetMapping(value = "/tarea-del")
    @ResponseBody
    public String deleteAction(@RequestParam int codTarea) throws NotFoundException {
        Tarea tarea = tareaRepository.get(codTarea);
        tareaRepository.remove(tarea);
        return "Tarea Borrada " + codTarea + " con éxito";
    }

    @GetMapping("/tarea")
    public String getTareaView(@RequestParam int codTarea, Model modelAndView) throws NotFoundException {
        Tarea tarea = tareaRepository.get(codTarea);
        modelAndView.addAttribute("tarea", tarea);
        modelAndView.addAttribute("usuarioLogueado", "Alex");
        return "tarea_details_view";
    }

    @GetMapping("/tarea-add")
    public String tareaFormActionView(){
        return "tarea_form_view";
    }

    @PostMapping(value = "/tarea-add")
    public String postAddAction(@RequestParam Map<String, String> params) {
        String user = params.get("user");
        String descripcion = params.get("description");
        String prioridad = params.get("priority");
        String realizadaString = params.get("realizada");
        boolean realizada = realizadaString != null && realizadaString.equalsIgnoreCase("true");
        Tarea.Priority priority = Tarea.Priority.fromText(prioridad);
        String horaExpiracionString = params.get("expiration_time");
        String fechaExpiracionString = params.get("expiration_date");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime fechaHora = LocalDateTime.parse(fechaExpiracionString + " " + horaExpiracionString, timeFormatter);
        int code = tareaRepository.nextCode();
        Tarea tarea = new Tarea(code, user, descripcion, priority, fechaHora, realizada);
        tareaRepository.add(tarea);
        return "redirect:/tareas";
    }

    @GetMapping(value = "/tareas")
    public String tareaList(Model model, @RequestParam HashMap<String, String> params) {
        String usuario = params.get("usuario");
        String realizadoString = params.get("realizada");
        String vencimientoString = params.get("vencimiento");
        ArrayList<Tarea> tareas;
        if (usuario != null && !usuario.isEmpty()) {
            model.addAttribute("usuario", usuario);
        }
        if (realizadoString != null
                || vencimientoString != null) {
            Boolean realizado = (realizadoString != null && realizadoString.equals("true")) ? true : null;
            LocalDate vencimiento = (vencimientoString != null && !vencimientoString.isBlank()) ? LocalDate.parse(vencimientoString, DateTimeFormatter.ofPattern("yyyy-MM-dd")): null;
            tareas = tareaRepository.findAll(realizado, vencimiento, usuario);
        } else {
            tareas = tareaRepository.findAll();
        }
        model.addAttribute("tareas", tareas);
        return "list_tarea_view";
    }

}
