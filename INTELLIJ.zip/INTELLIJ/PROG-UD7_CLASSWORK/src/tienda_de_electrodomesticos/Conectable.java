package tienda_de_electrodomesticos;

public interface Conectable {
    public void encender();
    public void apagar();
}