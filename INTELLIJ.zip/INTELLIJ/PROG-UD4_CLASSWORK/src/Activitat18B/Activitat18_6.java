package Activitat18B;

import java.util.Scanner;

public class Activitat18_6 {
    public static void main(String[] args) {

        System.out.printf("Su NIF es: %s", calcularNIF(obtenerDni()));

    }

    public static String obtenerDni() {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduzca su DNI: ");

        return teclado.next();
    }

    public static String calcularNIF(String dni) {

        String cadena = "TRWAGMYFPDXBNJZSQVHLCKE";

        return dni + "-" + cadena.charAt(Integer.parseInt(dni) % 23);
    }
}