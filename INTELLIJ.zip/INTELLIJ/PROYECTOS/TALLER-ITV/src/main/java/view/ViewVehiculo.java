package view;

import de.vandermeer.asciitable.AT_Row;
import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;
import entities.vehiculos.Vehiculo;

public class ViewVehiculo {
    private Vehiculo vehiculo;

    public ViewVehiculo(Vehiculo vehiculos){
        this.vehiculo = vehiculos;
    }

    private String getTablaVehiculos(){
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow(null, null, null, null, null, "Detalles " + vehiculo.getClass().getSimpleName());
        row.getCells().get(5).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow("Matricula", "Marca", "Modelo", "Cilindros", "Numero de Plazas", "Potencia en CC");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(5).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow(vehiculo.getMatricula(), vehiculo.getMarca(),
                vehiculo.getModelo(), vehiculo.getCilindros(), vehiculo.getNumeroPlazas(),
                vehiculo.getPotenciaDeCC());
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(5).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow("*", "*", "*", "*", "*", "*");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(3).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(4).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(5).getContext().setTextAlignment(TextAlignment.CENTER);
        table.addRule();

        return table.render();
    }

    @Override
    public String toString() {
        return getTablaVehiculos();
    }
}
