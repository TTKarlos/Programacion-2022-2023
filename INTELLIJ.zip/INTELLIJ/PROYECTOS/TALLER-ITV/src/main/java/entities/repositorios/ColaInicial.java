package entities.repositorios;

import entities.vehiculos.Vehiculo;
import exceptions.*;
import utils.GestorVehiculosPermitidos;

import java.util.ArrayList;

public class ColaInicial {
    private final static int INDICE_INCIAL = 0;
    private final static int MAXIMO_VEHICULOS = 50;
    private ArrayList<Vehiculo> vehiculos;

    public ColaInicial() {
        this.vehiculos = new ArrayList<>();
    }

    public ArrayList<Vehiculo> getVehiculos() {
        return vehiculos;
    }

    public void anyadir(Vehiculo vehiculo) throws ColaLlenaException, FechaIncorrectaException, YaExisteException, VehiculoIncorrectoException {
        estaLlenaLaCola();
        esFechaCorrecta(vehiculo);
        existeVehiculo(vehiculo);
        estaPermitidoVehiculo(vehiculo);

        vehiculos.add(vehiculo);
    }

    public Vehiculo sacar() throws ColaVaciaException {
        existenVehiculos();
        return vehiculos.remove(INDICE_INCIAL);
    }

    public void devolver(Vehiculo vehiculo) {
        try {
            estaLlenaLaCola();
            esFechaCorrecta(vehiculo);
            existeVehiculo(vehiculo);
            estaPermitidoVehiculo(vehiculo);

            vehiculos.add(INDICE_INCIAL, vehiculo);

        } catch (FechaIncorrectaException | YaExisteException | VehiculoIncorrectoException e){
            System.out.println(e.getMessage());
        }
    }

    public boolean hayVehiculos() {
        if(vehiculos.isEmpty()){
            return false;
        }

        return true;
    }

    public int getTotalVehiculos() {
        return vehiculos.size();
    }

    private boolean existeElVehiculo(Vehiculo vehiculo){
        for (int i = INDICE_INCIAL; i < vehiculos.size(); i++) {
            if(vehiculos.get(i).getMatricula().equalsIgnoreCase(vehiculo.getMatricula())){
                return true;
            }
        }

        return false;
    }

    private void estaLlenaLaCola() throws ColaLlenaException {
        if(vehiculos.size() >= MAXIMO_VEHICULOS){
            throw new ColaLlenaException("vehiculos");
        }
    }

    private void esFechaCorrecta(Vehiculo vehiculo) throws FechaIncorrectaException {
        if(!vehiculo.laFechaEsCorrecta()){
            throw new FechaIncorrectaException();
        }
    }

    private void existeVehiculo(Vehiculo vehiculo) throws YaExisteException {
        if(existeElVehiculo(vehiculo)){
            throw new YaExisteException();
        }
    }

    private void estaPermitidoVehiculo(Vehiculo vehiculo) throws VehiculoIncorrectoException {
        if(!GestorVehiculosPermitidos.estaPermitidoElVehiculo(vehiculo)){
            throw new VehiculoIncorrectoException();
        }
    }

    private void existenVehiculos() throws ColaVaciaException {
        if (!hayVehiculos()){
            throw new ColaVaciaException("vehiculos");
        }
    }
}