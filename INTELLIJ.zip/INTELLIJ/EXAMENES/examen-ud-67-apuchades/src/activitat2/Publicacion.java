package activitat2;

public class Publicacion {
    private Cliente cliente;
    private Servicio servicio;
    private String mensaje;

    public Publicacion(Cliente cliente, Servicio servicio, String mensaje){
        this.cliente = cliente;
        this.servicio = servicio;
        this.mensaje = mensaje;
    }

    public String getMensaje() {
        return mensaje;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Servicio getServicio() {
        return servicio;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Publicacion)){
            return false;
        }
        Publicacion publicacion = (Publicacion) obj;
        return cliente.equals(publicacion.getCliente()) && servicio.equals(publicacion.getServicio());
    }
}