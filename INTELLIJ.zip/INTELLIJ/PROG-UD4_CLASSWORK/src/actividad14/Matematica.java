package actividad14;

import java.util.Scanner;

public class Matematica {

    public static boolean esPrimo(int a){

        for (int i = 2; i < -1; i++){

            if (a % i == 0){
                return false;
            }
        }
        return true;
    }
}
