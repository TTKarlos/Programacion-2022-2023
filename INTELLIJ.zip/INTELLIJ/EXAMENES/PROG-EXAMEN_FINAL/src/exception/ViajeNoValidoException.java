package exception;

public class ViajeNoValidoException extends Exception{
    public ViajeNoValidoException(String conViaje){
        super("Viaje " + conViaje + " no registrado. Motivo: Destino no permitido para la agencia.");
    }
}