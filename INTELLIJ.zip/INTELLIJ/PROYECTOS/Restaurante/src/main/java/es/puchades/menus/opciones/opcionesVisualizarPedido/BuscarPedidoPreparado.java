package es.puchades.menus.opciones.opcionesVisualizarPedido;

import es.puchades.Restaurante;

public class BuscarPedidoPreparado extends OpcionesVisualizarPedido {
    protected Restaurante restaurante;

    public BuscarPedidoPreparado(Restaurante restaurante){
        super("Buscar y visualizar pedidos pendientes", restaurante);
        this.restaurante = restaurante;
    }

    @Override
    public void ejecutar() {
        restaurante.buscarPendientes();
    }
}