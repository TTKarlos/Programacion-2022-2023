package view;

import de.vandermeer.asciitable.AT_Row;
import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;
import entities.Mecanico;
import java.util.ArrayList;

public class ViewMecanicos {
    private ArrayList<Mecanico> mecanicos;

    public ViewMecanicos(ArrayList<Mecanico> mecanicos) {
        this.mecanicos = mecanicos;
    }

    private String getTablaMecanicos(){
        AsciiTable table = new AsciiTable();
        AT_Row row;

        table.addRule();
        row = table.addRow(null, null, "Listado de Mecanicos");
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);

        table.addRule();
        row = table.addRow("Numero de Mecanico", "Nombre del Mecanico", "DNI del Mecanico");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);

        for (int i = 0; i < mecanicos.size(); i++) {
            table.addRule();
            row = table.addRow((i + 1), mecanicos.get(i).getNombre(), mecanicos.get(i).getDni());
            row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
            row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        }

        table.addRule();
        row = table.addRow("*", "*", "*");
        row.getCells().get(0).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(1).getContext().setTextAlignment(TextAlignment.CENTER);
        row.getCells().get(2).getContext().setTextAlignment(TextAlignment.CENTER);
        table.addRule();

        return table.render();
    }

    @Override
    public String toString() {
        return getTablaMecanicos();
    }
}