package org.example.enums;

public enum TamanyoDeBebida {
    GRANDE,
    MEDIANA,
    PEQUENYA,
}