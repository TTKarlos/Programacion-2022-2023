import java.time.LocalDateTime;
import java.util.Objects;

public class Voto {
    private String dni;
    private LocalDateTime fechaVoto;
    private Partido partido;

    public Voto(String dni, Partido partido) {
        this.dni = dni;
        this.partido = partido;
        this.fechaVoto = LocalDateTime.now();
    }

    public Voto(String dni){
        this.dni = dni;
    }

    public Partido getPartido() {
        return partido;
    }

    public String getDni() {
        return dni;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Voto voto)) return false;
        return Objects.equals(dni, voto.dni);
    }
}