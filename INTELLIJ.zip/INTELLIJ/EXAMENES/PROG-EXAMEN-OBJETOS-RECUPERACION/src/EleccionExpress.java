import exceptions.VotoInvalidoException;

import java.time.LocalDate;
import java.util.ArrayList;

public class EleccionExpress extends Eleccion{
    public EleccionExpress(ArrayList<Partido> partidos, LocalDate diaVotacion) {
        super(partidos, diaVotacion);
    }

    @Override
    public void generarMesaElectoral(){
        super.generarMesaElectoral();
        ArrayList<String> dni = generar15Votantes();
        MesaElectoral mesaElectoral = new MesaElectoral("E-" + mesasElectorales.size() + 1, dni);
        comprobarMesasElectorales();
        mesasElectorales.add(mesaElectoral);
    }

    @Override
    public void votar(String dni, Partido partido){
        for (int i = 0; i < mesasElectorales.size(); i++) {
            for (int j = 0; j < mesasElectorales.get(i).getCiudadanosConvocados().size(); j++) {
                if(mesasElectorales.get(i).getCiudadanosConvocados().get(i).equalsIgnoreCase(dni)){
                    if(diaVotacion.isEqual(LocalDate.now())){
                        Voto voto = new Voto(dni, partido);
                        mesasElectorales.get(i).depositarVoto(voto);
                        return;
                    } else {
                        throw new VotoInvalidoException("Error! el plazo ha concluido");
                    }
                }
            }
        }

        throw new VotoInvalidoException("Error el dni " + dni + " no esta convocado en ninguna mesa");

    }
}