import java.util.Scanner;

public class Activitat1 {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        int[] numero = new int[11];

        for (int i = 0; i <= numero.length; i++){

            System.out.printf("Introdueix el numero %d: ", i);

            numero[i] = teclado.nextInt();
        }

        for(int i = 0; i <= numero.length; i++){
            System.out.printf("Numero %d: %d\n", i, numero[i]);

        }
    }
}