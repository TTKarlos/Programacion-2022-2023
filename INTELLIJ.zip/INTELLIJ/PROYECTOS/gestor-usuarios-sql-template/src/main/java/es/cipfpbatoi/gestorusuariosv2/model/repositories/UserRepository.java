package es.cipfpbatoi.gestorusuariosv2.model.repositories;

import es.cipfpbatoi.gestorusuariosv2.exceptions.NotFoundException;
import es.cipfpbatoi.gestorusuariosv2.exceptions.UserNotFoundException;
import es.cipfpbatoi.gestorusuariosv2.model.dao.SQLUserDAO;
import es.cipfpbatoi.gestorusuariosv2.model.dao.interfaces.UserDAO;
import es.cipfpbatoi.gestorusuariosv2.model.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;

@Service
public class UserRepository {
    @Autowired
    EmpresaRepository empresaRepository;
    @Autowired
    UserDAO userDAO;

    public UserRepository(@Autowired SQLUserDAO sqlUserDAO) {
        this.userDAO = sqlUserDAO;
    }

    public void add(User usuario) {
        userDAO.save(usuario);
    }

    public ArrayList<User> findAll() {
        return userDAO.findAll();
    }

    public ArrayList<User> findAll(String searchField) {
        return userDAO.findAll(searchField);
    }

    public ArrayList<User> findAllWithEnterprises(){
        ArrayList<User> listUsers = findAll();

        for (int i = 0; i < listUsers.size(); i++) {
            listUsers.get(i).setEmpresa(empresaRepository.getById(listUsers.get(i).idEmpresa()));
        }

        return listUsers;
    }

    public User findWithEnterprises(int id){
        User user = findById(id);
        user.setEmpresa(empresaRepository.getById(findById(id).idEmpresa()));
        return user;
    }

    public User getById(int id) {
        User user = findById(id);
        if (user == null) {
            throw new UserNotFoundException(id);
        }
        return user;
    }

    public User findById(int id) {
        return userDAO.findById(id);
    }

    public void remove(User user) {
        userDAO.remove(user);
    }
}