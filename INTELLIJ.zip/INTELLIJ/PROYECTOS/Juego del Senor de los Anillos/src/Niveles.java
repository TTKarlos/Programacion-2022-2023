import java.util.Scanner;

public class Niveles {

    final static String NOM_GANDALF = "\uD83E\uDDD9"+ "GANDALF";
    final static String NOM_FRODO = "\uD83C\uDFC7"+ "FRODO";
    final static String NOM_SAM = "\uD83E\uDDD4"+ "SAM";
    final static String NOM_HOBBITS = "\uD83E\uDDDD"+ "HOBBITS";
    final static String NOM_MERRY = "\uD83D\uDC71"+"MERRY";
    final static String NOM_PIPPIN = "\uD83E\uDDD1"+"PIPPIN";
    final static String NOM_GOLLUM = "\uD83D\uDC7D"+"GOLLUM";
    final static String NOM_SAURON = "\uD83E\uDD34"+"SAURON";
    final static String RESET_COLOR = "\u001B[0m";
    final static String COLOR_AZUL = "\u001B[34m";
    final static String COLOR_ROJO = "\u001B[31m";
    final static String COLOR_MORADO = "\u001B[35m";
    final static String TITULO_PERSONALIZADO = COLOR_AZUL+"EL SEÑOR DE LOS ANILLOS"+RESET_COLOR;
    final static String COLOR_GROC = "\u001B[33m";
    final static String ESPAI_EN_BLANC = " ";

    //************************************************ INICI ************************************************\\

    public static void borrarEscrito(){
/**
         for (int i = 0; i < 50; i++){
         System.out.println("\r");
         }
**/
    }

    //************************************************ PERDRE ************************************************\\

    public static void perdre(){
        System.out.println("Desgraciadamente, la aventura ha acabado y el mundo vuelve a" +
                " ser un lugar inseguro. ¡Una lástima!");
    }

    //************************************************ GUANYAR ************************************************\\

    public static void guanyar(){
        System.out.println("¡¡Enhorabuena hobbits!! Habéis conseguido destruir el anillo mágico.\n" +
                "El mundo vuelve a respirar tranquilo. ¡Hasta otra amigos!");
    }

    //************************************************ FI ************************************************\\

    public static void fi(){
        System.out.println("Adiós");
    }

    //************************************************ INICI ************************************************\\

    public static boolean inici (){
        System.out.println(COLOR_GROC + "         ___ . .  _\n" +
                "\"T$$$P\"   |  |_| |_\n" +
                " :$$$     |  | | |_\n" +
                " :$$$                                                      \"T$$$$$$$b.\n" +
                " :$$$     .g$$$$$p.   T$$$$b.    T$$$$$bp.                   BUG    \"Tb      T$b      T$P   .g$P^^T$$  ,gP^^T$$ \n" +
                "  $$$    d^\"     \"^b   $$  \"Tb    $$    \"Tb    .s^s. :sssp   $$$     :$; T$$P $^b.     $   dP\"     `T :$P    `T\n" +
                "  :$$   dP         Tb  $$   :$;   $$      Tb  d'   `b $      $$$     :$;  $$  $ `Tp    $  d$           Tbp.   \n" +
                "  :$$  :$;         :$; $$   :$;   $$      :$; T.   .P $^^    $$$    .dP   $$  $   ^b.  $ :$;            \"T$$p.  \n" +
                "  $$$  :$;         :$; $$...dP    $$      :$;  `^s^' .$.     $$$...dP\"    $$  $    `Tp $ :$;     \"T$$      \"T$b \n" +
                "  $$$   Tb.       ,dP  $$\"\"\"Tb    $$      dP \"\"$\"\"$\" \"$\"$^^  $$$\"\"T$b     $$  $      ^b$  T$       T$ ;      $$;\n" +
                "  $$$    Tp._   _,gP   $$   `Tb.  $$    ,dP    $  $...$ $..  $$$   T$b    :$  $       `$   Tb.     :$ T.    ,dP \n" +
                "  $$$;    \"^$$$$$^\"   d$$     `T.d$$$$$P^\"     $  $\"\"\"$ $\"\", $$$    T$b  d$$bd$b      d$b   \"^TbsssP\" 'T$bgd$P  \n" +
                "  $$$b.____.dP                                 $ .$. .$.$ss,d$$$b.   T$b.                                       \n" + RESET_COLOR);

        System.out.println("                                             ___________________________ \n" +
                "   _______________________-------------------                            `\\\n" +
                " /:--__                                                                    |\n" +
                "||< > |                                   _______________________________/\n" +
                "| \\__/_________________-------------------                           |\n" +
                "|                                                                     |\n" +
                " |                       "+TITULO_PERSONALIZADO+"                      |\n" +
                " |                                                                     |\n" +
                " |  Era un día tranquilo en Hobbiton. Todos los hobbits preparaban la  |\n" +
                "  |  fiesta aniversario de la destrucción del anillo que liberó a toda la|\n" +
                "  |  Tierra Media del reinado negro de Sauron.                            |\n" +
                "  |  Nuestro héroe Frodo, junto a sus amigos, se encargaban de decorar    |\n" +
                "  |  la cueva del ya anciano Bilbo Bolsón.                                |\n" +
                "  |  De repente, una silueta conocida se dejó ver por la ventana….         |\n"+
                "   |  ¡Oh no! ¡Gandalf! Siempre que aparece ese viejo mago, nunca trae     |\n" +
                "   |  buenas noticias….                                                    |\n" +
                "   |  Éste pidió reunirse urgentemente con Frodo y sus compañeros Sam,     |\n" +
                "   |  Merry y Pippin. Tras su charla, los hobbits confirmaron los peores   |\n" +
                "   |  augurios… Les contó que el anillo no había sido destruido, que no    |\n" +
                "   |  sabe cómo, pero Gollum lo poseía de nuevo en su cueva y lo pagina 3. |\n" +
                "   |  sabe cómo, pero Gollum lo poseía de nuevo en su cueva y lo             |\n" +
                "   |  guardaba para que nadie se lo quitase.                                 |\n" +
                "   |  "+NOM_GANDALF + ": Por favor hobbits, debéis encargaros de encontrarlo y|\n" +
                "   |  destruirlo de nuevo en el Monte del Destino de Mordor pero esta vez,    |\n" +
                "   |  no podéis fallar.                                                      |\n" +
                "  |                                              ______________________________|\n" +
                "  |  ___________________-------------------------                              `\\\n" +
                "  |/`--_                                                                         |\n" +
                "  ||[ ]||                                            _________________________-/\n" +
                "   \\===/___________________--------------------------\n");

        System.out.print(COLOR_AZUL +"¿Quieres que Frodo y sus compañeros acepten el reto de Gandalf y\n" +
                "vayan a buscar el anillo para destruirlo? (SÍ / NO): " + RESET_COLOR);

        return comprovarSioNo();
    }

    public static boolean comprovarSioNo(){

        Scanner teclado = new Scanner(System.in);

        boolean esCorrecte = false;
        String nom;

        do{
            if (esCorrecte){
                System.out.print(COLOR_ROJO + "Introdueix sols SI/NO -->" + RESET_COLOR);
            }

            nom = teclado.next();

            if (nom.equalsIgnoreCase("si") || nom.equalsIgnoreCase("no")){
                esCorrecte = false;
            } else {
                esCorrecte =true;
            }

        } while (esCorrecte);

        if (nom.equalsIgnoreCase("si")){
            return true;
        } else {
            return false;
        }
    }

    //************************************************ NIVEL 1 ************************************************\\

    public static boolean nivel1(){
        System.out.println("                    / \\\n" +
                "                   / | \\  "+NOM_FRODO + ": ¡Muy bien! Vamos a buscar a ese granuja de Gollum. Le\n" +
                "                  /  |  \\   robaremos el anillo y esta vez lo destruiremos. No fue fácil entonces,\n" +
                "                 |   |   |    ni tampoco ahora, pero  lo conseguiremos, ¿verdad, chicos? \n" +
                "                 |   |   |  "+NOM_SAM + ": ¡Sí! ¡Vamos! Pero… debemos preparar todo lo necesario para\n" +
                "                 |   |   |    afrontar de nuevo los diferentes desaf+íos que se nos van a proponer.\n" +
                "                 |   |   |    Botas, guantes, agua para el camino, y p….. ¡No hay pan señor\n" +
                "                 |   |   |    Frodo!.\n" +
                "                 |   |   |   "+NOM_FRODO +": Los sacos de trigo no llegan hasta la semana que viene y nos\n" +
                "                 |   |   |    hace falta pan para salir mañana de manera urgente.\n" +
                "                 |   |   |   "+NOM_GANDALF +": Os propongo un juego. Si lo ganáis os diré mi conjuro\n" +
                "                 |   |   |    panadero con el que podréis crear todos los panes que queráis.\n" +
                "                 |   |   |\n" +
                "                 |   |   |\n" +
                "                 |   |   |\n" +
                "                 |   |   |                      .____---^^     ^^---____.\n" +
                "                 |   |   |                      TI      *       *      IT\n" +
                "                 |   |   |                      !I          *          I!\n" +
                "                 |  / \\  |                       X                     X\n" +
                "/\\               |/     \\|               /\\      XL         ?         JX\n" +
                "\\ \\_____________/         \\_____________/ /      II    ?   / \\   ?    II\n" +
                " \\______________\\         /______________/       II   / \\ /   \\ / \\   II\n" +
                "                 \\       /                        X  /   v     v   \\  X\n" +
                "                 |\\\\   //|                        ``/    _     _    \\''\n" +
                "                 |//\\ ///|                         \\\\- _-_ -_- _-_ -//\n" +
                "                 |///////|                           \\\\_-  -_-  -_//\n" +
                "                 |///////|                             ``       ''\n" +
                "                 |///////|                               ``-_-''\n" +
                "                 |///////|\n" +
                "                 |///////|\n" +
                "                 |///////|\n" +
                "                / \\/\\_/\\/ \\\n" +
                "               |\\_/\\/ \\/\\_/|\n" +
                "               |/ \\/\\ /\\/ \\|\n" +
                "                \\_/\\/_\\/\\_/\n" +
                "                  \\_/_\\_/");

        StringBuilder cadenaAleatoria = new StringBuilder(cadenaAleatoria());
        int intentos = 1;

        do{
            if(intentos > 1){
                System.out.printf("INTENTO %d:\n==========\n", intentos);
            }

            int numeroAleatori = (int)(Math.random()*2+1);
            for (int i = 1; i < numeroAleatori + 3 ; i++) {
                int numeroAleatori2 = (int)(Math.random()*20+0);
                cadenaAleatoria.replace(numeroAleatori2, numeroAleatori2, ESPAI_EN_BLANC);
            }

            int contadorParelles = contadorDeVocals(cadenaAleatoria);

            System.out.printf(COLOR_AZUL + "Di quantes parelles de vocals te \"%s\": %s", cadenaAleatoria, RESET_COLOR);
            int numIntroduit = comprovadorDeNumeros();

            if (numIntroduit == contadorParelles){
                return true;
            }

            intentos++;

        } while(intentos <= 3);

        return false;
    }

    public static int contadorDeVocals(StringBuilder cadenaAleatoria) {
        int contadorParelles = 0;
        int contador = 0;

        for (int i = 0; i < cadenaAleatoria.length(); i++) {

            String posicio = String.valueOf(cadenaAleatoria.charAt(i));

            if (posicio.equalsIgnoreCase("a") || posicio.equalsIgnoreCase("e") ||
                    posicio.equalsIgnoreCase("i") || posicio.equalsIgnoreCase("o") ||
                    posicio.equalsIgnoreCase("u")) {
                contador++;
            } else {
                contador = 0;
            }

            if (contador >= 2) {
                contadorParelles++;
                contador--;
            }
        }

        return contadorParelles;
    }

    public static StringBuilder cadenaAleatoria(){
        String alfabet = "abcdefghijklmnopqrstuvwxyz";
        StringBuilder cadenaAleatoria = new StringBuilder();

        for (int i=0; i < 20; i++){
            int numeroAleatori = (int)(Math.random()*25+0);
            cadenaAleatoria.append(alfabet.charAt(numeroAleatori));
        }

        return cadenaAleatoria;
    }

    public static int comprovadorDeNumeros() {

        Scanner teclado = new Scanner(System.in);

        boolean esCorrecte = true;
        String num;

        do {
            if (!esCorrecte) {
                System.out.print(COLOR_ROJO + "Introdueix sols Numeros --> " + RESET_COLOR);
            }

            num = teclado.next();

            esCorrecte = false;

            for (int i = 0; i < num.length(); i++) {
                String posicio = String.valueOf(num.charAt(i));
                if (posicio.equals("0") || posicio.equals("1") || posicio.equals("2") || posicio.equals("3") ||
                        posicio.equals("5") || posicio.equals("6") || posicio.equals("7") || posicio.equals("8") ||
                        posicio.equals("9")){
                    esCorrecte = true;
                }
            }
        }while (!esCorrecte) ;

        return Integer.parseInt(num);
    }

    //************************************************ NIVEL 2 ************************************************\\

    public static boolean nivel2(){

        System.out.println(COLOR_AZUL+"    .       ..       .\n" +
                          "    |\\      ||      /|\n" +
                          "    | \\     ||     / |\n" +
                          "    |  \\    ||    /  |\n" +
                          "    |  :\\___JL___/   |\n" +
                          "    |  :|##XLJ: :|   |\n" +
                          "    '\\ :|###||: X|  /'\n" +
                          "      \\:|###||:X#| /\n" +
                          "       |==========|\n" +
                          "        |###XXX;;|\n" +
                          "        |##XX:: :|\n" +
                          "        |##Xn:: :|\n" +
                          "        |##XU:: :|\n" +
                          "        |##XX:: :|\n" +
                          "        |##XX:: :|   "+RESET_COLOR+NOM_GANDALF +": Sois unos cracks de las letras. Aquí va el conjuro:\n" +
        COLOR_AZUL+       "        |##XX:: n|   "+RESET_COLOR+"Abracadabra, abracadero, ¡barras de pan ricas de panadero!\n" +
        COLOR_AZUL+       "        |##XX:: U|   "+RESET_COLOR+"Ahora ya tenéis todo lo necesario para el viaje. ¡Buena suerte hobbits!\n" +
        COLOR_AZUL+       "        |##XX:: :|   "+RESET_COLOR+NOM_HOBBITS+": ¡Sí! ¡Vamos amigos!\n" +
        COLOR_AZUL+       "        |##XX:: :|   "+RESET_COLOR+"Ya de camino a las Montañas Nubladas donde se encuentra la ncaverna de\n" +
        COLOR_AZUL+       "        |##XX:: :|   "+RESET_COLOR+"Gollum, los hobbits debían atravesar las minas de Moria, pero... \n" +
        COLOR_AZUL+       "        |##Xn:: :|   "+RESET_COLOR+NOM_MERRY+": ¡Oh, dios mío! La puerta está cerrada, no podemos pasar.\n" +
        COLOR_AZUL+       "        |##XU:: :|   "+RESET_COLOR+NOM_PIPPIN+": Fijaos, aquí en la puerta pone.. 'Para poder entrar, la mezcla\n" +
        COLOR_AZUL+       "        |##XX:: :|   "+RESET_COLOR+"sagrada de estas dos frases deberas realizar. Si no lo consigues,\n" +
        COLOR_AZUL+       "        |##XX:: :|   "+RESET_COLOR+"nunca podrás pasar.\n" +
        COLOR_AZUL+       "        |##XX:: :|   "+RESET_COLOR+NOM_SAM+": ¿Y qué demonios es la mezcla sagrada?\n" +
        COLOR_AZUL+       "        |##XX:: n|   "+RESET_COLOR+NOM_FRODO+": ¡Ay Sam…! ¿No te acuerdas? Recuerda aquello que naprendimos en\n" +
        COLOR_AZUL+       "        |##XX:: U|   "+RESET_COLOR+"Rivendell. Una mezcla sagrada equivale al primero ncon el último, el segundo\n" +
        COLOR_AZUL+       "        |##XX:: :|   "+RESET_COLOR+"on el penúltimo, y así hasta el final.\n" +
        COLOR_AZUL+       "        |##XX:: :|\n" +
                          "        |##XX:: :|\n" +
                          "        |##Xn:: :|\n" +
                          "        |##XX:: :|\n" +
                          "        |##,_,: :|\n" +
                          "        |./ T \\.:|\n" +
                          "        || o|o |:|\n" +
                          "        ||  |  |:|\n" +
                          "      .============.\n" +
                          "     .==============.\n" +
                          "    .================."+RESET_COLOR);

        int intentos = 1;
        StringBuilder cadenaAleatoria1 = new StringBuilder(paraulaDe5LetrasAleatoria());
        StringBuilder cadenaAleatoria2 = new StringBuilder(paraulaDe5LetrasAleatoria());
        StringBuilder cadenaFinal = new StringBuilder();

        do{
            if(intentos > 1){
                System.out.printf("INTENTO %d:\n==========\n", intentos);
            }

            for (int i = 0; i < 5; i++){
                cadenaFinal.append(cadenaAleatoria1.charAt(i));
                int posicio = 4 - i;
                cadenaFinal.append(cadenaAleatoria2.charAt(posicio));
            }

            System.out.printf(COLOR_AZUL + "La mescla sagrada de les cadenes de caràcters " + cadenaAleatoria1 + " i " +
                    cadenaAleatoria2 + " correspon a la cadena: " + RESET_COLOR);
            String nomIntroduit = comprovarCadenaDe10Caracters();

            if (cadenaFinal.compareTo(new StringBuilder(nomIntroduit)) == 0){
                return true;
            }

            intentos++;

        } while(intentos <= 3);

        return false;
    }

    public static String comprovarCadenaDe10Caracters(){
        Scanner teclado = new Scanner(System.in);

        boolean esCorrecte = false;
        String nomIntroduit;

        do {
            if (esCorrecte) {
                System.out.print(COLOR_ROJO + "Introdueix 10 caracters --> " + RESET_COLOR);
            }

            nomIntroduit = teclado.next();

            esCorrecte = false;

            if(nomIntroduit.length() != 10){
                esCorrecte = true;
            }

        }while (esCorrecte) ;

        return nomIntroduit;
    }

    public static StringBuilder paraulaDe5LetrasAleatoria (){

        StringBuilder cadenAleatoria = new StringBuilder();

        for (int i = 1; i <= 5; i++){
            String alfabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            int numeroAleatori = (int)(Math.random()*61+0);
            cadenAleatoria.append(alfabet.charAt(numeroAleatori));
        }

        return cadenAleatoria;
    }

    //************************************************ NIVEL 3 ************************************************\\

    public static boolean nivel3(){

        Scanner teclado = new Scanner(System.in);
        System.out.println("                         `-.\n" +
                "              -._ `. `-.`-. `-.\n" +
                "             _._ `-._`.   .--.  `.\n" +
                "          .-'   '-.  `-|\\/    \\|   `-.\n" +
                "        .'         '-._\\   (o)O) `-.\n" +
                "       /         /         _.--.\\ '. `-. `-.\n" +
                "      /|    (    |  /  -. ( -._( -._ '. '.\n" +
                "     /  \\    \\-.__\\ \\_.-'`.`.__'.   `-, '. .'\n" +
                "     |  /\\    |  / \\ \\     `--')/  .-'.'.'\n" +
                " .._/  /  /  /  / / \\ \\          .' . .' .'\n" +
                "/  ___/  |  /   \\ \\  \\ \\__       '.'. . .\n" +
                "\\  \\___  \\ (     \\ \\  `._ `.     .' . ' .'\n" +
                " \\ `-._\\ (  `-.__ | \\    )//   .'  .' .-'\n" +
                "  \\_-._\\  \\  `-._\\)//    \"\"_.-' .-' .' .'\n" +
                "    `-'    \\ -._\\ \"\"_..--''  .-' .'\n" +
                "            \\/    .' .-'.-'  .-' .-'\n" +
                "                .-'.' .'  .' .-'\n");
        System.out.printf(NOM_SAM +": Las puertas se abren señor Frodo. ¡Seguimos con nuestra\nmisión!\n" +
                "Los hobbits atravesaron las minas dejando atrás una manada de\nOrcos malolientes que consiguieron" +
                " esquivar gracias a la capa\nmágica de Frodo. Una vez fuera, los hobbits se dirigieron a la" +
                " caverna\nde Gollum que no tardaron en encontrar.\n" +
                NOM_MERRY +": Por fin te encontramos Gollum! Devuélveme el anillo. Lo\ndebemos destruir por el" +
                " bien de toda Tierra Media.\n" +
                NOM_GOLLUM +": ¡Malditos seáis hobbits!. Es mi tessssoro. Lo he guardado en\neste cofre y para" +
                " poder abrirlo debéis responder resolver el enigma\nque aparece en su display. ¡Nunca lo podréis" +
                " resolver! . Podéis\nintentarlo, pero no lo vais a conseguir… ¡jamás!\n" +
                NOM_FRODO +": Veamos qué pone en este dichoso display. Chicos, aquí\naparecen y desaparecen " +
                "palabras. y luego me lanza una pregunta.\nVaya, qué complicado….\n" +
                COLOR_AZUL + "Memoriza los 5 caracteres que correspondan a los índices mostrados.\n" +
                "Estas preparado: " + RESET_COLOR);

        boolean esCorrecte;
        int intentos = 1;
        String cadenaFinal;
        String cadenaIntroduida;

        do{
            if(intentos > 1){
                System.out.printf("INTENTO %d:\n==========\n", intentos);
            }

            System.out.print(COLOR_AZUL + "Memoriza los 5 caracteres que correspondan a los índices mostrados.\n" +
                    "Estas preparado: " + RESET_COLOR);

            do{
                if(comprovarSioNo()){
                    esCorrecte = false;
                } else {
                    System.out.print(COLOR_ROJO + "No te preocupes te esperamos.\n" + RESET_COLOR + COLOR_AZUL +
                            "Estas preparado: " + RESET_COLOR);
                    esCorrecte = true;
                }
            } while (esCorrecte);

            System.out.println(COLOR_AZUL + "Memoriza los 5 caracteres que correspondan a los índices mostrados:"
                    + RESET_COLOR);

            StringBuilder cadenaAleatoria1 = cadenaAleatoriaAmbSimbols();
            StringBuilder cadenaAleatoria2 = cadenaAleatoriaAmbSimbols();
            StringBuilder cadenaAleatoria3 = cadenaAleatoriaAmbSimbols();
            StringBuilder cadenaAleatoria4 = cadenaAleatoriaAmbSimbols();
            StringBuilder cadenaAleatoria5 = cadenaAleatoriaAmbSimbols();

            int index1 = (int) (Math.random()*4+0);
            int index2 = (int) (Math.random()*4+0);
            int index3 = (int) (Math.random()*4+0);
            int index4 = (int) (Math.random()*4+0);
            int index5 = (int) (Math.random()*4+0);

            salirPorPantallaCada2Segundos(cadenaAleatoria1, cadenaAleatoria2, cadenaAleatoria3, cadenaAleatoria4,
                    cadenaAleatoria5, index1, index2, index3, index4, index5);

            cadenaFinal = String.valueOf(cadenaAleatoria1.charAt(index1)) +
                    String.valueOf(cadenaAleatoria2.charAt(index2)) + String.valueOf(cadenaAleatoria3.charAt(index3)) +
                    String.valueOf(cadenaAleatoria4.charAt(index4)) + String.valueOf(cadenaAleatoria5.charAt(index5));

            System.out.print(COLOR_AZUL + "\r\nDebes escribir todos juntos: " + RESET_COLOR);
            cadenaIntroduida = comprovarCadenaDe5Caracters();

            intentos++;

            if(cadenaIntroduida.equals(cadenaFinal)){
                return true;
            }

        } while(intentos <= 3);

        return false;
    }

    public static String comprovarCadenaDe5Caracters(){
        Scanner teclado = new Scanner(System.in);

        boolean esCorrecte = false;
        String nomIntroduit;

        do {
            if (esCorrecte) {
                System.out.print(COLOR_ROJO + "Introdueix 5 caracters --> " + RESET_COLOR);
            }

            nomIntroduit = teclado.next();

            esCorrecte = false;

            if(nomIntroduit.length() != 5){
                esCorrecte = true;
            }

        }while (esCorrecte) ;

        return nomIntroduit;
    }

    public static void salirPorPantallaCada2Segundos(StringBuilder cadenaAleatoria1, StringBuilder cadenaAleatoria2,
                                                      StringBuilder cadenaAleatoria3,StringBuilder cadenaAleatoria4,
                                                      StringBuilder cadenaAleatoria5, int index1, int index2,
                                                      int index3, int index4, int index5){

        System.out.printf("Cadena 1 --> %s (%d)", cadenaAleatoria1, index1);
        delay(2000);
        System.out.print("\r");
        System.out.printf("Cadena 2 --> %s (%d)", cadenaAleatoria2, index2);
        delay(2000);
        System.out.print("\r");
        System.out.printf("Cadena 3 --> %s (%d)", cadenaAleatoria3, index3);
        delay(2000);
        System.out.print("\r");
        System.out.printf("Cadena 4 --> %s (%d)", cadenaAleatoria4, index4);
        delay(2000);
        System.out.print("\r");
        System.out.printf("Cadena 5 --> %s (%d)", cadenaAleatoria5, index5);
        delay(2000);
        System.out.print("\r");
        System.out.print("\r");
    }

    public static void delay(long milis){
        try {
            Thread.sleep(milis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static StringBuilder cadenaAleatoriaAmbSimbols() {

        StringBuilder cadena = new StringBuilder("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ$!€&<>¡%");
        StringBuilder cadenaAleatoria = new StringBuilder();

        for (int i = 0; i < 5; i++) {
            cadenaAleatoria.append(cadena.charAt((int) (Math.random() * 59 + 1)));
        }

        return cadenaAleatoria;
    }

    //************************************************ NIVEL 4 ************************************************\\

    public static boolean nivel4(){
        System.out.printf(NOM_FRODO +" :  ¡¡Yeehaaa!! ¡Hemos abierto el cofre! El anillo ya está en\nnuestro poder." +
                " Ahora debemos llevarlo a la montaña de Sauron para\ndestruirlo y esta vez para siempre.\n" +
                NOM_SAM +" : Démonos prisa. El tiempo se acaba. Vayamos a Mordor a\ndestruirlo.\n" +
                "Los hobbits se presentaron allí raudos y veloces, pero se encontraron\nde nuevo ante las peligrosas" +
                " y enigmáticas puertas de Mordor.\n" +
                NOM_PIPPIN + " : ¡Wow! No las recordaba así.\n" +
                NOM_MERRY + " : Y yo no las recordaba cerradas.\n" +
                NOM_FRODO +" : No os preocupéis. Ya logré atravesarlas una vez, y esta vez\nno será menos. " +
                "Respondamos a esta pregunta que aparece en la\npuerta y la puerta se abrirá de par en par.\n");

        int intentos = 1;

        do{

            if(intentos >= 2){
                System.out.printf("INTENTO %d:\n==========\n", intentos);
            }

            StringBuilder cadena1 = cadenaAleatoriaDeVocals5();
            StringBuilder cadena2 = cadenaAleatoriaDeVocals5();
            StringBuilder cadena3 = cadenaAleatoriaDeVocals5();
            StringBuilder cadenaComprovar = cadenaAleatoriaDeVocals2();

            int numVocals1 = contadorDeVocals2(cadena1, cadenaComprovar);
            int numVocals2 = contadorDeVocals2(cadena2, cadenaComprovar);
            int numVocals3 = contadorDeVocals2(cadena3, cadenaComprovar);

            System.out.printf(COLOR_AZUL + "Cuantas veces coicide la cadena \"%s\" con la cadena \"%s\": %s",
                    cadenaComprovar, cadena1, RESET_COLOR);
            int numIntroduirt1 = comprovadorDeNumeros();
            System.out.printf(COLOR_AZUL + "Cuantas veces coicide la cadena \"%s\" con la cadena \"%s\": %s",
                    cadenaComprovar, cadena2, RESET_COLOR);
            int numIntroduirt2 = comprovadorDeNumeros();
            System.out.printf(COLOR_AZUL + "Cuantas veces coicide la cadena \"%s\" con la cadena \"%s\": %s",
                    cadenaComprovar, cadena3, RESET_COLOR);
            int numIntroduirt3 = comprovadorDeNumeros();

            StringBuilder cadenaComprovarInvertit = new StringBuilder(cadenaComprovar.substring(1) +
                    cadenaComprovar.substring(0,1));

            int numVocalsInvertit1 = contadorDeVocals2(cadena1, cadenaComprovarInvertit);
            int numVocalsInvertit2 = contadorDeVocals2(cadena2, cadenaComprovarInvertit);
            int numVocalsInvertit3 = contadorDeVocals2(cadena3, cadenaComprovarInvertit);

            System.out.printf(COLOR_AZUL + "\nCuantas veces coicide la cadena \"%s\" con la cadena \"%s\": %s",
                    cadenaComprovarInvertit, cadena1, RESET_COLOR);
            int numIntroduirtInvertit1 = comprovadorDeNumeros();
            System.out.printf(COLOR_AZUL + "Cuantas veces coicide la cadena \"%s\" con la cadena \"%s\": %s",
                    cadenaComprovarInvertit, cadena2, RESET_COLOR);
            int numIntroduirtInvertit2 = comprovadorDeNumeros();
            System.out.printf(COLOR_AZUL + "Cuantas veces coicide la cadena \"%s\" con la cadena \"%s\": %s",
                    cadenaComprovarInvertit, cadena3, RESET_COLOR);
            int numIntroduirtInvertit3 = comprovadorDeNumeros();

            if (numVocals1 == numIntroduirt1 && numVocals2 == numIntroduirt2 && numVocals3 == numIntroduirt3 &&
                    numVocalsInvertit1 == numIntroduirtInvertit1 && numVocalsInvertit2 == numIntroduirtInvertit2 &&
                    numVocalsInvertit3 == numIntroduirtInvertit3){
                return true;
            }

            intentos++;

        } while (intentos <= 3);

        return false;
    }

    public static int contadorDeVocals2(StringBuilder cadena, StringBuilder cadenaComrpovar){
        int contador = 0;

        for (int i = 0; i < cadena.length() - 1; i++){
            String posicio = cadena.substring(i, i+2);

            if(posicio.equalsIgnoreCase(String.valueOf(cadenaComrpovar))){
                contador++;
            }
        }

        return contador;
    }

    public static StringBuilder cadenaAleatoriaDeVocals5(){

        String cadena = "aeiou";
        StringBuilder cadenaAleatoria = new StringBuilder();

        for (int i=0; i < 5; i++){
            int numeroAleatori = (int)(Math.random()*5+0);
            cadenaAleatoria.append(cadena.charAt(numeroAleatori));
        }

        return cadenaAleatoria;
    }

    public static StringBuilder cadenaAleatoriaDeVocals2(){

        String cadena = "aeiou";
        StringBuilder cadenaAleatoria = new StringBuilder();

        for (int i=0; i < 2; i++){
            int numeroAleatori = (int)(Math.random()*5+0);
            cadenaAleatoria.append(cadena.charAt(numeroAleatori));
        }

        return cadenaAleatoria;
    }

    //************************************************ NIVEL 5 ************************************************\\

    public static boolean nivel5(){

        Scanner teclado = new Scanner(System.in);

        System.out.printf(NOM_SAM + ": ¡Bravo señor Frodo!. Vayamos al precipicio de Mordor para\ndestruir este " +
                "maldito anillo de una vez.\n" +
                "Nuestros amigos estaban a punto de conseguir su objetivo, cuando\nde repente, vieron que el aura" +
                " con el ojo de Sauron gobernaba el\nacceso al precipicio de lava de Mordor. El ojo empezó" +
                " a\ndeslumbrarles. Casi no podían mirar. Sólo podían oír su voz que les\ndecía:\n" +
                NOM_SAURON +": Malvados hobbits… no pensaba veros de nuevo por aquí.\nVeo que transportais" +
                " el anillo que yo forjé para gobernarlos a todos.\nYa lo logré salvar de este precipicio" +
                " de lava aquella vez pero veo que\nno lo he logrado. Sabía que no podía confiar en ese" +
                " apestoso de\nGollum. Sólo os dejaré pasar por delante de mí si respondéis a esta\npregunta:\n" +
                COLOR_AZUL + "Cifra las dos cadenas mostradas a continuación:\n" + RESET_COLOR);

        int intentos = 1;

        do{

            if (intentos >= 2){
                System.out.printf("INTENTOS %d:\n==========\n",intentos);
            }

            System.out.print(COLOR_AZUL + "Cifra las dos cadenas mostradas a continuación:\n" + RESET_COLOR);

            StringBuilder cadenaAleatoria1 = cadenaEntre6I12caracters();
            StringBuilder cadenaAleatoria2 = cadenaEntre6I12caracters();

            StringBuilder cadenaAleatoriaGenerada1 = cambiarCadenaNivel5(new StringBuilder(cadenaAleatoria1));
            StringBuilder cadenaAleatoriaGenerada2 = cambiarCadenaNivel5(new StringBuilder(cadenaAleatoria2));

            System.out.printf("Cadena 1: %s\nCadena 2: %s\n\n%sCifra las cadenas:%s\n",cadenaAleatoria1, cadenaAleatoria2,
                    COLOR_AZUL, RESET_COLOR);

            System.out.print("Cadena Cifrada 1: ");
            String cadenaintroducida1 = teclado.next();
            System.out.print("Cadena Cifrada 2: ");
            String cadenaintroducida2 = teclado.next();

            if (cadenaintroducida1.compareTo(String.valueOf(cadenaAleatoriaGenerada1)) == 0){
                if (cadenaintroducida2.compareTo(String.valueOf(cadenaAleatoriaGenerada2)) == 0){
                    return true;
                }
            }

            intentos++;

        } while(intentos <= 3);

        return false;
    }

    public static StringBuilder cambiarCadenaNivel5(StringBuilder cadena){

        String cadenaAlfabet = "/0123456789:'abcdefghijklmnopqrstuvwxyz{@ABCDEFGHIJKLMNOPQRSTUVWXYZ[";
        StringBuilder cadenaGenerada = new StringBuilder();

        for (int i = 0; i < cadena.length(); i++){
            String posicio = String.valueOf(cadena.charAt(i));
            if (i % 2 != 0){
                cadenaGenerada.append(cadenaAlfabet.charAt(cadenaAlfabet.indexOf(posicio) - 1));
            } else {
                cadenaGenerada.append(cadenaAlfabet.charAt(cadenaAlfabet.indexOf(posicio) + 1));
            }
        }

        return cadenaGenerada;
    }

    public static StringBuilder cadenaEntre6I12caracters(){

        StringBuilder cadena = new StringBuilder();
        int numAleatori = (int) (Math.random()*4+1);

        for (int i = 1; i <= 6 + numAleatori; i++){
            int numAleatori2 = (int) (Math.random()*35+0);
            String cadenaAlfabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            cadena.append(cadenaAlfabet.charAt(numAleatori2));
        }

        return cadena;
    }
}