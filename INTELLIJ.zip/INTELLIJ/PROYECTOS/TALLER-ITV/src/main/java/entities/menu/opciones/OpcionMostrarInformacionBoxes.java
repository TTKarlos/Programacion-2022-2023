package entities.menu.opciones;

import entities.Taller;

public class OpcionMostrarInformacionBoxes extends OpcionesTaller{
    protected Taller taller;

    public OpcionMostrarInformacionBoxes(Taller taller) {
        super("Mostrar Informacion de Todos lo Boxes", taller);
        this.taller = taller;
    }

    @Override
    public void ejecutar() {
        taller.mostrarInformacionDeTodosLosBoxes();
    }
}