package activitat16;

public class Pizza {

    private String nombre;
    private Massa massa;
    private Ingrediente[] ingredietes = new Ingrediente[2];

    public Pizza(String nombre, Ingrediente ingrediete1, Ingrediente ingrediete2){
        this.massa = new Massa();
        this.nombre = nombre;
        this.ingredietes[0] = ingrediete1;
        this.ingredietes[1] = ingrediete2;
    }

    public void anyadirIngrediente(Ingrediente ingrediente){
        if(ingredietes.length >= 5){
            System.out.println("No puedes añadir más de 5 ingredientes");
            return;
        }
        Ingrediente[] nuevosIngredientes = new Ingrediente[ingredietes.length + 1];
        for(int i = 0; i < nuevosIngredientes.length - 1; i++){
            nuevosIngredientes[i] = ingredietes[i];
        }

        nuevosIngredientes[nuevosIngredientes.length - 1] = ingrediente;
        this.ingredietes = nuevosIngredientes;
    }

    public int getNumeroIngredientes(){
        return ingredietes.length;
    }

    public void setBordeRelleno(boolean bordeRelleno){
        massa.setRellenoDeQueso(bordeRelleno);
    }

    public double getPrecio(){
        double totalPrecio = massa.getPrecio();
        for(int i = 0; i < ingredietes.length; i++){
            totalPrecio += ingredietes[i].getPrecio();
        }

        return totalPrecio;
    }
}