package es.puchades.productos.tipos;

import es.puchades.productos.Producto;

public class Montadito extends Producto {
    public Montadito(String nombre, String descripcion, float precioBase, float decuento, float iva) {
        super(nombre, descripcion, precioBase, decuento, iva);
    }
}