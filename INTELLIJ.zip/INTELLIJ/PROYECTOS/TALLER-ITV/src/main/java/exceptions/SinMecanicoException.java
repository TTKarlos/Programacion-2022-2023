package exceptions;

public class SinMecanicoException extends Exception{
    public SinMecanicoException(int faseDestino){
        super("Error! No hay mecánicos en la fase " + faseDestino);
    }
}