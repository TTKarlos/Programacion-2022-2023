package entities.menu.opciones;

import entities.Taller;

public class OpcionMoverMecanicoDeFase extends OpcionesTaller{
    protected Taller taller;

    public OpcionMoverMecanicoDeFase(Taller taller) {
        super("Mover Mecanico de una Fase", taller);
        this.taller = taller;
    }

    @Override
    public void ejecutar() {
        taller.moverMecanicoDeFase();
    }
}