package es.cipfpbatoi.plantillaexamen.model.dao;

import es.cipfpbatoi.plantillaexamen.model.dao.interfaces.EditorialDAOInterface;
import es.cipfpbatoi.plantillaexamen.model.utils.Editorial;
import es.cipfpbatoi.plantillaexamen.model.utils.database.MySQLConnection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.sql.*;
import java.util.ArrayList;

@Service
public class EditorialDAO implements EditorialDAOInterface {
    @Autowired
    private final MySQLConnection mySQLConnection;

    public EditorialDAO(@Autowired MySQLConnection mySQLConnection) {
        this.mySQLConnection = mySQLConnection;
    }

    @Override
    public boolean save(Editorial editorial){
        if(editorial.getId() > 0){
            return update(editorial);
        }

        return insert(editorial);
    }

    private boolean update(Editorial editorial){
        String sql = "UPDATE editoriales SET nombre = ? nif = ? WHERE id = ?";

        try(
                Connection connection = mySQLConnection.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql)){
            preparedStatement.setString(1, editorial.getNombre());
            preparedStatement.setString(2, editorial.getNif());
            preparedStatement.setInt(3, editorial.getId());

            int combrobador = preparedStatement.executeUpdate();

            return combrobador > 0;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private boolean insert(Editorial editorial){
        String sql = "INSERT INTO editoriales (id, nombre, nif) VALUE (?,?,?)";

        try(
                Connection connection = mySQLConnection.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                ){
            preparedStatement.setInt(1, editorial.getId());
            preparedStatement.setInt(2, editorial.getId());
            preparedStatement.setInt(3, editorial.getId());
            int comprobador = preparedStatement.executeUpdate();

            return comprobador > 0;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    public ArrayList<Editorial> findAll() {
        ArrayList<Editorial> editorials = new ArrayList<>();

        try (
                Connection connection = mySQLConnection.getConnection();
                Statement statement = connection.createStatement();
        ){
            String sql = "SELECT * FROM editoriales";
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()){
                editorials.add(mapToResultset(resultSet));
            }

            return editorials;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    public Editorial findById(int id) {
        try (
                Connection connection = mySQLConnection.getConnection();
                Statement statement = connection.createStatement();
                ){
            String sql = "SELECT * FROM editoriales WHERE id = " + id;
            ResultSet resultSet = statement.executeQuery(sql);

            if(resultSet.next()){
                return mapToResultset(resultSet);
            }

            return null;
        } catch (SQLException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    private Editorial mapToResultset(ResultSet resultSet) throws SQLException {
        return new Editorial(resultSet.getInt("id"), resultSet.getString("nombre"),
                resultSet.getString("nif"));
    }
}