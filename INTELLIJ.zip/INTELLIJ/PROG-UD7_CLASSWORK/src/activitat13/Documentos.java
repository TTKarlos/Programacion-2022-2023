package activitat13;

public class Documentos implements Imprimible{
    private String titulo;
    private String fechaDePublicacion;
    private String texto;

    public Documentos(String titulo, String fechaDePublicacion, String texto){
        this.titulo = titulo;
        this.fechaDePublicacion = fechaDePublicacion;
        this.texto = texto;
    }

    @Override
    public void obtenerTexto() {
        System.out.println("[Documentos]: titulo: " + titulo + " fecha publicacion: " +
                fechaDePublicacion + " texto: " + texto);
    }
}