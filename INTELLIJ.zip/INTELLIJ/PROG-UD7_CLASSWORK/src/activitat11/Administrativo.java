package activitat11;

public class Administrativo extends Empleado {

    final static float INCREMENTAR_SALARI = 0.05f;
    private int despacho;
    private String fax;

    public Administrativo(String nombre, String apellidos, String dni, String fechaDeInicio, String telefono,
                          float salario, int despacho, String fax){
        super(nombre, apellidos, dni, fechaDeInicio, telefono, salario);
        this.despacho = despacho;
        this.fax = fax;
    }

    public void incrementarSalario(){
        setSalario(getSalario() + (getSalario() * INCREMENTAR_SALARI));
    }

    @Override
    public String toString() {
        return "Puesto de la empresa: ADMINISTRATIVO, " + super.toString() + ", Oficina: " + despacho + ", Fax: +" + fax;
    }
}