package activitat17;

public enum Cambio {
    MANUAL {
        public String toString() {
            return "M";
        }
    },
    AUTOMATIC {
        public String toString() {
            return "A";
        }
    }
}