package es.cipfpbatoi.plantillaexamen.model.dao.interfaces;

import es.cipfpbatoi.plantillaexamen.model.utils.Editorial;
import org.springframework.stereotype.Service;
import java.util.ArrayList;

@Service
public interface EditorialDAOInterface {
    boolean save(Editorial editorial);
    ArrayList<Editorial> findAll();
    Editorial findById(int id);
}