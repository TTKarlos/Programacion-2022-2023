import java.util.Scanner;

public class Actividad10 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("introdueix un numero:");
        float num1= teclado.nextFloat();

        System.out.println("introdueix un numero:");
        float num2= teclado.nextFloat();

        System.out.println("introdueix un numero:");
        float num3= teclado.nextFloat();

        float resultado = (num1*num2*num3);

        System.out.println(resultado);

    }
}
