package entities.menu.opciones;

import entities.Taller;

public class OpcionReclamarVehiculo extends OpcionesTaller{
    protected Taller taller;

    public OpcionReclamarVehiculo(Taller taller) {
        super("Reclamar Vehiculo", taller);
        this.taller = taller;
    }

    @Override
    public void ejecutar() {
        taller.reclamarVehiculo();
    }
}