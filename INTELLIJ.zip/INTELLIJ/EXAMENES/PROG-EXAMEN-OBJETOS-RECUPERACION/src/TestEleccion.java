import java.time.LocalDate;
import java.util.ArrayList;

public class TestEleccion {
    public static void main(String[] args) {
        Partido miPartido = new Partido(1, "miPartido");
        Partido tuPartido = new Partido(2, "tuPartido");
        ArrayList<Partido> partidos = new ArrayList<>();
        partidos.add(miPartido);
        partidos.add(tuPartido);
        Eleccion eleccionExpress = new EleccionExpress(partidos, LocalDate.of(2023, 6, 12));
        Eleccion eleccionFlexible = new EleccionFlexible(partidos, LocalDate.of(2023, 6, 10), 10);
        eleccionExpress.generarMesaElectoral();
        eleccionExpress.generarMesaElectoral();
        eleccionExpress.generarMesaElectoral();
        eleccionExpress.generarMesaElectoral();
        eleccionExpress.generarMesaElectoral();
        String dni1 = eleccionExpress.getMesasElectorales().get(0).getCiudadanosConvocados().get(0);
        String dni2 = eleccionExpress.getMesasElectorales().get(1).getCiudadanosConvocados().get(2);
        String dni3 = eleccionExpress.getMesasElectorales().get(2).getCiudadanosConvocados().get(1);
        String dni4 = eleccionExpress.getMesasElectorales().get(3).getCiudadanosConvocados().get(3);
        String dni5 = eleccionExpress.getMesasElectorales().get(0).getCiudadanosConvocados().get(1);

        eleccionExpress.votar(dni1, miPartido);
        eleccionExpress.votar(dni2, miPartido);
        eleccionExpress.votar(dni3, tuPartido);
        eleccionExpress.votar(dni4, miPartido);
        eleccionExpress.votar(dni5, tuPartido);

        eleccionExpress.calcularResultados();

        for (int i = 0; i < eleccionExpress.getResultados().size(); i++) {
            System.out.println("Partido: " + eleccionExpress.getResultados().get(i).getPartido().getNombre());
            System.out.println("Votos: " + eleccionExpress.getResultados().get(i).getVotos());
        }
    }
}