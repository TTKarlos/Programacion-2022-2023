package activitat6;

public class TestEmpresa {
    public static void main(String[] args) {

        Administrativo administrativo = new Administrativo("Juan", "Perez Perez", "21655251Q",
                "20/2/2022", "34564544544", 1000.00f, 2, "34564544544");

        Vendedor vendedor = new Vendedor("Vendedor1", "Gomez Gomez", "21564451E",
                "20/2/2020", "654879123", 2000.00f, false, 2,
                new Cliente[]{}, 5);

        Cliente[] listaClientes = new Cliente[2];
        listaClientes[0] = new Cliente("Paco", 658742547, "21808974D", "Aitex");
        listaClientes[1] = new Cliente("Alejandro", 654789123, "21589645H", "Mercadona");

        System.out.println("---- Trabajadores antes de aumentar salario ----");
        System.out.println(administrativo);
        System.out.println(vendedor);
        System.out.println();

        System.out.println("---- Trabajadores después de aumentar salario ----");
        administrativo.incrementarSalario();
        vendedor.incrementarSalario();
        System.out.println(administrativo);
        System.out.println(vendedor);
        System.out.println();

        System.out.println("---- Vendedor después de añadir 2 clientes ----");
        vendedor.añadirCliente(listaClientes[0]);
        vendedor.añadirCliente(listaClientes[1]);
        System.out.println(administrativo);
        System.out.println(vendedor);
        System.out.println();
    }
}