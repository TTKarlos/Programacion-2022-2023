public class Acticitat18 {
    public static void main(String[] args) {

        System.out.println("Es salutacio: " + igualASalutacio("Alex"));
        System.out.println("Es salutacio: " + igualASalutacio("HOLA"));
        System.out.println("Es salutacio: " + igualASalutacio("HELLO" ));
    }

    public static boolean igualASalutacio(String frase){

        String salutacio1 = "Hola";
        String salutacio2 = "Hello";
        String salutacio3 = "Què tal";

        boolean esSalutacio = false;

        if (frase.equalsIgnoreCase(salutacio1) || frase.equalsIgnoreCase(salutacio2) || frase.equalsIgnoreCase(salutacio3)){
            esSalutacio = true;
        }
        return esSalutacio;
    }
}
