import java.util.Scanner;
import java.util.SortedMap;

public class Activitat1 {

    final static int MAJOR_DE_EDAD = 18;

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("Introdueix la teau edad:");
        int edad = teclado.nextInt();
        if (edad >= MAJOR_DE_EDAD) {
            System.out.println("Es major de edad");
        }else {
            System.out.println("No es major de edad");
        }

    }
}