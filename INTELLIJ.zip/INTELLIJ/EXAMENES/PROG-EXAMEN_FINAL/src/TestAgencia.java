import exception.ViajeNoValidoException;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class TestAgencia {
    public static void main(String[] args) {
        Agencia agencia = new Agencia("Ag236735S", "Tus Viajes Online, S.L",
                "Elena Diaz", "Alicante-Madrid-Valencia-Sevilla-Bacelona-Alcoy-Cordoba");
        try {
            agencia.anyadirViaje(new Viaje("v-1", "Alicante-Sevilla-Alicante",
                    LocalDateTime.of(2023, 5, 10, 18, 0, 0, 0),
                    100, 7));
            agencia.anyadirViaje(new Viaje("v-2", "Alcoy-Barcelona-Alcoy",
                    LocalDateTime.of(2023, 5, 5, 14, 0, 0, 0),
                    200, 5, 3));
            agencia.anyadirViaje(new Viaje("v-3", "Alicante-Barcelona-Madrid-Alicante",
                    LocalDateTime.of(2023, 5, 10, 9, 0, 0, 0),
                    175, 2, 4));
            agencia.anyadirViaje(new ViajeExclusivo("vex-4", "Alicante-Madrid-Alicante",
                    LocalDateTime.of(2023, 3, 31, 9, 0, 0, 0),
                    200, 3, 4));
        }catch (ViajeNoValidoException e){
            System.out.print(e.getMessage());
        }

        agencia.getViaje("v-1").realizarReserva("Albeto", 2);
        agencia.getViaje("v-2").realizarReserva("Ana", 1);
        agencia.getViaje("vex-4").realizarReserva("Enrique", 1);
        agencia.getViaje("v-3").realizarReserva("Ana", 1);
        agencia.getViaje("v-2").realizarReserva("Beatriz", 2);

        mostrarViajes(agencia.getViajesPendientes());
    }

    public static void mostrarViajes(ArrayList<Viaje> viajes){
        for (int i = 0; i < viajes.size(); i++) {
            System.out.println(viajes.get(i));
        }
    }
}