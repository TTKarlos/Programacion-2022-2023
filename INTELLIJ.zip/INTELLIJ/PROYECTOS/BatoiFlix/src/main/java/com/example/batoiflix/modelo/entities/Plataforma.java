package com.example.batoiflix.modelo.entities;

public class Plataforma {
    private int codigo;
    private String nombre;

    public Plataforma(int codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }
    public Plataforma(String nombre) {
        this.codigo = -1;
        this.nombre = nombre;
    }
}
