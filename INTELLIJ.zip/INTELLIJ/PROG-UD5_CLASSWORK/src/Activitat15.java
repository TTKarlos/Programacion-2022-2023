public class Activitat15 {
    public static void main(String[] args) {

        String[][] matriz = new String[5][7];

        rellenarMatriz(matriz);
        visualizarMatriu(matriz);
        visualizarFila(5 ,matriz);
        System.out.println(matriz[3][2]);
        System.out.println(matriz[4][2]);
        visualizarMatriu(cambiarQuartaFilayTerceraFila(matriz));
        //visualizarMatriu(intercambiarPrimeraYQuartaColumna(matriz));

    }

    public static void rellenarMatriz(String[][] matriz){
        for(int i = 0; i < matriz.length; i++){
            for(int j = 0; j < matriz[i].length; j++){
                matriz[i][j] = String.valueOf((char)('a' + i + j));
            }
        }
    }

    public static void visualizarFila(int numFila, String[][] matriz){
        for(int i = 0; i < matriz[numFila - 1].length; i++){
            System.out.println(matriz[numFila - 1][i]);
        }
    }

    public static String[][] cambiarQuartaFilayTerceraFila(String[][] matriu){
        String[][] matriuInvertida = matriu;
        matriuInvertida[3][2] = matriu[4][2];
        matriuInvertida[4][2] = matriu[3][2];

        return matriuInvertida;
    }

    public static void visualizarMatriu(String[][] matriu){
        for(int i = 0; i < matriu.length; i++){
            for (int j = 0; j < matriu[i].length; j++){
                System.out.print(matriu[i][j]);
            }
            System.out.print("\n");
        }
    }

    public static String[][] intercambiarPrimeraYQuartaColumna(String[][] matriu){

        String[][] matriuIntercanviada = matriu;

        for (int i = 0; i < matriu[0].length; i++){
            matriuIntercanviada[i][0] = matriu[i][3];
        }

        for (int j = 0; j < matriu[3].length ; j++){
            matriuIntercanviada[j][3] = matriu[j][0];
        }

        return matriuIntercanviada;
    }
}