package es.cipfpbatoi.modelo.repositorios;

import es.cipfpbatoi.excepciones.NotFoundException;
import es.cipfpbatoi.modelo.dao.FileTareaDAO;
import es.cipfpbatoi.modelo.dao.TareaDaoInterface;
import es.cipfpbatoi.modelo.entidades.Tarea;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;

@Service
public class TareaRepository {

    private TareaDaoInterface tareaDao;

    public TareaRepository(@Autowired FileTareaDAO tareaDao) {
        this.tareaDao = tareaDao;
    }

    /**
     * Añade la Tarea recibida como argumento a la base de datos en memoria
     * @param tarea
     */
    public void add(Tarea tarea) {
        this.tareaDao.add(tarea);
    }

    /**
     * Obtiene la Tarea con codigo @codTarea. En caso de que no la encuentre devolverá una excepción
     * @NotFoundException
     *
     * @param codigo
     */
    public Tarea get(int codigo) throws NotFoundException {
        return tareaDao.getById(codigo);
    }

    public Tarea find(int codTarea) {
        return tareaDao.findById(codTarea);
    }

    /**
     *  Devuelve el listado de todas las tareas.
     */
    public ArrayList<Tarea> findAll() {
        return tareaDao.findAll();
    }

    /**
     *  Devuelve el listado de todas las tareas.
     */
    public ArrayList<Tarea> findAll(Boolean isRealizado, LocalDate vencimiento, String usuario) {
        return tareaDao.findAllWithParams(isRealizado, vencimiento, usuario);
    }

    /**
     *  Devuelve el listado de todas las tareas cuyo atributo nombre coincide con @user
     */
    public ArrayList<Tarea> findAll(String user) {
        return tareaDao.findAllWithParams(user);
    }

    /**
     * Borra una tarea a partir de su código
     * @param tarea
     */
    public void remove(Tarea tarea) {
        this.tareaDao.delete(tarea.getCodigo());
    }

    public int nextCode() {
       ArrayList<Tarea> tareas = tareaDao.findAll();
        int max = 0;
        for (Tarea item: tareas) {
            max = Math.max(max, item.getCodigo());
        }
        return max + 1;
    }
}
