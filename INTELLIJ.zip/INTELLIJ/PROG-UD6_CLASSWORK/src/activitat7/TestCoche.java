package activitat7;

public class TestCoche {
    public static void main(String[] args) {
        Coche [] listado = new Coche[5];
        listado[0] = new Coche("Seat", "Ibiza", "Rojo", true, "2212KVN", 2000);
        listado[1] = new Coche("Ferrari", "Modela", "Negro", true, "2122RRN", 1985);
        listado[2] = new Coche("Volkswagen", "Tiguan", "Blanco", false, "1212KJ", 2015);
        listado[3] = new Coche("Opel", "Corsa", "Verde", true, "56355R", 2003);
        listado[4] = new Coche();

        for(int i = 0; i < listado.length; i++){
            listado[i].mostrarInformacion();
            System.out.println();
        }
    }
}