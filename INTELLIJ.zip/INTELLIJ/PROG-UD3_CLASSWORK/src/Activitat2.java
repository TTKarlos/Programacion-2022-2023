import java.util.Scanner;

public class Activitat2 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Introdueix un número: ");
        int numero = teclado.nextInt();

        if ( numero % 2 == 0){
            System.out.println("És par");
        }
        else {
            System.out.println("No és par");
        }
        if (numero<0){
            System.out.println("És negatiu");
        }
        else {
            System.out.println("És positiu");
        }

    }
}
