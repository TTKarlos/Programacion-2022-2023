package com.example.batoiflix.modelo.dao;

import com.example.batoiflix.modelo.dao.interfaces.UsuarioDAOInterface;
import com.example.batoiflix.modelo.entities.Usuario;
import com.example.batoiflix.modelo.enums.TipoUsuario;
import com.example.batoiflix.utils.database.MySQLConnection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

@Service
public class UsuarioDAO implements UsuarioDAOInterface {
    MySQLConnection mySQLConnection;
    public UsuarioDAO(@Autowired MySQLConnection mySQLConnection){
        this.mySQLConnection = mySQLConnection;
    }
    @Override
    public ArrayList<Usuario> findAll() throws Exception {
        String sql = "SELECT * FROM usuarios";
        try(Connection connection = mySQLConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            ArrayList<Usuario> usuarios = new ArrayList<>();
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()){
                usuarios.add(mapFromResultSet(rs));
            }
            return usuarios;
        } catch (SQLException e){
            throw new Exception(e.getMessage());
        }
    }

    @Override
    public boolean save(Usuario usuario) throws Exception {
        if (usuario.getCodigo() < 0){
            return insert(usuario);
        } else {
            return update(usuario);
        }
    }

    private Usuario findByID(int id) throws Exception {
        String sql = "SELECT * FROM usuarios WHERE id = ?";
        try(Connection connection = mySQLConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1,id);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()){
                return mapFromResultSet(rs);
            }
            return null;
        } catch (SQLException e){
            throw new Exception(e.getMessage());
        }
    }

    private Usuario findByEmail(String email) throws Exception {
        String sql = "SELECT * FROM usuarios WHERE email = ?";
        try(Connection connection = mySQLConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1,email);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()){
                return mapFromResultSet(rs);
            }
            return null;
        } catch (SQLException e){
            throw new Exception(e.getMessage());
        }
    }

    @Override
    public Usuario getByID(int id) throws Exception {
        Usuario usuario = findByID(id);
        if (usuario!= null){
            return usuario;
        }
        throw new RuntimeException("Usuario con id "+ id + " no encontrado");
    }

    @Override
    public Usuario getByEmail(String email) throws Exception {
        Usuario usuario = findByEmail(email);
        if (usuario != null){
            return usuario;
        } else {
            throw new RuntimeException("Usuario con email "+ email + " no encontrado");
        }
    }

    private boolean update(Usuario usuario) throws Exception {
        String sql = "UPDATE usuarios SET  nombre = ?, contraseña = ?, tipo = ?";
        try(Connection connection = mySQLConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1,usuario.getNombre());
            preparedStatement.setString(2, usuario.getContrasenya());
            preparedStatement.setString(3,usuario.getTipoUsuario().toString());
            return preparedStatement.executeUpdate() == 1;
        } catch (SQLException e){
            throw new Exception(e.getMessage());
        }
    }

    private boolean insert(Usuario usuario) throws Exception {
        String sql = "INSERT INTO usuarios (nombre, contraseña, tipo) VALUES (?,?,?)";
        try(Connection connection = mySQLConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1,usuario.getNombre());
            preparedStatement.setString(2, usuario.getContrasenya());
            preparedStatement.setString(3,usuario.getTipoUsuario().toString());
            ResultSet resultSet = preparedStatement.getGeneratedKeys();
            if (resultSet.next()){
                int autoIncremental = resultSet.getInt(1);
                usuario.setCodigo(autoIncremental);
                return true;
            }
            return false;
        } catch (SQLException e){
            throw new Exception(e.getMessage());
        }
    }

    private Usuario mapFromResultSet(ResultSet resultSet) throws SQLException {
        String nombre = resultSet.getString("nombre");
        String apellidos = resultSet.getString("apellidos");
        String email = resultSet.getString("email");
        int id = resultSet.getInt("id");
        String password = resultSet.getString("contraseña");
        TipoUsuario tipoUsuario = TipoUsuario.valueOf("tipo");
        return new Usuario(id,nombre,apellidos,email,password,tipoUsuario);
    }

    @Override
    public Usuario getByName(String nombre, String apellidos) throws Exception {
        Usuario usuario = findByName(nombre, apellidos);
        if (usuario != null){
            return usuario;
        }
        throw new Exception("No se ha encontrado ningún usuario con el nombre " + nombre + " " + apellidos);
    }

    private Usuario findByName(String nombre, String apellidos) throws Exception {
        String sql = "SELECT * FROM usuarios WHERE nombre = ? AND apellidos = ?";
        try(Connection connection = mySQLConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1,nombre);
            preparedStatement.setString(2,apellidos);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()){
                return mapFromResultSet(rs);
            }
            return null;
        } catch (SQLException e){
            throw new Exception(e.getMessage());
        }
    }
}