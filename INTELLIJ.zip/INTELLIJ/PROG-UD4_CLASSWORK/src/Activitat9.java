public class Activitat9 {
    public static void main(String[] args) {

        int numMaxim = obtenirElMajor(2, 10, 3, 8);
        System.out.println("El número máxim és: " + numMaxim);
    }

    public static int obtenirElMajor(int num1, int num2, int num3, int num4){

        if (num1 > num2){
            num2 = num1;
        } else if (num2 > num3){
            num3 = num2;
        } else if (num3 > num4){
            num4 = num3;
        } else {
            num4 = num4;
        }
        return num4;
    }
}
